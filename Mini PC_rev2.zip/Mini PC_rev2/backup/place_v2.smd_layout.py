"""Placement of the whole 100 x 100 mm panel (handheld + left break-off flight node). Run with KiCad CLOSED, KiCad's python:
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\place_v2.py MiniPC_v2.kicad_pcb [--write]
Coordinates in mm, y grows downwards, origin = top-left corner of the panel.
  node strip   x 0 .. 20   (left, break-off, 3 mouse-bite tabs over a 2 mm routed slot)
  handheld     x 22 .. 100 (78 x 100): J3 / J1 in the top corners, screen below them (landscape), flat SMD parts under the screen,
               d-pad cross bottom-left, encoder in the middle, ESP32 on the right with its antenna hanging over the right edge,
               PWR + BOOT + RESET just under the ESP32, slide switch + USB-C on the right edge. Radios, module headers, ports on the back.
Big parts are placed by hand (table PLACE); passives are dropped next to the pad they serve (table NEAR) by a spiral search that keeps
courtyards apart and stays off the through-hole pads of the other side.
Rewrites the outline (Edge.Cuts), the mouse-bite footprints and the J5 / U1 courtyards (J5: header only, so parts may sit under the
screen module; U1: module body only, the antenna overhangs the edge)."""
import math
import os
import sys

import pcbnew

HERE = os.path.dirname(os.path.abspath(__file__))
args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0] if args else os.path.join(HERE, "..", "MiniPC_v2.kicad_pcb"))
WRITE = "--write" in sys.argv
MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))

NODE_W = 20.0                     # break-off strip width
SLOT = 2.0
HX0 = NODE_W + SLOT               # handheld left edge
R = 2.0                           # outer corner radius
TABS = (15.0, 50.0, 85.0)         # tab centres (y), 5 mm wide
TAB_W = 5.0

_keep = pcbnew.LoadBoard(PCB)     # KiCad's python wants the board loaded twice
# pre-pass: drop the old outline and mouse bites, save to a temp file and reload. (Removing items from a board that is then
# edited further breaks KiCad 10's python wrappers: later lookups come back as bare SwigPyObjects.)
pre = pcbnew.LoadBoard(PCB)
for d in [d for d in pre.GetDrawings() if d.GetLayer() == pcbnew.Edge_Cuts]:
    pre.Delete(d)
for f in [f for f in pre.GetFootprints() if f.GetReference().startswith("MB")]:
    pre.Delete(f)
TMP = os.path.join(os.environ.get("TEMP", HERE), "place_v2_tmp.kicad_pcb")
pcbnew.SaveBoard(TMP, pre, True)
board = pcbnew.LoadBoard(TMP)
FP = {f.GetReference(): f for f in board.GetFootprints()}


# ---------------------------------------------------------------- footprint helpers
def orient(ref, rot, back):
    f = FP[ref]
    if f.IsFlipped() != back:
        f.Flip(f.GetPosition(), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
    f.SetOrientationDegrees(rot)
    return f


def crt_box(f):
    """courtyard bbox (l, t, r, b) in mm; falls back to the footprint bbox without texts"""
    lay = pcbnew.B_CrtYd if f.IsFlipped() else pcbnew.F_CrtYd
    try:
        bb = f.GetCourtyard(lay).BBox()
        if bb.GetWidth() > 0:
            return (TOMM(bb.GetLeft()), TOMM(bb.GetTop()), TOMM(bb.GetRight()), TOMM(bb.GetBottom()))
    except Exception:
        pass
    bb = f.GetBoundingBox(False)
    return (TOMM(bb.GetLeft()), TOMM(bb.GetTop()), TOMM(bb.GetRight()), TOMM(bb.GetBottom()))


def put(ref, rot=0, back=False, **kw):
    """place so that one side / the centre of the courtyard box lands on the given coordinate:
    put('U8', 0, False, l=1, t=27) | put(..., cx=.., cy=..) | put(..., r=.., b=..)"""
    f = orient(ref, rot, back)
    f.SetPosition(V(0, 0))
    l, t, r, b = crt_box(f)
    dx = kw["l"] - l if "l" in kw else kw["r"] - r if "r" in kw else kw["cx"] - (l + r) / 2 if "cx" in kw else 0
    dy = kw["t"] - t if "t" in kw else kw["b"] - b if "b" in kw else kw["cy"] - (t + b) / 2 if "cy" in kw else 0
    f.SetPosition(V(dx, dy))
    return f


def put_local(ref, rot, back, local, target):
    """place so that the footprint-local point `local` (unrotated, unflipped) lands on `target` (x, y)"""
    f = orient(ref, rot, back)
    f.SetPosition(V(0, 0))
    lx, ly = local
    if back:
        lx = -lx
    a = math.radians(rot)
    gx = lx * math.cos(a) + ly * math.sin(a)          # KiCad: positive angle = counter-clockwise on screen (y down)
    gy = -lx * math.sin(a) + ly * math.cos(a)
    f.SetPosition(V(target[0] - gx, target[1] - gy))
    return f


def pad_xy(ref, num):
    ps = [p for p in FP[ref].Pads() if p.GetNumber() == str(num)]
    p = ps[0].GetPosition()
    return TOMM(p.x), TOMM(p.y)


def put_pad(ref, back, num, target, facing):
    """place so that pad `num` lands exactly on `target`, picking the rotation (0 / 90 / 180 / 270) that puts the pad on the
    `facing` side of the footprint ('left', 'right', 'up', 'down'). Uses KiCad's real pad position (no flip / rotate maths)."""
    f = FP[ref]
    for rot in (0, 90, 180, 270):
        orient(ref, rot, back)
        f.SetPosition(V(0, 0))
        px, py = pad_xy(ref, num)
        if {"left": px < -0.5, "right": px > 0.5, "up": py < -0.5, "down": py > 0.5}[facing]:
            f.SetPosition(V(target[0] - px, target[1] - py))
            return f
    raise ValueError("%s: no rotation puts pad %s %s" % (ref, num, facing))


def pads_of_net(ref, net):
    return [(TOMM(p.GetPosition().x), TOMM(p.GetPosition().y)) for p in FP[ref].Pads() if p.GetNetname() == net]


# ---------------------------------------------------------------- big parts, by hand
SCREEN_CX = HX0 + (100 - HX0) / 2          # 61.0
P = put
# --- handheld, front
P("J3", 90, False, l=HX0 + 1.0, t=0.8)                          # EXP 2, top-left corner
P("J1", 90, False, r=100 - 1.0, t=0.8)                          # EXP 1, top-right corner
put_local("J5", 0, False, (0, 0), (SCREEN_CX - 7.62, 4.6 + 41.3))   # screen: pad 1, header row at the bottom of the module
# ESP32: rot -90 = antenna (local -y) points right; the antenna part (local y < -6.75) hangs over the right edge
U1_CY = 59.3
put_local("U1", -90, False, (0, -6.75), (100.0, U1_CY))
# d-pad cross (button pitch 10 mm)
DX, DY, DP = 37.2, 72.0, 10.0
P("SW7", 0, False, cx=DX, cy=DY)                                # MIDDLE
P("SW3", 0, False, cx=DX, cy=DY - DP)                           # UP
P("SW4", 0, False, cx=DX, cy=DY + DP)                           # DOWN
P("SW5", 0, False, cx=DX - DP, cy=DY)                           # LEFT
P("SW6", 0, False, cx=DX + DP, cy=DY)                           # RIGHT
P("SW10", 0, False, l=57.0, t=58.6)                             # encoder
P("SW11", 0, False, cx=65.8, cy=81.0)                           # EXIT, under the encoder
P("SW1", 90, False, l=76.0, t=69.8)                             # BOOT  } side by side, right under the ESP32,
P("SW2", 90, False, l=79.8, t=69.8)                             # RESET } next to the PWR button
P("SW8", 0, False, l=83.6, t=70.2)                              # PWR (deep-sleep) button
# slide switch: actuator (local +y) out of the right edge, mounting pads 0.2 mm inside it
put_local("SW9", 90, False, (0, 2.05), (100.0, 94.0))
# USB-C: opening (local +y, body front at 3.65) flush with the right edge
put_local("J2", 90, False, (0, 3.65), (100.0, 83.8))
# status LEDs + light sensor in the gap between the screen and the controls
for i, ref in enumerate(("D4", "D5", "D6", "D7")):
    P(ref, 0, False, cx=30.0 + 12.0 * i, cy=52.6)
P("R9", 0, False, cx=74.0, cy=52.6)                              # LDR
P("BZ1", 0, False, l=HX0 + 0.6, b=99.4)                          # buzzer, bottom-left corner
P("Q3", 0, False, l=37.0, b=99.4)                                # buzzer NPN
P("D8", 90, False, l=43.0, b=99.4)                               # flyback diode
# --- handheld, back (top row ports, radios, module headers)
for ref, x in (("J4", 35.6), ("J12", 48.6), ("J13", 61.6), ("J14", 74.6)):
    P(ref, 90, True, l=x, t=0.8)
P("U7", 0, True, l=HX0 + 4.8, t=6.0)                             # LoRa RFM95W, 4.8 mm in: its left pins escape outward, not under it
# u.FL straight right of the antenna pad (pad 9), signal pin facing it: 3 mm feed, no vias (drawn by manual.py)
_a9 = pad_xy("U7", 9)
put_pad("J10", True, 1, (_a9[0] + 3.0, _a9[1]), "left")
P("U5", 90, True, l=HX0 + 1.0, t=25.0)                          # CC1101 socket (1.27 mm), 2nd header row
P("J9", 90, True, l=58.0, t=6.0)                                 # GY-91
P("J11", 90, True, l=81.6, t=6.0)                                # HAPTIC
P("M1", 0, True, l=91.0, t=11.0)                                 # coin motor wires
P("J7", 90, True, l=45.0, t=25.0)                                # CHARGER
P("J8", 90, True, l=63.0, t=25.0)                                # 3V3 MOD
P("J6", 0, True, l=77.0, t=24.0)                                 # LIPO JST

# --- node strip, front
P("U9", 0, False, cx=10.0, t=1.0)                                 # RFM95W
P("U11", 0, False, l=0.8, t=18.6)                                 # AMS1117
P("U8", 0, False, l=1.6, t=27.0)                                  # ATmega32U4 (1.6 mm in: room for vias left of its edge pins)
P("D9", 90, False, l=15.6, t=27.0)                                # Schottky USB 5 V
P("D10", 90, False, l=15.6, t=34.6)                               # Schottky BEC
put_local("J16", -90, False, (0, 3.65), (0.0, 47.6))              # USB-C, opening out of the left edge
P("J18", 0, False, l=12.6, t=42.4)                                # ICSP
for i, ref in enumerate(("J15", "J19", "J20", "J21", "J22")):
    P(ref, 0, False, l=0.2 + 3.95 * i, t=54.2)                   # BEC IN + 4 sensor plugs
# power block (pours + Kelvin sense traces are drawn by route_prep.py): the WSK2512's current pads are diagonal (pad 1 upper-left,
# pad 4 lower-right), so PACK+ feeds it from the upper left, ESC+ leaves to the lower right, the INA180 sits lower left
put_local("J23", 0, False, (0, 0), (3.2, 68.8))                   # PACK+
put_local("J25", 0, False, (0, 0), (16.8, 68.8))                  # PACK-
put_local("J24", 0, False, (0, 0), (16.8, 80.6))                  # ESC+
P("R17", 0, False, cx=10.0, cy=74.6)                              # 1 mohm shunt
P("U10", 180, False, cx=4.0, cy=78.5)                             # INA180: IN+ upper right, IN- upper left
P("R34", 90, True, cx=11.5, cy=68.6)                              # 100k battery divider top: taps the PACK+ pour (stitch via)
P("D11", 0, False, cx=5.0, cy=87.5)
P("D12", 0, False, cx=10.0, cy=87.5)
# J17 u.FL right under the RFM95W's antenna pad (pad 9)
P("J17", -90, False, r=NODE_W - 0.5, t=17.8)                    # u.FL under the RFM95W's antenna pad (pad 9), signal pin up

# ---------------------------------------------------------------- courtyards of J5 (screen) and U1 (ESP32)
def replace_courtyard(ref, rect_local):
    """replace the footprint's courtyard by one rectangle given in local (unrotated) coordinates"""
    f = board.FindFootprintByReference(ref)
    lay = pcbnew.B_CrtYd if f.IsFlipped() else pcbnew.F_CrtYd
    for g in f.GraphicalItems():                       # FOOTPRINT.Remove() breaks KiCad 10's python wrappers:
        if g.GetLayer() == lay:                        # park the old courtyard on User.Comments instead
            g.SetLayer(pcbnew.Cmts_User)
    rot, px, py = f.GetOrientationDegrees(), TOMM(f.GetX()), TOMM(f.GetY())
    f.SetOrientationDegrees(0)
    x0, y0, x1, y1 = rect_local
    s = pcbnew.PCB_SHAPE(f, pcbnew.SHAPE_T_RECTANGLE)
    s.SetLayer(lay)
    s.SetWidth(MM(0.05))
    s.SetStart(V(px + x0, py + y0))
    s.SetEnd(V(px + x1, py + y1))
    f.Add(s)
    s.thisown = 0                     # KiCad owns it now (else Python frees it and the board gets corrupted)
    f.SetOrientationDegrees(rot)


replace_courtyard("J5", (-1.25, -1.25, 16.49, 1.25))              # header pins only (module is up on its header)
replace_courtyard("U1", (-9.75, -6.75, 9.75, 13.5))               # on-board part of the module (antenna overhangs)
# ESP32 antenna keep-out (off-board, right of the edge): Espressif's +-24 mm wings trimmed to +-19 mm so the USB-C below stays out of it
for z in FP["U1"].Zones():
    ol = z.Outline()
    bb = ol.BBox()
    x0, x1 = bb.GetLeft(), bb.GetRight()
    ol.RemoveAllContours()
    ol.NewOutline()
    for (x, y) in ((x0, U1_CY - 19), (x1, U1_CY - 19), (x1, U1_CY + 19), (x0, U1_CY + 19)):
        ol.Append(x, MM(y))
# the screen outline and its "keep clear" text go to F.Fab (SMD parts are allowed under the module now)
for g in list(FP["J5"].GraphicalItems()):
    if g.GetLayer() == pcbnew.F_SilkS and not (hasattr(g, "GetText") and len(g.GetText()) <= 4):
        g.SetLayer(pcbnew.F_Fab)

# ---------------------------------------------------------------- occupancy (for the passive packer)
occ = {"F": [], "B": []}                 # rectangles (l, t, r, b)
GAP = 0.25


def mark(f):
    side = "B" if f.IsFlipped() else "F"
    other = "F" if side == "B" else "B"
    if f.GetReference() != "J5":
        occ[side].append(crt_box(f))
    for p in f.Pads():
        if p.HasHole():
            bb = p.GetBoundingBox()
            r = (TOMM(bb.GetLeft()) - 0.4, TOMM(bb.GetTop()) - 0.4, TOMM(bb.GetRight()) + 0.4, TOMM(bb.GetBottom()) + 0.4)
            occ[other].append(r)
            if f.GetReference() == "J5":
                occ[side].append(r)


def free(rect, side, region):
    l, t, r, b = rect
    if l < region[0] or t < region[1] or r > region[2] or b > region[3]:
        return False
    for (L, T, Rr, B) in occ[side]:
        if l < Rr + GAP and r > L - GAP and t < B + GAP and b > T - GAP:
            return False
    return True


NODE_REG = (0.4, 0.4, NODE_W - 0.4, 99.6)
HAND_REG = (HX0 + 0.4, 0.4, 99.6, 99.6)


def tht_rects(f):
    """through-hole pads (inflated) of a footprint: they also need room on the other side"""
    out = []
    for p in f.Pads():
        if p.HasHole():
            bb = p.GetBoundingBox()
            out.append((TOMM(bb.GetLeft()) - 0.3, TOMM(bb.GetTop()) - 0.3, TOMM(bb.GetRight()) + 0.3, TOMM(bb.GetBottom()) + 0.3))
    return out


def near(ref, target, back, region, rots=(0, 90)):
    """spiral search from the target point for the first free spot"""
    f = FP[ref]
    for rad in [i * 0.4 for i in range(0, 120)]:
        n = max(1, int(2 * math.pi * rad / 0.6))
        for k in range(n):
            a = 2 * math.pi * k / n
            cx, cy = target[0] + rad * math.cos(a), target[1] + rad * math.sin(a)
            for rot in rots:
                put(ref, rot, back, cx=cx, cy=cy)
                bx = crt_box(f)
                if free(bx, "B" if back else "F", region) and all(free(r, "F" if back else "B", region) for r in tht_rects(f)):
                    mark(f)
                    return True
    print("!! no room for", ref)
    return False


for f in board.GetFootprints():
    if f.GetReference() in PLACED if "PLACED" in dir() else True:
        pass
PLACED = set()

# everything above is placed; mark them
NEAR_REFS = set()
# passives: ref -> (target ref, pad or net, side 'F'/'B', region)
H, N = HAND_REG, NODE_REG
NEAR = [
    # ESP32 decoupling + strapping
    ("C2", "U1", 2, "F", H), ("C1", "U1", 2, "F", H), ("C3", "U1", 2, "B", H),
    ("C35", "U1", 3, "F", H),                                         # EN RC capacitor (1 uF), next to the EN pin
    ("R4", "U1", 3, "F", H), ("R5", "U1", 27, "F", H),
    # USB-C side
    ("U4", "J2", "A6", "F", H), ("R3", "J2", "A7", "F", H), ("R6", "J2", "A6", "F", H),
    ("R1", "J2", "B5", "F", H), ("R2", "J2", "A5", "F", H), ("F1", "J2", "A4", "B", H), ("C10", "J2", "A4", "B", H),
    # screen
    ("C4", "J5", 1, "F", H), ("C5", "J5", 1, "F", H),
    # charger / battery / gauge
    ("C6", "J7", None, "B", H), ("U3", "J6", 1, "F", H), ("C9", "J6", 1, "F", H),
    ("C7", "J8", None, "B", H), ("C8", "J8", None, "B", H),
    ("D2", "SW9", 1, "B", H), ("D3", "J2", "A4", "B", H),          # OR-ing Schottkys where battery / USB come in (tall: not under a module)
    ("SW9_dummy", None, None, None, None),
    # CC1101, GY-91, LoRa
    ("C11", "U5", None, "B", H), ("C12", "U5", None, "B", H),
    ("C13", "J9", None, "F", H), ("R7", "J9", None, "F", H), ("R8", "J9", None, "F", H),
    ("C16", "U7", 13, "B", H), ("C17", "U7", 13, "B", H),
    # LDR
    ("R10", "R9", 2, "F", H), ("C14", "R9", 2, "F", H),
    # PCF8574 under the screen, near the ESP32 side
    ("U6", None, (52.0, 30.0), "F", H), ("C15", "U6", 16, "F", H), ("R11", "U6", 13, "F", H),
    # encoder pull-ups
    ("R12", "SW10", "A", "F", H), ("R13", "SW10", "B", "F", H),
    # LEDs
    ("C18", "D4", None, "F", H), ("C19", "D6", None, "F", H), ("C20", "D7", None, "F", H),
    # power gates
    ("Q1", "D4", None, "F", H), ("R14", "Q1", None, "F", H),
    ("Q2", "J14", None, "F", H), ("R15", "Q2", None, "F", H),
    # buzzer driver
    ("R16", "Q3", None, "F", H),
    # ---- node
    ("Y1", "U8", 17, "B", N),                                         # crystal on the back, under the XTAL pins
    ("C21", "Y1", 1, "B", N), ("C22", "Y1", 2, "B", N),
    ("C23", "U8", "/N_5V", "B", N), ("C24", "U8", "/N_5V", "B", N), ("C25", "U8", "/N_5V", "B", N), ("C26", "U8", "/N_5V", "B", N),
    ("C27", "U8", "/N_AREF", "B", N), ("C31", "U8", "/N_UCAP", "B", N),
    ("R18", "U8", "/N_RST", "B", N), ("R19", "U8", "/N_HWB", "B", N),
    ("R22", "U8", "/N_DP", "B", N), ("R23", "U8", "/N_DM", "B", N),
    ("R20", "J16", "A5", "B", N), ("R21", "J16", "B5", "B", N), ("C34", "J16", "A4", "B", N),
    ("C29", "U10", 5, "F", N),                                        # 100 nF: INA180 supply bypass (VS pin 5)
    ("C32", "U11", 3, "B", N), ("C33", "U11", 2, "B", N),             # AMS1117 in / out 10 uF
    ("C28", "U9", 13, "B", N),                                        # 100 nF at the node RFM95W's 3.3 V pin (TX bursts)
    ("R26", "U9", 3, "B", N), ("R27", "U9", 3, "B", N), ("R28", "U9", 4, "B", N), ("R29", "U9", 4, "B", N),
    ("R30", "U9", 5, "B", N), ("R31", "U9", 5, "B", N), ("R32", "U9", 6, "B", N), ("R33", "U9", 6, "B", N),
    ("R35", "U8", "/N_BATSENSE", "B", N), ("C30", "U8", "/N_BATSENSE", "B", N),
    ("R36", "J20", None, "B", N), ("R37", "J20", None, "B", N),
    ("R24", "D11", None, "F", N), ("R25", "D12", None, "F", N),
]
NEAR = [e for e in NEAR if e[1] is not None or isinstance(e[2], tuple)]
NEAR_REFS = {e[0] for e in NEAR}
for f in board.GetFootprints():
    r = f.GetReference()
    if r in FP and r not in NEAR_REFS and not r.startswith("MB"):
        mark(f)
# node power block: pours (F.Cu + In2, stitched, so no parts on the back there either) and the IN- sense path on B.Cu
for side in ("F", "B"):
    occ[side] += [(0.4, 65.9, 8.4, 75.1), (11.6, 74.05, 19.6, 83.6)]
occ["B"] += [(0.6, 71.4, 14.3, 73.0), (0.6, 71.4, 2.2, 77.6)]
occ["F"] += [(5.9, 75.4, 7.3, 78.2)]                              # IN+ sense trace


def target_of(tref, key):
    if tref is None:
        return key
    if key is None:
        bx = crt_box(FP[tref])
        return ((bx[0] + bx[2]) / 2, (bx[1] + bx[3]) / 2)
    if isinstance(key, str) and key.startswith("/"):
        return None
    return pad_xy(tref, key)


used_net_pads = {}
for ref, tref, key, side, reg in NEAR:
    if isinstance(key, str) and key.startswith("/"):
        pts = pads_of_net(tref, key)
        i = used_net_pads.get((tref, key), 0)
        used_net_pads[(tref, key)] = i + 1
        tgt = pts[i % len(pts)]
    else:
        tgt = target_of(tref, key)
    near(ref, tgt, side == "B", reg)

# anything never placed on the board?
for f in board.GetFootprints():
    bx = crt_box(f)
    r = f.GetReference()
    if r.startswith("MB"):
        continue
    inside_node = bx[2] <= NODE_W + 0.01 and bx[0] >= -0.6
    inside_hand = bx[0] >= HX0 - 0.01
    if not (inside_node or inside_hand):
        print("!! %s straddles / outside: %s" % (r, [round(v, 2) for v in bx]))

# ---------------------------------------------------------------- outline: one outer loop + internal slot cut-outs
EW = 0.05


def seg(a, b):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_SEGMENT)
    s.SetLayer(pcbnew.Edge_Cuts); s.SetWidth(MM(EW)); s.SetStart(V(*a)); s.SetEnd(V(*b)); board.Add(s); s.thisown = 0


def arc(c, start, angle):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_ARC)
    s.SetLayer(pcbnew.Edge_Cuts); s.SetWidth(MM(EW)); s.SetCenter(V(*c)); s.SetStart(V(*start))
    s.SetArcAngleAndEnd(pcbnew.EDA_ANGLE(angle, pcbnew.DEGREES_T), True); board.Add(s); s.thisown = 0


T = [(c - TAB_W / 2, c + TAB_W / 2) for c in TABS]
W, H_ = 100.0, 100.0
NX = NODE_W
# outer loop, clockwise on screen: node top -> slot top -> handheld -> bottom -> node
seg((R, 0), (NX - R, 0)); arc((NX - R, R), (NX - R, 0), 90)            # node top-right corner
seg((NX, R), (NX, T[0][0]))                                               # node right edge down to tab 1
seg((NX, T[0][0]), (HX0, T[0][0]))                                        # tab 1 top
seg((HX0, T[0][0]), (HX0, R)); arc((HX0 + R, R), (HX0, R), 90)           # handheld left edge up, top-left corner
seg((HX0 + R, 0), (W - R, 0)); arc((W - R, R), (W - R, 0), 90)
seg((W, R), (W, H_ - R)); arc((W - R, H_ - R), (W, H_ - R), 90)
seg((W - R, H_), (HX0 + R, H_)); arc((HX0 + R, H_ - R), (HX0 + R, H_), 90)
seg((HX0, H_ - R), (HX0, T[2][1]))                                        # handheld left edge up to tab 3
seg((HX0, T[2][1]), (NX, T[2][1]))                                        # tab 3 bottom
seg((NX, T[2][1]), (NX, H_ - R)); arc((NX - R, H_ - R), (NX, H_ - R), 90)
seg((NX - R, H_), (R, H_)); arc((R, H_ - R), (R, H_), 90)
seg((0, H_ - R), (0, R)); arc((R, R), (0, R), 90)
# internal slots between the tabs (stadium shaped, 2 mm wide)
for (a, b) in ((T[0][1], T[1][0]), (T[1][1], T[2][0])):
    r = SLOT / 2
    cx = NX + r
    seg((NX, a + r), (NX, b - r)); arc((cx, b - r), (NX, b - r), -180)
    seg((HX0, b - r), (HX0, a + r)); arc((cx, a + r), (HX0, a + r), -180)

# mouse bites: one row of 5 x 0.5 mm NPTH per tab, 0.5 mm off the handheld edge
lib = os.path.abspath(os.path.join(HERE, "..", "MiniPC_v2.pretty"))
for i, c in enumerate(TABS):
    mb = pcbnew.FootprintLoad(lib, "MouseBites_5x0.5mm")
    mb.SetReference("MB%d" % (i + 1))
    mb.SetOrientationDegrees(90)
    mb.SetPosition(V(HX0 - 0.5, c))
    board.Add(mb); mb.thisown = 0

# ---------------------------------------------------------------- report
for ref in ("U1", "J2", "SW9", "J16", "J17"):
    f = FP[ref]
    print(ref, "pos", round(TOMM(f.GetPosition().x), 2), round(TOMM(f.GetPosition().y), 2), "rot", f.GetOrientationDegrees(), "crt", [round(v, 2) for v in crt_box(f)])
print("U1 pad1", pad_xy("U1", 1), "pad14", pad_xy("U1", 14), "pad27", pad_xy("U1", 27))
print("J2 A6", pad_xy("J2", "A6"), "J16 A6", pad_xy("J16", "A6"), "U9 pad9", pad_xy("U9", 9))
if WRITE:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
os.remove(TMP)
