"""Hand-drawn copper shared by route_prep.py and route_import.py (all of it LOCKED):
  * Kelvin sense traces of the 1 mohm shunt R17 (WSK2512, 4 terminals: pads 1 / 4 carry the current, pads 2 / 3 are the sense pads):
      IN+  pad 2 -> straight down -> INA180 (U10) pin 3, F.Cu
      IN-  pad 3 -> via -> B.Cu under the PACK+ pour -> via -> U10 pin 4
    They must never touch the PACK+ / ESC+ pours (that is what makes them Kelvin), so the autorouter never sees them on the real nets.
  * battery divider tap: R34 pad on PACK+ (back side) -> short B.Cu trace -> a PACK+ stitching via
  * MAX17048 (U3) VBAT pins 2 + 3: 0.25 mm neck-down stub so the 0.4 mm VBAT track can reach the 0.5 mm pitch pads
  * handheld LoRa feed: RFM95W U7 pad 9 -> u.FL J10, one straight 50 ohm B.Cu trace (+ the no-route area under U7, route_prep.py)
  * add_jumper_groups(): R17's pads 1+2 / 3+4 declared as one terminal each (text edit, the python API cannot)
Coordinates in mm (panel origin top-left, y down)."""
import pcbnew

MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))
rect = lambda x0, y0, x1, y1: [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]

PACK = rect(0.4, 65.9, 8.4, 75.1)          # J23 (PACK+) -> shunt pad 1, stays 0.3+ mm off sense pad 2
ESC = rect(11.6, 74.05, 19.6, 83.6)        # shunt pad 4 -> J24 (ESC+), stays off sense pad 3
STITCH_P = [(x, y) for y in (66.8, 68.2, 69.6, 70.9) for x in (6.6, 7.8)] + [(x, y) for y in (73.5, 74.5) for x in (2.6, 3.8, 5.0)]
STITCH_E = [(x, y) for y in (74.7, 75.9, 77.1) for x in (15.0, 16.3, 17.6, 18.9)] + \
           [(x, y) for y in (77.3, 78.6, 79.9, 81.2, 82.5) for x in (12.3, 13.6)] + [(x, 83.0) for x in (15.0, 16.3, 17.6, 18.9)]
SENSE_W = 0.25


def pad_obj(board, ref, num):
    return [p for p in board.FindFootprintByReference(ref).Pads() if p.GetNumber() == str(num)][0]


def pad(board, ref, num):
    p = pad_obj(board, ref, num)
    return TOMM(p.GetX()), TOMM(p.GetY())


def _existing(board, cls, net, pts, layer=None):
    """an identical track / via already on the board (the session brings some of them back): reuse it"""
    tol = MM(0.02)                                       # the session file rounds to 10 um
    near = lambda p, q: abs(p.x - q.x) <= tol and abs(p.y - q.y) <= tol
    for t in board.GetTracks():
        if t.GetClass() != cls or t.GetNetname() != net or (layer is not None and t.GetLayer() != layer):
            continue
        have = [t.GetPosition()] if cls == "PCB_VIA" else [t.GetStart(), t.GetEnd()]
        if len(have) == len(pts) and (all(near(h, p) for h, p in zip(have, pts)) or all(near(h, p) for h, p in zip(have, pts[::-1]))):
            t.SetLocked(True)
            return t
    return None


def dedupe(board):
    """delete tracks / vias that duplicate another item of the same net (same layer, ends within 0.02 mm); returns the count"""
    tol = MM(0.02)
    key = lambda p: (int(round(p.x / tol)), int(round(p.y / tol)))
    seen, dup = set(), []
    for t in board.GetTracks():
        if t.GetClass() == "PCB_VIA":
            k = ("v", t.GetNetname(), key(t.GetPosition()))
        else:
            a, b = sorted((key(t.GetStart()), key(t.GetEnd())))
            k = ("t", t.GetNetname(), t.GetLayer(), a, b)
        if k in seen:
            dup.append(t)
        else:
            seen.add(k)
    for t in dup:
        board.Delete(t)
    return len(dup)


def track(board, a, b, w, layer, net):
    old = _existing(board, "PCB_TRACK", net, (V(*a), V(*b)), layer)
    if old is not None:
        return old
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(V(*a)); t.SetEnd(V(*b)); t.SetWidth(MM(w)); t.SetLayer(layer); t.SetNet(board.FindNet(net)); t.SetLocked(True)
    board.Add(t); t.thisown = 0
    return t


def via(board, p, net, d=0.6, drill=0.3):
    old = _existing(board, "PCB_VIA", net, (V(*p),))
    if old is not None:
        return old
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(V(*p)); v.SetWidth(MM(d)); v.SetDrill(MM(drill)); v.SetNet(board.FindNet(net)); v.SetLocked(True)
    board.Add(v); v.thisown = 0
    return v


def add_sense(board):
    """the two Kelvin traces; returns {temporary net name: [pads, tracks, vias]} for the DSN export"""
    F, B = pcbnew.F_Cu, pcbnew.B_Cu
    p2, p3 = pad(board, "R17", 2), pad(board, "R17", 3)
    inp, inm = pad(board, "U10", 3), pad(board, "U10", 4)
    plus = [track(board, p2, (p2[0], inp[1]), SENSE_W, F, "/N_PACKP"),
            track(board, (p2[0], inp[1]), inp, SENSE_W, F, "/N_PACKP")]
    va = (p3[0], p3[1] - 1.13)
    vb = (1.4, inm[1] - 0.75)
    minus = [track(board, p3, va, SENSE_W, F, "/N_ESCP"), via(board, va, "/N_ESCP"),
             track(board, va, (vb[0], va[1]), SENSE_W, B, "/N_ESCP"), track(board, (vb[0], va[1]), vb, SENSE_W, B, "/N_ESCP"),
             via(board, vb, "/N_ESCP"), track(board, vb, inm, SENSE_W, F, "/N_ESCP")]
    return {"/N_SENSEP": plus + [pad_obj(board, "R17", 2), pad_obj(board, "U10", 3)],
            "/N_SENSEM": minus + [pad_obj(board, "R17", 3), pad_obj(board, "U10", 4)]}


def add_rf(board):
    """handheld LoRa feed: RFM95W (U7, back) pad 9 -> u.FL J10 pin 1, placed straight to its right: one 50 ohm B.Cu trace"""
    a, c = pad(board, "U7", 9), pad(board, "J10", 1)
    track(board, a, c, 0.3244, pcbnew.B_Cu, "/LORA_ANT")


def u7_keepout_rect(board):
    """area under the RFM95W (U7, back side) between its two pad columns: no tracks / vias on B.Cu, so nothing runs under the
    module or past its antenna pin (the autorouter had threaded MISO between the ANT and GND pads)"""
    f = board.FindFootprintByReference("U7")
    cx, cy = TOMM(f.GetX()), TOMM(f.GetY())
    return rect(cx - 5.75, cy - 8.0, cx + 5.75, cy + 8.0)


def add_buses(board):
    """node sensor plugs J19..J22 stand 3.95 mm apart with the same pin order, so their shared pins are straight rows:
    SDA = pin 1 (J20..J22), SCL = pin 2 (J20..J22), N_3V3 = pin 3 (J19..J22). Drawn on F.Cu before routing (the autorouter
    kept using the gaps between the plugs for other nets and then could not close these)."""
    rows = ((1, ("J20", "J21", "J22"), 0.25), (2, ("J20", "J21", "J22"), 0.25), (3, ("J19", "J20", "J21", "J22"), 0.4))
    for pin, refs, w in rows:
        pts = [pad(board, r, pin) for r in refs]
        net = pad_obj(board, refs[0], pin).GetNetname()
        assert all(pad_obj(board, r, pin).GetNetname() == net for r in refs), (pin, refs)
        for a, b in zip(pts, pts[1:]):
            track(board, a, b, w, pcbnew.F_Cu, net)


def add_others(board):
    add_rf(board)
    add_buses(board)
    # battery divider top (R34, back side) -> nearest PACK+ stitching via
    r34 = [pad(board, "R34", n) for n in (1, 2) if pad_obj(board, "R34", n).GetNetname() == "/N_PACKP"][0]
    tgt = min(STITCH_P, key=lambda v: (v[0] - r34[0]) ** 2 + (v[1] - r34[1]) ** 2)
    track(board, r34, tgt, 0.3, pcbnew.B_Cu, "/N_PACKP")
    # MAX17048 VBAT neck-down
    u3 = board.FindFootprintByReference("U3")
    lay = pcbnew.B_Cu if u3.IsFlipped() else pcbnew.F_Cu
    a2, a3 = pad(board, "U3", 2), pad(board, "U3", 3)
    xe = a2[0] + (-0.95 if a2[0] < TOMM(u3.GetX()) else 0.95)
    track(board, a2, (xe, a2[1]), 0.25, lay, "VBAT")
    track(board, a3, (xe, a3[1]), 0.25, lay, "VBAT")
    track(board, (xe, a2[1]), (xe, a3[1]), 0.25, lay, "VBAT")


def add_all(board):
    s = add_sense(board)
    add_others(board)
    return s


def add_jumper_groups(path, ref="R17", groups=(("1", "2"), ("3", "4"))):
    """text edit of the saved board: '(jumper_pad_groups ...)' on the shunt, so KiCad knows pads 1+2 and 3+4 are one terminal
    each (the Kelvin sense pads are deliberately NOT tied to the pours with copper). KiCad keeps it on later saves; the python
    API cannot set it. Run with the board saved and KiCad closed."""
    s = open(path, encoding="utf8").read()
    i = s.find('(property "Reference" "%s"' % ref)
    start = s.rfind("\n\t(footprint ", 0, i)
    end = s.find("\n\t(footprint ", i)
    end = len(s) if end < 0 else end
    if "jumper_pad_groups" in s[start:end]:
        return False
    key = "(duplicate_pad_numbers_are_jumpers no)"
    j = s.find(key, start, end)
    assert j > 0, "no '%s' in %s" % (key, ref)
    grp = " ".join("(%s)" % " ".join('"%s"' % n for n in g) for g in groups)
    s = s[:j + len(key)] + "\n\t\t(jumper_pad_groups %s)" % grp + s[j + len(key):]
    open(path, "w", encoding="utf8").write(s)
    return True
