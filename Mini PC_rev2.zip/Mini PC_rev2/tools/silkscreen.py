"""Silkscreen pass on the PCB (run with KiCad CLOSED, with KiCad's own python):
  - every part's Reference AND Value are printed on the silkscreen (1.0 mm / 0.15 mm), the Value being the short name from labels.json
    (UP, DOWN, LEFT, RIGHT, I2C A, CHARGER, ...), so the silkscreen says what a part is
  - headers / sockets get their pin names printed beside every pin (SDA SCL 3V3 GND ...) as text that belongs to the footprint
    (it moves and rotates with the part and survives 'Update PCB from Schematic')
Idempotent. Usage:  python silkscreen.py <pcb> [--write] [--reset-text-positions]       (without --write it only reports)
labels.json is written by add_parts.py."""
import json
import math
import os
import re
import shutil
import sys

import pcbnew

HERE = os.path.dirname(os.path.abspath(__file__))
PCB = next((a for a in sys.argv[1:] if not a.startswith("--")), os.path.join(HERE, "..", "MiniPC_v2.kicad_pcb"))
PCB = os.path.abspath(PCB)
WRITE = "--write" in sys.argv
RESET_POS = "--reset-text-positions" in sys.argv     # put Reference above / Value below each part (only for the first run: it overrides manual text moves)
labels = json.load(open(os.path.join(HERE, "labels.json"), encoding="utf8"))
MM = pcbnew.FromMM

_keep = pcbnew.LoadBoard(PCB)          # KiCad's python needs the board loaded twice before the second object is usable
board = pcbnew.LoadBoard(PCB)


def snapshot(b):
    snap = {}
    for fp in b.GetFootprints():
        snap[fp.GetReference()] = (str(fp.GetFPID().GetLibItemName()), {p.GetNumber() + "#" + str(i): p.GetNetname() for i, p in enumerate(fp.Pads())})
    return snap


before = snapshot(board)
board_poly = pcbnew.SHAPE_POLY_SET()
board_poly_ok = bool(board.GetBoardPolygonOutlines(board_poly, False)) and board_poly.OutlineCount() > 0
n_val = n_pin = n_removed = 0
for fp in board.GetFootprints():
    ref = fp.GetReference()
    if ref.startswith("MB") and fp.GetAttributes() & pcbnew.FP_BOARD_ONLY:     # mouse-bite perforations: no texts
        continue
    top = fp.GetLayer() == pcbnew.F_Cu
    silk = pcbnew.F_SilkS if top else pcbnew.B_SilkS
    lab = labels.get(ref)
    pad_list = list(fp.Pads())          # take the lists once: KiCad's python breaks iteration after a Remove()
    item_list = list(fp.GraphicalItems())
    if lab:
        fp.SetValue(lab["value"])
    passive = ref[:1] in ("R", "C") and ref[1:].isdigit() and re.match(r"^[RC]_(0402|0603|0805|1206)_", str(fp.GetFPID().GetLibItemName())) is not None
    for k_, fld in enumerate((fp.Reference(), fp.Value())):
        fld.SetLayer((pcbnew.F_Fab if top else pcbnew.B_Fab) if (passive and k_ == 1) else silk)       # SMD passives: only the reference is printed
        fld.SetVisible(True)
        fld.SetTextSize(pcbnew.VECTOR2I(MM(1.0), MM(1.0)))
        fld.SetTextThickness(MM(0.15))
    if RESET_POS:
        bb = fp.GetBoundingBox(False, False)
        cx = bb.GetCenter().x
        for fld, y in ((fp.Reference(), bb.GetTop() - MM(1.2)), (fp.Value(), bb.GetBottom() + MM(1.2))):
            fld.SetPosition(pcbnew.VECTOR2I(int(cx), int(y)))
            fld.SetTextAngle(pcbnew.EDA_ANGLE(0, pcbnew.DEGREES_T))
            fld.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_CENTER)
            fld.SetVertJustify(pcbnew.GR_TEXT_V_ALIGN_CENTER)
    n_val += 1
    pins = (lab or {}).get("pins") or {}
    if not pins:
        continue
    # drop pin-name texts from an earlier run (same text, on silkscreen) so the pass can be repeated
    for it in item_list:
        if isinstance(it, pcbnew.PCB_TEXT) and it.GetLayer() == silk and it.GetText() in pins.values() and it.GetText() not in ("${REFERENCE}", "${VALUE}"):
            fp.Remove(it)
            n_removed += 1
    pads = [p for p in pad_list if p.GetNumber() in pins]
    if not pads:
        continue
    theta = fp.GetOrientation().AsRadians()
    # local pad x (footprint frame): rotate the absolute offset back by the footprint orientation
    def local_x(p):
        d = p.GetPosition() - fp.GetPosition()
        return pcbnew.ToMM(d.x * math.cos(theta) - d.y * math.sin(theta))

    def local_y(p):
        d = p.GetPosition() - fp.GetPosition()
        return pcbnew.ToMM(d.x * math.sin(theta) + d.y * math.cos(theta))

    pitch = min([abs(a.GetPosition().y - b.GetPosition().y) + abs(a.GetPosition().x - b.GetPosition().x)
                 for a in pads for b in pads if a is not b] or [MM(2.54)])
    size = 0.8 if pcbnew.ToMM(pitch) < 2.0 else 1.0
    col_x = sorted({round(local_x(p), 2) for p in pad_list})
    mid = (col_x[0] + col_x[-1]) / 2.0
    if len(pad_list) >= 3 and len({round(local_y(p), 2) for p in pad_list}) == 1 and len(col_x) == len(pad_list):
        # one horizontal row of pads (the OLED module header): names run along the row, centred under each pad and just outside the
        # courtyard edge on the +y side (the module covers the pads, so the names stay readable once it is mounted)
        size = 1.0          # JLC / project minimum text height: 'VCC' is wider than the 2.54 pitch, so neighbours alternate between two levels
        cy_box = fp.GetCourtyard(pcbnew.F_CrtYd if top else pcbnew.B_CrtYd).BBox()
        corners = [(cy_box.GetLeft(), cy_box.GetTop()), (cy_box.GetRight(), cy_box.GetTop()),
                   (cy_box.GetLeft(), cy_box.GetBottom()), (cy_box.GetRight(), cy_box.GetBottom())]
        edge_y = max(pcbnew.ToMM((x - fp.GetPosition().x) * math.sin(theta) + (y - fp.GetPosition().y) * math.cos(theta)) for x, y in corners)
        row_y = local_y(pads[0])
        off = max(edge_y - row_y, 1.5) + 0.6
        ordered = sorted(pads, key=local_x)

        def level(k, base, sign):                   # stagger: even pads on the first level, odd pads one level further
            return sign * (base + (1.3 if k % 2 else 0.0))

        def spot(p, o):
            return p.GetPosition().x + MM(o) * math.sin(theta), p.GetPosition().y + MM(o) * math.cos(theta)

        # names go outside the courtyard, unless that is off the board or over the break-off slot / tabs: then on the module side of the pads
        sign, base = 1.0, off
        if board_poly_ok:
            for k, p in enumerate(ordered):
                x, y = spot(p, level(k, base, 1.0))
                if not all(board_poly.Contains(pcbnew.VECTOR2I(int(x + MM(d) * math.cos(theta)), int(y - MM(d) * math.sin(theta)))) for d in (-1.2, 0.0, 1.2)):
                    sign, base = -1.0, 1.65
                    break
        for k, p in enumerate(ordered):
            o = level(k, base, sign)
            dx, dy = MM(o) * math.sin(theta), MM(o) * math.cos(theta)
            t = pcbnew.PCB_TEXT(fp)
            t.SetText(pins[p.GetNumber()])
            t.SetLayer(silk)
            t.SetTextSize(pcbnew.VECTOR2I(MM(size), MM(size)))
            t.SetTextThickness(MM(0.15))
            t.SetPosition(pcbnew.VECTOR2I(int(p.GetPosition().x + dx), int(p.GetPosition().y + dy)))
            t.SetTextAngle(fp.GetOrientation())
            t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_CENTER)
            t.SetVertJustify(pcbnew.GR_TEXT_V_ALIGN_CENTER)
            fp.Add(t)
            n_pin += 1
        continue
    for p in pads:
        lx = local_x(p)
        right = True if len(col_x) == 1 else lx >= mid
        gap = 0.85 + pcbnew.ToMM(max(p.GetSize().x, p.GetSize().y)) / 2.0     # clears the header's own silkscreen outline (1.38 mm from the pin)
        off = gap if right else -gap
        dx, dy = MM(off) * math.cos(theta), -MM(off) * math.sin(theta)
        t = pcbnew.PCB_TEXT(fp)
        t.SetText(pins[p.GetNumber()])
        t.SetLayer(silk)
        t.SetTextSize(pcbnew.VECTOR2I(MM(size), MM(size)))
        t.SetTextThickness(MM(0.15 if size >= 1.0 else 0.12))
        t.SetPosition(pcbnew.VECTOR2I(int(p.GetPosition().x + dx), int(p.GetPosition().y + dy)))
        t.SetTextAngle(fp.GetOrientation())
        t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_LEFT if right else pcbnew.GR_TEXT_H_ALIGN_RIGHT)
        t.SetVertJustify(pcbnew.GR_TEXT_V_ALIGN_CENTER)
        fp.Add(t)
        n_pin += 1

print(f"{PCB}\n  footprints: {len(before)}; value+reference on silkscreen: {n_val}; pin-name texts added: {n_pin} (replaced {n_removed} older ones)")
if WRITE:
    pro = os.path.splitext(PCB)[0] + ".kicad_pro"
    bak = {f: open(f, "rb").read() for f in (pro,) if os.path.exists(f)}
    pcbnew.SaveBoard(PCB, board)
    for f, data in bak.items():                       # SaveBoard rewrites the project file: put the user's settings back
        open(f, "wb").write(data)
    after = snapshot(pcbnew.LoadBoard(PCB))
    same = before == after
    print("  saved; footprints / footprint ids / pad nets unchanged:", same)
    if not same:
        sys.exit("MISMATCH after save")
