"""Tiny KiCad 10 schematic writer: embeds library symbols, places parts, connects pins with
net labels / power symbols / wires. Everything is deterministic (stable UUIDs)."""
import re
import uuid
from kicadsym import raw_symbol, pins as sym_pins, _balanced

PROJECT = "MiniPC_v2"
ROOT_UUID = str(uuid.uuid5(uuid.NAMESPACE_URL, PROJECT + "/root"))
CUSTOM_LIB = "MiniPC_v2"

POWER_NETS = {  # net name -> (power lib symbol, arrow direction for stubs)
    "GND": "power:GND",
    "+3V3": "power:+3V3",
    "VBUS": "power:+5V",
    "VSYS": "power:+5V",
    "VBAT": "power:+5V",
    "VBAT_RTC": "power:+5V",
}

QUIET = False
_uid = [0]


def uid(tag=""):
    _uid[0] += 1
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"{PROJECT}/{_uid[0]}/{tag}"))


def f(v):
    s = f"{v:.4f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def snap(v, g=2.54):
    return round(round(v / g) * g, 4)


# ------------------------------------------------------------------ symbols
def _prop_val(block, name):
    m = re.search(r'\(property "%s" "((?:[^"\\]|\\.)*)"' % re.escape(name), block)
    return m.group(1) if m else None


def _flatten(lib, name):
    block = raw_symbol(lib, name)
    ext = re.search(r'\(extends "([^"]*)"\)', block)
    if not ext:
        return block
    parent = _flatten(lib, ext.group(1))
    pname = ext.group(1)
    merged = parent.replace(f'(symbol "{pname}"', f'(symbol "{name}"', 1)
    merged = re.sub(r'\(symbol "%s_(\d+_\d+)"' % re.escape(pname), r'(symbol "%s_\1"' % name, merged)
    for prop in ("Value", "Footprint", "Datasheet", "Description", "ki_keywords"):
        v = _prop_val(block, prop)
        if v is not None:
            merged = re.sub(r'(\(property "%s" ")((?:[^"\\]|\\.)*)(")' % prop,
                            lambda m: m.group(1) + v.replace("\\", "\\\\") + m.group(3), merged, count=1)
    return merged


class Sym:
    def __init__(self, libid, text=None):
        self.libid = libid
        lib, name = libid.split(":", 1)
        block = text if text is not None else _flatten(lib, name)
        self.block = block.replace(f'(symbol "{name}"', f'(symbol "{libid}"', 1)
        self.pins = sym_pins(block)
        self.fp = _prop_val(block, "Footprint") or ""
        self.desc = _prop_val(block, "Description") or ""
        self.ref_prefix = _prop_val(block, "Reference") or "U"
        self.value = _prop_val(block, "Value") or name

        def pos(prop):
            m = re.search(r'\(property "%s" "[^"]*"\s*\(at ([-\d.]+) ([-\d.]+) ([-\d.]+)\)' % prop, block)
            return (float(m.group(1)), float(m.group(2)), float(m.group(3))) if m else (0, 0, 0)
        self.ref_pos, self.val_pos = pos("Reference"), pos("Value")

    def lib_block(self):
        return "\n".join("\t\t" + l for l in self.block.split("\n"))


_symcache = {}
CUSTOM = {}


def sym(libid):
    if libid not in _symcache:
        if libid.startswith(CUSTOM_LIB + ":"):
            _symcache[libid] = Sym(libid, CUSTOM[libid])
        else:
            _symcache[libid] = Sym(libid)
    return _symcache[libid]


# ------------------------------------------------------------------ schematic
class Schematic:
    def __init__(self, paper="A1"):
        self.paper = paper
        self.items = []      # body text chunks
        self.libs = {}
        self.refs = {}       # prefix -> counter
        self.pwr = 0
        self.points = {}     # (x,y) -> net, for sanity

    # ---- low level emitters
    def _lib(self, libid):
        s = sym(libid)
        self.libs[libid] = s
        return s

    def prop(self, name, value, x, y, a=0, hide=False, extra=""):
        value = value.replace("\\", "\\\\").replace('"', '\\"')
        return (f'\t\t(property "{name}" "{value}"\n\t\t\t(at {f(x)} {f(y)} {a})\n'
                + ("\t\t\t(hide yes)\n" if hide else "")
                + '\t\t\t(show_name no)\n\t\t\t(do_not_autoplace no)\n\t\t\t(effects\n\t\t\t\t(font\n\t\t\t\t\t(size 1.27 1.27)\n\t\t\t\t)\n'
                + extra + "\t\t\t)\n\t\t)\n")

    def next_ref(self, prefix):
        self.refs[prefix] = self.refs.get(prefix, 0) + 1
        return f"{prefix}{self.refs[prefix]}"

    def reserve(self, ref):
        m = re.match(r"([A-Za-z#]+)(\d+)$", ref)
        if m:
            self.refs[m.group(1)] = max(self.refs.get(m.group(1), 0), int(m.group(2)))

    def label(self, net, x, y, angle):
        just = "left bottom" if angle in (0, 90) else "right bottom"
        self.items.append(
            f'\t(label "{net}"\n\t\t(at {f(x)} {f(y)} {angle})\n\t\t(effects\n\t\t\t(font\n\t\t\t\t(size 1.27 1.27)\n\t\t\t)\n'
            f'\t\t\t(justify {just})\n\t\t)\n\t\t(uuid "{uid("label")}")\n\t)\n')

    def wire(self, x1, y1, x2, y2):
        self.items.append(
            f'\t(wire\n\t\t(pts\n\t\t\t(xy {f(x1)} {f(y1)}) (xy {f(x2)} {f(y2)})\n\t\t)\n\t\t(stroke\n\t\t\t(width 0)\n'
            f'\t\t\t(type default)\n\t\t)\n\t\t(uuid "{uid("wire")}")\n\t)\n')

    def noconnect(self, x, y):
        self.items.append(f'\t(no_connect\n\t\t(at {f(x)} {f(y)})\n\t\t(uuid "{uid("nc")}")\n\t)\n')

    def text(self, s, x, y, size=2.54, bold=False):
        self.items.append(
            f'\t(text "{s}"\n\t\t(exclude_from_sim no)\n\t\t(at {f(x)} {f(y)} 0)\n\t\t(effects\n\t\t\t(font\n\t\t\t\t(size {size} {size})\n'
            + ("\t\t\t\t(bold yes)\n" if bold else "") + f'\t\t\t)\n\t\t\t(justify left bottom)\n\t\t)\n\t\t(uuid "{uid("text")}")\n\t)\n')

    def box(self, x1, y1, x2, y2):
        self.items.append(
            f'\t(rectangle\n\t\t(start {f(x1)} {f(y1)})\n\t\t(end {f(x2)} {f(y2)})\n\t\t(stroke\n\t\t\t(width 0.1524)\n'
            f'\t\t\t(type dash)\n\t\t)\n\t\t(fill\n\t\t\t(type none)\n\t\t)\n\t\t(uuid "{uid("box")}")\n\t)\n')

    # ---- power symbols
    def power(self, net, x, y):
        lib = POWER_NETS[net]
        s = self._lib(lib)
        self.pwr += 1
        ref = f"#PWR{self.pwr:03d}"
        self.items.append(self._instance(s, lib, ref, net, x, y, "", power=True))

    def pwrflag(self, net, x, y):
        x, y = snap(x), snap(y)
        s = self._lib("power:PWR_FLAG")
        self.pwr += 1
        ref = f"#FLG{self.pwr:03d}"
        self.items.append(self._instance(s, "power:PWR_FLAG", ref, "PWR_FLAG", x, y, "", power=True))
        self.label(net, x, y, 90)   # name the net it sits on

    def _instance(self, s, libid, ref, value, x, y, footprint, power=False, extra_props=None):
        out = [f'\t(symbol\n\t\t(lib_id "{libid}")\n\t\t(at {f(x)} {f(y)} 0)\n\t\t(unit 1)\n\t\t(body_style 1)\n'
               f'\t\t(exclude_from_sim no)\n\t\t(in_bom {"no" if power else "yes"})\n\t\t(on_board {"no" if power else "yes"})\n'
               f'\t\t(in_pos_files {"no" if power else "yes"})\n\t\t(dnp no)\n\t\t(uuid "{uid(ref)}")\n']
        rx, ry, ra = s.ref_pos
        vx, vy, va = s.val_pos
        out.append(self.prop("Reference", ref, x + rx, y - ry, int(ra), hide=power))
        out.append(self.prop("Value", value, x + vx, y - vy, int(va), hide=False))
        out.append(self.prop("Footprint", footprint, x, y, 0, hide=True))
        out.append(self.prop("Datasheet", "", x, y, 0, hide=True))
        out.append(self.prop("Description", s.desc, x, y, 0, hide=True))
        for k, v in (extra_props or {}).items():
            out.append(self.prop(k, v, x, y, 0, hide=True))
        for n in s.pins:
            out.append(f'\t\t(pin "{n}"\n\t\t\t(uuid "{uid(ref + n)}")\n\t\t)\n')
        out.append(f'\t\t(instances\n\t\t\t(project "{PROJECT}"\n\t\t\t\t(path "/{ROOT_UUID}"\n\t\t\t\t\t(reference "{ref}")\n'
                   f'\t\t\t\t\t(unit 1)\n\t\t\t\t)\n\t\t\t)\n\t\t)\n\t)\n')
        return "".join(out)

    # ---- parts
    def pin_xy(self, libid, x, y, num):
        p = sym(libid).pins[num]
        return round(x + p["x"], 4), round(y - p["y"], 4), p

    def place(self, libid, x, y, nets=None, ref=None, value=None, fp=None, extra=None, stub=0.0, wired=()):
        """Place a symbol and attach nets. nets: {pin_number: net | 'NC'}. Returns ref."""
        s = self._lib(libid)
        x, y = snap(x), snap(y)
        ref = ref or self.next_ref(s.ref_prefix.rstrip("?"))
        self.reserve(ref)
        self.items.append(self._instance(s, libid, ref, value or s.value, x, y, fp if fp is not None else s.fp, extra_props=extra))
        covered = set()
        for num, net in (nets or {}).items():
            px, py, p = self.pin_xy(libid, x, y, num)
            covered.add((px, py))
            self.attach(net, px, py, (p["angle"] + 180) % 360, stub)
        if QUIET:
            return ref
        # report any visible pin whose point is not covered
        for num, p in s.pins.items():
            pt = (round(x + p["x"], 4), round(y - p["y"], 4))
            if pt not in covered and not p["hide"] and num not in wired:
                print(f"  WARN {ref} ({libid}) pin {num} {p['name']} not connected")
        return ref

    def attach(self, net, px, py, out_angle, stub=0.0):
        if net == "NC":
            self.noconnect(px, py)
            return
        if net == "~":
            return
        ex, ey = px, py
        if stub:
            dx = {0: 1, 180: -1}.get(out_angle, 0) * stub
            dy = {90: -1, 270: 1}.get(out_angle, 0) * stub
            ex, ey = round(px + dx, 4), round(py + dy, 4)
            self.wire(px, py, ex, ey)
        if net in POWER_NETS and self._power_ok(net, out_angle):
            self.power(net, ex, ey)
        else:
            self.label(net, ex, ey, out_angle)

    @staticmethod
    def _power_ok(net, out_angle):
        # power symbols only on vertical pins (up for rails, down for GND); labels elsewhere
        if net == "GND":
            return out_angle == 270
        return out_angle == 90

    # ---- passives
    def two_pin(self, libid, value, fp, x, y, top, bottom, ref=None, **kw):
        s = sym(libid)
        nets = {"1": top, "2": bottom}
        return self.place(libid, x, y, nets, ref=ref, value=value, fp=fp, **kw)

    # ---- output
    def render(self, path):
        head = ('(kicad_sch\n\t(version 20260306)\n\t(generator "eeschema")\n\t(generator_version "10.0")\n'
                f'\t(uuid "{ROOT_UUID}")\n\t(paper "{self.paper}")\n\t(lib_symbols\n')
        libs = "\n".join(s.lib_block() for _, s in sorted(self.libs.items()))
        tail = ('\n\t)\n' + "".join(self.items)
                + '\t(sheet_instances\n\t\t(path "/"\n\t\t\t(page "1")\n\t\t)\n\t)\n\t(embedded_fonts no)\n)\n')
        with open(path, "w", encoding="utf8", newline="\n") as fh:
            fh.write(head + libs + tail)
