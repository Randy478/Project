"""Create MiniPC_v2.kicad_pcb from the schematic netlist: rev-1 outline (80.5 x 90.0 mm, sharp corners), 4 copper layers,
every footprint WITH its nets, parked to the right of the board in labelled groups (nothing placed, routed or poured).
Run with KiCad python:  python.exe gen_pcb_v2.py      then:  python gen_rules_v2.py   (saving the board resets the .kicad_pro)"""
import os
import subprocess
import sys

import pcbnew

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from sexp import parse, child, children

ROOT = os.path.abspath(os.path.join(HERE, ".."))
KICAD = os.path.expandvars(r"%LOCALAPPDATA%\Programs\KiCad\10.0")
FPDIR = os.path.join(KICAD, "share", "kicad", "footprints")
KCLI = os.path.join(KICAD, "bin", "kicad-cli.exe")
BW, BH = 80.5, 90.0
mm, tomm = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(mm(x), mm(y))

GROUPS = [
    ("MCU", ["U1"]),
    ("USB-C + power (USB 5V -> D1 -> AMS1117 -> 3V3)", ["J2", "D1", "U2", "C1", "C2", "C3", "R1", "R2", "R3", "R6"]),
    ("Display / RTC / expansion headers", ["Brd1", "J4", "J1", "J3"]),
    ("Buttons", ["SW3", "SW4", "SW5", "SW6", "SW7", "SW8", "SW1", "SW2"]),
    ("Buzzer + pull-ups", ["BZ1", "R4", "R5"]),
]
_extra = os.path.join(HERE, "parts_groups.json")          # written by add_parts.py: the 'go wild' additions
if os.path.exists(_extra):
    import json
    GROUPS += [(k, v) for k, v in json.load(open(_extra, encoding="utf8")).items()]


def load():
    net = os.path.join(ROOT, "MiniPC_v2.net")
    subprocess.run([KCLI, "sch", "export", "netlist", "--format", "kicadsexpr", "--output", net,
                    os.path.join(ROOT, "MiniPC_v2.kicad_sch")], check=True, capture_output=True)
    tree = parse(open(net, encoding="utf8").read())
    comps = {}
    for c in children(child(tree, "components"), "comp"):
        ts = child(c, "tstamps")
        comps[child(c, "ref")[1]] = dict(value=child(c, "value")[1], fp=child(c, "footprint")[1], uuid=ts[1] if ts else "")
    pad_net = {}
    for n in children(child(tree, "nets"), "net"):
        name = child(n, "name")[1]
        for nd in children(n, "node"):
            pad_net[(child(nd, "ref")[1], child(nd, "pin")[1])] = name
    return comps, pad_net


board = pcbnew.BOARD()
board.SetCopperLayerCount(4)
nets = {}


def get_net(name):
    if name not in nets:
        ni = pcbnew.NETINFO_ITEM(board, name)
        board.Add(ni)
        nets[name] = ni
    return nets[name]


def edge(x1, y1, x2, y2):
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(V(x1, y1))
    s.SetEnd(V(x2, y2))
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(mm(0.05))
    board.Add(s)


def note(text, x, y, size=2.0):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(V(x, y))
    t.SetLayer(pcbnew.Cmts_User)
    t.SetTextSize(pcbnew.VECTOR2I(mm(size), mm(size)))
    t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_LEFT)
    board.Add(t)


def main():
    comps, pad_net = load()
    fps = {}
    for ref, c in comps.items():
        lib, name = c["fp"].split(":", 1)
        fp = pcbnew.FootprintLoad(os.path.join(FPDIR, lib + ".pretty"), name)
        if fp is None:
            raise RuntimeError("footprint not found: " + c["fp"])
        fp.SetReference(ref)
        fp.SetValue(c["value"])
        if c["uuid"]:
            fp.SetPath(pcbnew.KIID_PATH("/" + c["uuid"].lstrip("/")))
        for p in fp.Pads():
            n = pad_net.get((ref, p.GetNumber()))
            if n and not n.startswith("unconnected-"):   # the schematic has no connections: pads stay net-less
                p.SetNet(get_net(n))
        board.Add(fp)
        fps[ref] = fp

    edge(0, 0, BW, 0)
    edge(BW, 0, BW, BH)
    edge(BW, BH, 0, BH)
    edge(0, BH, 0, 0)
    note("Rev 1 outline %.1f x %.1f mm - 4 layers. Parts are parked to the right; nothing is placed yet." % (BW, BH), 0, -6, 1.8)

    placed = set()
    x0, y = BW + 15, 0.0
    for title, refs in GROUPS:
        note(title, x0, y - 3, 2.2)
        cx, row_h, row_w_max = x0, 0.0, 130.0
        for ref in refs:
            if ref not in fps:
                continue
            f = fps[ref]
            f.SetPosition(V(0, 0))
            bb = f.GetBoundingBox(False)
            w, h = tomm(bb.GetWidth()) + 3.0, tomm(bb.GetHeight()) + 3.0
            if cx + w > x0 + row_w_max:
                cx, y, row_h = x0, y + row_h, 0.0
            # place so the footprint's bounding box top-left sits at (cx, y)
            ox, oy = tomm(bb.GetLeft()), tomm(bb.GetTop())
            f.SetPosition(V(cx - ox + 1.5, y - oy + 1.5))
            cx += w
            row_h = max(row_h, h)
            placed.add(ref)
        y += row_h + 10.0
    missing = set(fps) - placed
    assert not missing, "ungrouped parts: %s" % sorted(missing)

    out = os.path.join(ROOT, "MiniPC_v2.kicad_pcb")
    pcbnew.SaveBoard(out, board)
    print("wrote", out, "-", len(fps), "footprints,", len(nets), "nets, 4 copper layers")


main()
