"""Round the corners of the board outline (Edge.Cuts rectangle -> 4 lines + 4 arcs). Run with KiCad CLOSED, KiCad's own python:
    python round_corners.py <pcb> [radius_mm] [--write]
Idempotent: it rebuilds the outline from the bounding box of the existing Edge.Cuts lines / arcs (other Edge.Cuts shapes are kept)."""
import math
import os
import sys

import pcbnew

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0])
R = float(args[1]) if len(args) > 1 else 3.0
WRITE = "--write" in sys.argv
MM = pcbnew.FromMM
V = lambda x, y: pcbnew.VECTOR2I(int(MM(x)), int(MM(y)))

_keep = pcbnew.LoadBoard(PCB)      # KiCad's python needs the board loaded twice
board = pcbnew.LoadBoard(PCB)
edge = [d for d in list(board.GetDrawings()) if d.GetLayer() == pcbnew.Edge_Cuts and d.GetShape() in (pcbnew.SHAPE_T_SEGMENT, pcbnew.SHAPE_T_ARC)]
if not edge:
    sys.exit("no Edge.Cuts outline found")
if len(edge) > 8:
    sys.exit("the outline has more than one rectangle (break-off board, see make_breakoff.py): rebuilding it from its bounding box would destroy that")
xs, ys = [], []
for d in edge:
    for p in (d.GetStart(), d.GetEnd()):
        xs.append(pcbnew.ToMM(p.x))
        ys.append(pcbnew.ToMM(p.y))
x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
w = pcbnew.ToMM(edge[0].GetWidth())
print(f"outline {x1 - x0:.2f} x {y1 - y0:.2f} mm at ({x0:.2f}, {y0:.2f}); {len(edge)} line/arc pieces -> radius {R} mm, line width {w:.2f}")
if R * 2 >= min(x1 - x0, y1 - y0):
    sys.exit("radius too large")
for d in edge:
    board.Remove(d)


def shape(kind):
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(kind)
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(MM(w))
    board.Add(s)
    return s


def line(ax, ay, bx, by):
    s = shape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(V(ax, ay))
    s.SetEnd(V(bx, by))


def arc(cx, cy, sx, sy, ex, ey, mdx, mdy):
    s = shape(pcbnew.SHAPE_T_ARC)
    k = math.sqrt(0.5) * R
    s.SetArcGeometry(V(sx, sy), V(cx + mdx * k, cy + mdy * k), V(ex, ey))


line(x0 + R, y0, x1 - R, y0)           # top
line(x1, y0 + R, x1, y1 - R)           # right
line(x1 - R, y1, x0 + R, y1)           # bottom
line(x0, y1 - R, x0, y0 + R)           # left
arc(x0 + R, y0 + R, x0, y0 + R, x0 + R, y0, -1, -1)           # top-left
arc(x1 - R, y0 + R, x1 - R, y0, x1, y0 + R, 1, -1)            # top-right
arc(x1 - R, y1 - R, x1, y1 - R, x1 - R, y1, 1, 1)              # bottom-right
arc(x0 + R, y1 - R, x0 + R, y1, x0, y1 - R, -1, 1)            # bottom-left

if WRITE:
    pro = os.path.splitext(PCB)[0] + ".kicad_pro"
    bak = open(pro, "rb").read() if os.path.exists(pro) else None
    pcbnew.SaveBoard(PCB, board)
    if bak is not None:
        open(pro, "wb").write(bak)          # SaveBoard rewrites the project file: put the user's settings back
    chk = pcbnew.LoadBoard(PCB)
    parts = [d for d in chk.GetDrawings() if d.GetLayer() == pcbnew.Edge_Cuts]
    kinds = sorted(str(d.GetShapeStr()) for d in parts)
    bb = chk.GetBoardEdgesBoundingBox()
    print("  saved:", kinds, f"| bbox {pcbnew.ToMM(bb.GetWidth()):.2f} x {pcbnew.ToMM(bb.GetHeight()):.2f} mm")
