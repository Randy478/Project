"""JLCPCB 4-layer design rules for the project: via sizes, track widths, net classes, fab-safe minimums and the JLC04161H-7628 stackup.
Run with KiCad CLOSED:   python set_jlc_rules.py <project folder or .kicad_pro>        (idempotent, rewrites only what it owns)

Numbers (JLCPCB multilayer capabilities, 1 oz outer copper):
  min track / space 0.09 mm (we keep >= 0.1 / 0.15), min via 0.45 mm pad / 0.2 mm drill (4+ layers), standard via 0.6 / 0.3 mm,
  silkscreen text >= 1.0 mm high, 0.15 mm stroke, copper to board edge >= 0.2 mm (0.3 mm recommended; the rev-1 ESP32 pads sit at 0.23 mm).
  JLC04161H-7628 (1.6 mm, 7628 prepreg 0.2104 mm over L2): 50 ohm single-ended = 0.3244 mm, 90 ohm differential = 0.2332 mm wide, 0.15 mm gap."""
import json
import os
import sys

arg = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
arg = os.path.abspath(arg)
PRO = arg if arg.endswith(".kicad_pro") else os.path.join(arg, "MiniPC_v2.kicad_pro")
PCB = PRO[:-len(".kicad_pro")] + ".kicad_pcb"

p = json.load(open(PRO, encoding="utf8"))
ds = p["board"]["design_settings"]

# ---- fab minimums ----------------------------------------------------------------------------------------------
ds["rules"].update({
    "min_clearance": 0.1, "min_track_width": 0.1,
    "min_via_diameter": 0.45, "min_through_hole_diameter": 0.2, "min_via_annular_width": 0.125,
    "min_copper_edge_clearance": 0.2, "min_hole_clearance": 0.15,
    "min_text_height": 1.0, "min_text_thickness": 0.15, "min_silk_clearance": 0.15,
})
ds["defaults"].update({"silk_line_width": 0.15, "silk_text_thickness": 0.15, "silk_text_size_h": 1.0, "silk_text_size_v": 1.0})

# ---- sizes you can pick while routing ---------------------------------------------------------------------------------
ds["track_widths"] = [0.0, 0.15, 0.2, 0.2332, 0.3, 0.3244, 0.5, 0.8, 1.0, 2.0, 3.0]
ds["via_dimensions"] = [{"diameter": 0.0, "drill": 0.0},
                        {"diameter": 0.6, "drill": 0.3},      # JLC standard via (default)
                        {"diameter": 0.45, "drill": 0.2},     # JLC minimum via for 4 layers (dense areas)
                        {"diameter": 0.8, "drill": 0.4}]      # power / stitching
ds["diff_pair_dimensions"] = [{"gap": 0.0, "via_gap": 0.0, "width": 0.0},
                              {"gap": 0.15, "via_gap": 0.25, "width": 0.2332}]   # 90 ohm USB on JLC04161H-7628

# ---- net classes ------------------------------------------------------------------------------------------------------
ns = p["net_settings"]
template = dict(ns["classes"][0])


def cls(name, track, clearance, via_d, via_drill, prio, dp_w=0.2, dp_gap=0.15):
    c = dict(template)
    c.update({"name": name, "track_width": track, "clearance": clearance, "via_diameter": via_d, "via_drill": via_drill,
              "priority": prio, "diff_pair_width": dp_w, "diff_pair_gap": dp_gap, "diff_pair_via_gap": 0.25})
    return c


ns["classes"] = [
    cls("Default", 0.2, 0.15, 0.6, 0.3, 2147483647),
    cls("Power", 0.5, 0.2, 0.8, 0.4, 3),
    cls("HighCurrent", 3.0, 0.3, 0.8, 0.4, 1),
    cls("USB", 0.2332, 0.2, 0.6, 0.3, 2, 0.2332, 0.15),
    cls("RF", 0.3244, 0.3, 0.6, 0.3, 0),
]
members = {
    "Power": ["+3V3", "GND", "VBAT", "VBUS", "/VBUSF", "/VBSW", "/VIN", "/BATN", "/LED3V3", "/GPS3V3",
              "/N_5V", "/N_3V3", "/N_GND", "/N_USBV", "/N_BEC"],
    "HighCurrent": ["/N_PACKP", "/N_ESCP"],
    "USB": ["/USB_DM", "/USB_DP", "/USB_DMC", "/USB_DPC", "/N_DM", "/N_DP", "/N_DMC", "/N_DPC"],
    "RF": ["/LORA_ANT", "/N_ANT"],
}
ns["netclass_patterns"] = [{"netclass": c, "pattern": n} for c, names in members.items() for n in names]

with open(PRO, "w", encoding="utf8", newline="\n") as f:
    json.dump(p, f, indent=2, ensure_ascii=False)
    f.write("\n")
print("project rules written:", PRO)

# ---- stackup (text insert into the .kicad_pcb setup block; only if it has none yet) --------------------------------------
STACK = '''		(stackup
			(layer "F.SilkS"
				(type "Top Silk Screen")
			)
			(layer "F.Paste"
				(type "Top Solder Paste")
			)
			(layer "F.Mask"
				(type "Top Solder Mask")
				(thickness 0.01)
			)
			(layer "F.Cu"
				(type "copper")
				(thickness 0.035)
			)
			(layer "dielectric 1"
				(type "prepreg")
				(thickness 0.2104)
				(material "7628")
				(epsilon_r 4.6)
				(loss_tangent 0.02)
			)
			(layer "In1.Cu"
				(type "copper")
				(thickness 0.0152)
			)
			(layer "dielectric 2"
				(type "core")
				(thickness 1.065)
				(material "FR4")
				(epsilon_r 4.6)
				(loss_tangent 0.02)
			)
			(layer "In2.Cu"
				(type "copper")
				(thickness 0.0152)
			)
			(layer "dielectric 3"
				(type "prepreg")
				(thickness 0.2104)
				(material "7628")
				(epsilon_r 4.6)
				(loss_tangent 0.02)
			)
			(layer "B.Cu"
				(type "copper")
				(thickness 0.035)
			)
			(layer "B.Mask"
				(type "Bottom Solder Mask")
				(thickness 0.01)
			)
			(layer "B.Paste"
				(type "Bottom Solder Paste")
			)
			(layer "B.SilkS"
				(type "Bottom Silk Screen")
			)
			(copper_finish "None")
			(dielectric_constraints no)
		)
'''
if os.path.exists(PCB):
    t = open(PCB, encoding="utf8").read()
    if "(stackup" in t:
        print("stackup already present: left alone")
    else:
        i = t.index("\t(setup\n") + len("\t(setup\n")
        open(PCB, "w", encoding="utf8", newline="\n").write(t[:i] + STACK + t[i:])
        print("JLC04161H-7628 stackup added to", PCB)
