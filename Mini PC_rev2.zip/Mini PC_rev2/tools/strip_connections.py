"""Remove every connection from MiniPC_v2.kicad_sch: all wires, junctions, labels, no-connect flags and buses.
Symbols (with their reference/value fields), texts and the library stay exactly where they are. Idempotent.
Pipeline that produced this project:  prune_j56.py -> localize_libs.py -> strip_connections.py  (see README)."""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from sexp import balanced_end

SCH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "MiniPC_v2.kicad_sch"))
KILL = {"wire", "junction", "label", "global_label", "hierarchical_label", "no_connect", "bus", "bus_entry",
        "directive_label", "netclass_flag"}

text = open(SCH, encoding="utf8").read()
root = text.index("(kicad_sch")
i = text.index("\n\t(", root) + 1
spans, counts = [], {}
while i < len(text):
    while i < len(text) and text[i] in " \t\r\n":
        i += 1
    if i >= len(text) or text[i] != "(":
        break
    e = balanced_end(text, i)
    head = text[i + 1:i + 40].split()[0].rstrip(")")
    if head in KILL:
        spans.append((i, e))
        counts[head] = counts.get(head, 0) + 1
    i = e
out = text
for s, e in sorted(spans, reverse=True):
    ls = out.rfind("\n", 0, s) + 1
    le = out.find("\n", e) + 1
    out = out[:ls] + out[le:]
open(SCH, "w", encoding="utf8", newline="\n").write(out)
print("removed:", counts or "nothing (already stripped)")
