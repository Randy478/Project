import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from sexp import parse, child, children, props

SRC = r"D:\Projects\Mini PC\Mini PC.kicad_sch"
tree = parse(open(SRC, encoding="utf8").read())
cnt = {}
syms = []
for n in tree:
    if isinstance(n, list) and n:
        cnt[n[0]] = cnt.get(n[0], 0) + 1
        if n[0] == "symbol" and child(n, "lib_id"):
            p = props(n)
            at = child(n, "at")
            syms.append((p.get("Reference"), p.get("Value"), child(n, "lib_id")[1], p.get("Footprint"), float(at[1]), float(at[2])))
print({k: v for k, v in cnt.items() if k in ("symbol", "wire", "junction", "label", "global_label", "no_connect", "text", "bus", "sheet")})
for s in sorted(syms, key=lambda x: (re.sub(r"\d", "", x[0] or ""), x[0] or "")):
    print(s)
print("root uuid:", child(tree, "uuid")[1], "| paper:", child(tree, "paper")[1], "| version:", child(tree, "version")[1])
for n in tree:
    if isinstance(n, list) and n and n[0] in ("text", "label", "global_label"):
        print(n[0].upper(), n[1][:70])
