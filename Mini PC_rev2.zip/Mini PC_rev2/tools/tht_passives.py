"""Rev-1 look for the handheld (4 Oct 2026): the passives that show on the front, below the screen, become through-hole like the
first Mini PC - resistors lying flat (axial, 10.16 mm), 100 nF ceramic discs, 1-10 uF 5 mm radial electrolytics. The ones hidden
under the screen (soldered straight on, ~2.5 mm gap) or on the back next to the plug-in modules / radios stay 1206 SMD.
KiCad CLOSED, KiCad's python:
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\tht_passives.py [--sch] [--pcb <board> ...] [--black <board> ...]
  --sch    sets the Footprint field of those symbols in MiniPC_v2.kicad_sch
  --pcb    swaps the footprints on each board (nets, schematic link, fields and position kept)
  --black  black solder mask + white silkscreen in the board's stack-up (renders, and the colour to pick when ordering)
Electrolytics are polarised (pad 1 = +): every one converted here has its positive net on pin 1 (checked: C1, C4, C20 = 3V3 rails,
C35 = EN); C3 (GND on pin 1) stays SMD."""
import os
import re
import sys

import pcbnew

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SCH = os.path.join(ROOT, "MiniPC_v2.kicad_sch")
FPROOT = os.path.join(os.environ["LOCALAPPDATA"], "Programs", "KiCad", "10.0", "share", "kicad", "footprints")
R_AX = "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal"
C_DISC = "Capacitor_THT:C_Disc_D3.8mm_W2.6mm_P2.50mm"
C_EL = "Capacitor_THT:CP_Radial_D5.0mm_P2.50mm"
MAP = {r: R_AX for r in ("R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R10", "R11", "R12", "R13", "R14", "R16")}
MAP.update({c: C_DISC for c in ("C2", "C5", "C14", "C18", "C19")})
MAP.update({c: C_EL for c in ("C1", "C4", "C20", "C35")})
POSITIVE_PIN1 = ("C1", "C4", "C20", "C35")


def block_after(s, i):
    d, j = 0, i
    while True:
        d += s[j] == "("; d -= s[j] == ")"; j += 1
        if d == 0:
            return j


def do_sch():
    s = open(SCH, encoding="utf8").read()
    n = 0
    for ref, fp in MAP.items():
        k = s.find('(property "Reference" "%s"\n' % ref)
        assert k > 0, ref
        st = s.rfind("\n\t(symbol\n", 0, k) + 2            # at the "(" of "(symbol"
        en = block_after(s, st)
        blk = s[st:en]
        new = re.sub(r'\(property "Footprint" "[^"]*"', '(property "Footprint" "%s"' % fp, blk, count=1)
        if new != blk:
            s = s[:st] + new + s[en:]
            n += 1
    open(SCH, "w", encoding="utf8").write(s)
    print("schematic: %d footprint fields changed" % n)


def do_pcb(path):
    _k = pcbnew.LoadBoard(path)
    b = pcbnew.LoadBoard(path)
    io = pcbnew.PCB_IO_KICAD_SEXPR()
    old_list = []
    for ref, fpid in MAP.items():
        old = b.FindFootprintByReference(ref)
        if old.GetFPIDAsString() == fpid:
            continue
        lib, name = fpid.split(":")
        new = io.FootprintLoad(os.path.join(FPROOT, lib + ".pretty"), name)
        new.SetFPIDAsString(fpid)
        new.SetReference(ref)
        new.SetValue(old.GetValue())
        new.Value().SetLayer(pcbnew.F_Fab)                 # passives: reference on silkscreen, value on the fab layer
        new.SetPath(old.GetPath())
        new.SetSheetname(old.GetSheetname())
        new.SetSheetfile(old.GetSheetfile())
        oldf = {f.GetName(): f.GetText() for f in old.GetFields()}
        for f in new.GetFields():
            if f.GetName() in oldf and f.GetName() not in ("Reference", "Value", "Footprint"):
                f.SetText(oldf[f.GetName()])
        nets = {p.GetNumber(): p.GetNetname() for p in old.Pads()}
        new.SetPosition(old.GetPosition())
        b.Add(new); new.thisown = 0
        for p in new.Pads():                               # by name, after the footprint is on the board (else they do not stick)
            p.SetNet(b.FindNet(nets[p.GetNumber()]))
        if ref in POSITIVE_PIN1:
            pin1 = [p for p in new.Pads() if p.GetNumber() == "1"][0].GetNetname()
            assert pin1 not in ("GND", "/N_GND", ""), "%s: pad 1 (+) would be on ground / no net" % ref
        old_list.append(old)
    for old in old_list:                                   # removals last (they upset KiCad's python wrappers)
        b.Delete(old)
    pcbnew.SaveBoard(path, b, True)
    print("%s: %d footprints swapped to through-hole" % (os.path.basename(path), len(old_list)))


def do_black(path):
    s = open(path, encoding="utf8").read()
    st = s.find("(stackup")
    en = block_after(s, st)
    blk = s[st:en]
    for lay, col in (("F.Mask", "Black"), ("B.Mask", "Black"), ("F.SilkS", "White"), ("B.SilkS", "White")):
        m = re.search(r'\(layer "%s"\s*\(type "[^"]*"\)' % re.escape(lay), blk)
        tail = blk[m.end():m.end() + 40]
        if "(color" in tail:
            blk = blk[:m.end()] + re.sub(r'\(color "[^"]*"\)', '(color "%s")' % col, tail, count=1) + blk[m.end() + 40:]
        else:
            blk = blk[:m.end()] + '\n\t\t\t\t(color "%s")' % col + blk[m.end():]
    s = s[:st] + blk + s[en:]
    open(path, "w", encoding="utf8").write(s)
    print("%s: black solder mask, white silkscreen" % os.path.basename(path))


args = sys.argv[1:]


def boards(flag):
    if flag not in args:
        return []
    out = []
    for a in args[args.index(flag) + 1:]:
        if a.startswith("--"):
            break
        out.append(os.path.abspath(a))
    return out


if "--sch" in args:
    do_sch()
for p in boards("--pcb"):
    do_pcb(p)
for p in boards("--black"):
    do_black(p)
