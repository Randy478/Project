"""Write the project footprint for the 2.42in SSD1309 OLED module at its REAL size, so the layout keeps the whole screen board clear:
    MiniPC_v2.pretty/OLED_2.42_SSD1309_Module.kicad_mod   (+ the library entry in fp-lib-table)
The 7 header pads sit where the module's pin header goes through your board; the courtyard / silkscreen / fab outline is the whole module
(the module lies on top of the board, held by its header, so nothing tall may sit under it on the front side).

Numbers (generic 2.42in module with a 2.54 mm 7-pin header, e.g. Tinytronics / HiLetgo / TZT type):
  board 72.0 x 43.5 mm (vendors list 72.0 x 43.0 ... 72.0 x 43.5: the larger one is used so the clearance is safe),
  active area 55.01 x 27.49 mm, mounting holes 2.8 mm on a 68 x 39 mm spacing (drawn on Fab only, NOT drilled).
ASSUMED (no vendor drawing found): header centred on the long bottom edge, pad centres 2.5 mm from that edge, active area centred.
Change the constants below and re-run if the module in your hand differs; then run swap_oled_footprint.py to update the PCB.
Origin of the footprint = centre of pad 1, pads run along +x, the module extends towards -y.   Usage: python make_oled_footprint.py"""
import os
import uuid

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LIB = os.path.join(ROOT, "MiniPC_v2.pretty")
NAME = "OLED_2.42_SSD1309_Module"

MOD_W, MOD_H = 72.0, 43.5          # module board outline
ACT_W, ACT_H = 55.01, 27.49        # active (lit) area
HOLE_DX, HOLE_DY, HOLE_D = 68.0, 39.0, 2.8
PINS, PITCH = 7, 2.54
HDR_INSET = 2.5                    # pad centre to the module's bottom edge
HDR_X_FROM_LEFT = (MOD_W - (PINS - 1) * PITCH) / 2.0       # assumed centred
CRTYD_MARGIN = 0.25
DRILL, PAD_D = 1.0, 1.7

left, right = -HDR_X_FROM_LEFT, MOD_W - HDR_X_FROM_LEFT
bottom, top = HDR_INSET, HDR_INSET - MOD_H
cx, cy = (left + right) / 2.0, (top + bottom) / 2.0


def u():
    return str(uuid.uuid4())


def n(v):
    return ("%.4f" % v).rstrip("0").rstrip(".")


def rect(layer, x0, y0, x1, y1, width, dashed=False):
    return (f'\t(fp_rect\n\t\t(start {n(x0)} {n(y0)})\n\t\t(end {n(x1)} {n(y1)})\n\t\t(stroke\n\t\t\t(width {width})\n'
            f'\t\t\t(type {"dash" if dashed else "solid"})\n\t\t)\n\t\t(fill no)\n\t\t(layer "{layer}")\n\t\t(uuid "{u()}")\n\t)\n')


def circle(layer, x, y, d, width):
    return (f'\t(fp_circle\n\t\t(center {n(x)} {n(y)})\n\t\t(end {n(x + d / 2.0)} {n(y)})\n\t\t(stroke\n\t\t\t(width {width})\n'
            f'\t\t\t(type solid)\n\t\t)\n\t\t(fill no)\n\t\t(layer "{layer}")\n\t\t(uuid "{u()}")\n\t)\n')


def text(layer, s, x, y, size, thick, extra=""):
    return (f'\t(fp_text user "{s}"\n\t\t(at {n(x)} {n(y)} 0)\n\t\t(layer "{layer}")\n\t\t(uuid "{u()}")\n\t\t(effects\n\t\t\t(font\n'
            f'\t\t\t\t(size {size} {size})\n\t\t\t\t(thickness {thick})\n\t\t\t)\n{extra}\t\t)\n\t)\n')


def prop(name, value, x, y, layer, hide=False):
    return (f'\t(property "{name}" "{value}"\n\t\t(at {n(x)} {n(y)} 0)\n\t\t(layer "{layer}")\n' + ("\t\t(hide yes)\n" if hide else "")
            + f'\t\t(uuid "{u()}")\n\t\t(effects\n\t\t\t(font\n\t\t\t\t(size 1 1)\n\t\t\t\t(thickness 0.15)\n\t\t\t)\n\t\t)\n\t)\n')


out = f'(footprint "{NAME}"\n\t(version 20260206)\n\t(generator "pcbnew")\n\t(generator_version "10.0")\n\t(layer "F.Cu")\n'
out += (f'\t(descr "2.42in OLED module SSD1309 128x64, {MOD_W} x {MOD_H} mm board, 7-pin 2.54 mm header on the long bottom edge. '
        f'Whole module outline = courtyard (clearance), header position ASSUMED centred, 2.5 mm from the edge.")\n')
out += '\t(tags "OLED 2.42 SSD1309 module display 7 pin header")\n'
out += prop("Reference", "REF**", cx, top - 1.5, "F.SilkS")
out += prop("Value", NAME, cx, top + 5.5, "F.Fab")          # inside the module outline, under the "SCREEN - KEEP CLEAR" note
out += prop("Datasheet", "", 0, 0, "F.Fab", True)
out += prop("Description", "", 0, 0, "F.Fab", True)
out += "\t(attr through_hole)\n"
# silkscreen: module outline (solid, 0.15) so the keep-clear area is visible on the board, and a pin-1 marker on the pad row
out += rect("F.SilkS", left, top, right, bottom, 0.15)
out += (f'\t(fp_line\n\t\t(start {n(-2.0)} {n(-1.27)})\n\t\t(end {n(-2.0)} {n(1.27)})\n\t\t(stroke\n\t\t\t(width 0.15)\n\t\t\t(type solid)\n\t\t)\n'
        f'\t\t(layer "F.SilkS")\n\t\t(uuid "{u()}")\n\t)\n')
out += text("F.SilkS", "SCREEN - KEEP CLEAR", cx, top + 3.0, 1.0, 0.15)
# fab: outline, active area, (undrilled) mounting hole positions
out += rect("F.Fab", left, top, right, bottom, 0.1)
out += rect("F.Fab", cx - ACT_W / 2.0, cy - ACT_H / 2.0, cx + ACT_W / 2.0, cy + ACT_H / 2.0, 0.1, dashed=True)
out += text("F.Fab", f"active area {ACT_W} x {ACT_H}", cx, cy, 1.0, 0.15)
for sx in (-1, 1):
    for sy in (-1, 1):
        out += circle("F.Fab", cx + sx * HOLE_DX / 2.0, cy + sy * HOLE_DY / 2.0, HOLE_D, 0.1)
out += text("F.Fab", "${REFERENCE}", cx, cy + ACT_H / 2.0 + 3.0, 1.0, 0.15)
out += text("F.Fab", f"module {MOD_W} x {MOD_H}", cx, bottom - 1.0, 0.8, 0.12)
# courtyard = whole module + margin
m = CRTYD_MARGIN
out += rect("F.CrtYd", left - m, top - m, right + m, bottom + m, 0.05)
for i in range(PINS):
    shape = "rect" if i == 0 else "circle"
    out += (f'\t(pad "{i + 1}" thru_hole {shape}\n\t\t(at {n(i * PITCH)} 0)\n\t\t(size {PAD_D} {PAD_D})\n\t\t(drill {DRILL})\n'
            f'\t\t(layers "*.Cu" "*.Mask")\n\t\t(remove_unused_layers no)\n\t\t(uuid "{u()}")\n\t)\n')
out += ")\n"

os.makedirs(LIB, exist_ok=True)
path = os.path.join(LIB, NAME + ".kicad_mod")
with open(path, "w", encoding="utf8", newline="\n") as f:
    f.write(out)
print("wrote", path)

table = os.path.join(ROOT, "fp-lib-table")
entry = '\t(lib (name "MiniPC_v2")(type "KiCad")(uri "${KIPRJMOD}/MiniPC_v2.pretty")(options "")(descr "Project footprints (full-size OLED module)"))\n'
t = open(table, encoding="utf8").read() if os.path.exists(table) else "(fp_lib_table\n\t(version 7)\n)\n"
if "MiniPC_v2.pretty" not in t:
    i = t.rindex(")")
    t = t[:i] + entry + t[i:]
    with open(table, "w", encoding="utf8", newline="\n") as f:
        f.write(t)
    print("registered library in fp-lib-table")
print(f"module x {left:.2f}..{right:.2f}, y {top:.2f}..{bottom:.2f} (origin = pad 1)")
