"""Silkscreen clean-up (KiCad CLOSED, KiCad's python):
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\silk_fix.py MiniPC_v2.kicad_pcb [--write]
Moves every visible Reference text (1.0 mm / 0.15 mm, the fab minimum) to the first spot around its part - above, below, left, right,
then the same turned 90 deg - where it touches no pad (0.15 mm), no silkscreen line or text of any part, and stays 0.3 mm inside the
board. Parts with no free spot get their reference hidden (listed at the end; the reference stays on the fab layer).
Pin-name texts and silkscreen lines of the footprints are not touched."""
import os
import sys

import pcbnew

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0])
WRITE = "--write" in sys.argv
MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))
CLR = int(MM(0.15))

_keep = pcbnew.LoadBoard(PCB)
board = pcbnew.LoadBoard(PCB)
outline = pcbnew.SHAPE_POLY_SET()
board.GetBoardPolygonOutlines(outline, True)
inner = pcbnew.SHAPE_POLY_SET(outline)
inner.Deflate(int(MM(0.3)), pcbnew.CORNER_STRATEGY_ROUND_ALL_CORNERS, int(MM(0.01)))

SIDES = {pcbnew.F_SilkS: pcbnew.F_Cu, pcbnew.B_SilkS: pcbnew.B_Cu}
obst = {pcbnew.F_SilkS: [], pcbnew.B_SilkS: []}     # (owner ref, shape)
refs = []
for f in board.GetFootprints():
    r = f.GetReference()
    for p in f.Pads():
        for silk, cu in SIDES.items():
            if p.IsOnLayer(cu) or p.HasHole():
                obst[silk].append((r, p.GetEffectiveShape(cu)))
    for g in f.GraphicalItems():
        if g.GetLayer() in obst and (not hasattr(g, "IsVisible") or g.IsVisible()):
            obst[g.GetLayer()].append((r, g.GetEffectiveShape()))
    val = f.Value()
    if val.GetLayer() in obst and val.IsVisible():
        obst[val.GetLayer()].append((r, val.GetEffectiveShape()))
    ref = f.Reference()
    if ref.IsVisible() and ref.GetLayer() in obst:
        refs.append(f)
for d in board.GetDrawings():
    if d.GetLayer() in obst:
        obst[d.GetLayer()].append(("", d.GetEffectiveShape()))


def crt(f):
    lay = pcbnew.B_CrtYd if f.IsFlipped() else pcbnew.F_CrtYd
    bb = f.GetCourtyard(lay).BBox()
    if bb.GetWidth() <= 0:
        bb = f.GetBoundingBox(False)
    return TOMM(bb.GetLeft()), TOMM(bb.GetTop()), TOMM(bb.GetRight()), TOMM(bb.GetBottom())


def fits(t, layer, own):
    s = t.GetEffectiveShape()
    poly = pcbnew.SHAPE_POLY_SET()
    bb = t.GetBoundingBox()
    for x, y in ((bb.GetLeft(), bb.GetTop()), (bb.GetRight(), bb.GetTop()), (bb.GetRight(), bb.GetBottom()), (bb.GetLeft(), bb.GetBottom())):
        if not inner.Contains(pcbnew.VECTOR2I(x, y)):
            return False
    for r, o in obst[layer]:
        if s.Collide(o, CLR):
            return False
    return True


# small parts first (they have the fewest choices), big ones last
refs.sort(key=lambda f: (crt(f)[2] - crt(f)[0]) * (crt(f)[3] - crt(f)[1]))
hidden, moved = [], 0
for f in refs:
    t = f.Reference()
    layer = t.GetLayer()
    t.SetTextSize(V(1.0, 1.0)); t.SetTextThickness(MM(0.15))
    l, tp, r, b = crt(f)
    cx, cy = (l + r) / 2, (tp + b) / 2
    own_before = t.GetPosition(), t.GetTextAngleDegrees()
    # keep the current spot if it is already clean
    cands = [(None, None)]
    for ang in (0, 90):
        cands += [((cx, tp - 0.7), ang), ((cx, b + 0.7), ang), ((l - 0.8, cy), ang), ((r + 0.8, cy), ang),
                  ((cx, tp - 1.6), ang), ((cx, b + 1.6), ang), ((l - 1.8, cy), ang), ((r + 1.8, cy), ang),
                  ((l, tp - 0.7), ang), ((r, tp - 0.7), ang), ((l, b + 0.7), ang), ((r, b + 0.7), ang)]
    for pos, ang in cands:
        if pos is not None:
            t.SetTextAngleDegrees(ang + (0 if not f.IsFlipped() else 0))
            t.SetPosition(V(*pos))
        if fits(t, layer, f.GetReference()):
            if pos is not None:
                moved += 1
            break
    else:
        t.SetPosition(own_before[0]); t.SetTextAngleDegrees(own_before[1])
        t.SetVisible(False)
        hidden.append(f.GetReference())
        continue
    obst[layer].append((f.GetReference(), t.GetEffectiveShape()))
print("references moved:", moved, " hidden (no free spot):", " ".join(sorted(hidden)) or "-")
if WRITE:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
