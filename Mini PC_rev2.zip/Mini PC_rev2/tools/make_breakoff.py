"""Break-off board: the EasyGlider flight-node board next to the handheld board, joined by 3 mouse-bite tabs, with the 55 node parts on it
(first-pass placement: nothing overlaps, nothing is routed; arrange it as you like). Run with KiCad CLOSED, KiCad's own python:
    python make_breakoff.py <pcb> [--side=right|top] [--node-width=N] [--front-only] [--write] [--redo]
The whole panel (handheld + 2 mm routed slot + node) is 100 x 100 mm, JLCPCB's cheap 4-layer tier. Coordinates in mm, y grows downwards.
  --side=right (default): handheld at the left (x 0 .. 98 - node width, full 100 mm tall), node on its right edge (x from handheld + 2 to 100, y from 0 down).
                          --node-width=N sets the strip width, without it the narrowest strip that holds all the parts is found.
  --side=top:             node above the handheld (the earlier layout): handheld 100 wide, node 100 wide and as tall as the parts need.
Both boards have 2 mm corners. 3 tabs, 5 mm wide, bridge the slot; each carries a row of 5 NPTH mouse-bite holes (0.5 mm, 0.8 mm pitch) in the slot, 0.5 mm off the
handheld's edge, so snapping the node off leaves at most a 0.5 mm ridge on the handheld.
Packing: bottom-left first fit, courtyards 1 mm apart sideways / 3.2 mm up-down (reference above, value below), SMD resistors / capacitors on the BACK of the node
(--front-only keeps them on the front), through-hole parts and the RFM95W / u.FL area blocked on the back too. USB-C faces out of the node's free outer edge.
Handheld parts the user placed against the bottom-right corner (U1 ESP32, SW8): with --side=top they follow the corner; with --side=right the ESP32's antenna may not
point at the node, so U1 turns to the bottom edge (antenna off the board) and SW8 keeps its distance from the handheld's right and bottom edges.
Mouse-bite footprints (MB1..MB3, 'not in schematic') come from MiniPC_v2.pretty/MouseBites_5x0.5mm; the script writes that file.
Refuses to run twice (it would re-pack your layout) unless --redo is given."""
import json
import math
import os
import re
import sys
import uuid

import pcbnew

HERE = os.path.dirname(os.path.abspath(__file__))
args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0] if args else os.path.join(HERE, "..", "MiniPC_v2.kicad_pcb"))
WRITE = "--write" in sys.argv
REDO = "--redo" in sys.argv
BACK = "--front-only" not in sys.argv           # SMD passives of the node on the back side
SIDE = next((a.split("=", 1)[1] for a in sys.argv if a.startswith("--side=")), "right")
NODE_W_ARG = next((float(a.split("=", 1)[1]) for a in sys.argv if a.startswith("--node-width=")), None)
assert SIDE in ("right", "top"), "--side must be right or top"
LIBDIR = os.path.abspath(os.path.join(HERE, "..", "MiniPC_v2.pretty"))
MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))

# ---- geometry ---------------------------------------------------------------------------------------------------------
HX0, HY0 = 0.0, 0.0                              # top-left corner of the handheld
TOTAL_W, TOTAL_H = 100.0, 100.0                  # the WHOLE panel (handheld + slot + node) must fit JLCPCB's cheap 100 x 100 mm tier
R = 2.0                                          # corner radius
GAP = 2.0                                        # routed slot between the boards
TAB_W = 5.0
BITE_D, BITE_PITCH, BITE_N = 0.5, 0.8, 5
BITE_Y = -0.5                                    # perforation row, in the slot 0.5 mm off the handheld edge (keeps the screen module's courtyard clear of the holes)
MARGIN = 1.5                                     # courtyard to node outline (sides)
MARGIN_Y = 2.5                                   # same at the top / bottom: the reference above the first row and the value under the last one must stay on the board
GX = float(next((a.split('=', 1)[1] for a in sys.argv if a.startswith('--gx=')), 1.0))      # courtyard-to-courtyard gaps (sideways / up-down): reference above, value below
GY = float(next((a.split('=', 1)[1] for a in sys.argv if a.startswith('--gy=')), 3.2))
TXT = 0.95                                       # text centre distance from the courtyard edge
STEP = 1.0
NAME = "MouseBites_5x0.5mm"
ANCHORED = ("U1", "SW8")                         # parts the user placed against the handheld's bottom-right corner
U1_ANT = 6.74                                    # U1 centre to the board edge it hangs over (module centre 6.74 mm inside the edge, antenna end 6 mm outside)

_keep = pcbnew.LoadBoard(PCB)                    # KiCad's python needs the board loaded twice
board = pcbnew.LoadBoard(PCB)

# ---- the node's parts -------------------------------------------------------------------------------------------------
groups = json.load(open(os.path.join(HERE, "parts_groups.json"), encoding="utf8"))
node_refs = next(v for k, v in groups.items() if k.startswith("BREAK-OFF"))
fps = {r: board.FindFootprintByReference(r) for r in node_refs}
missing = [r for r, f in fps.items() if f is None]
if missing:
    sys.exit("not on the board: %s" % missing)
if any(f.GetReference().startswith("MB") for f in board.GetFootprints()) and not REDO:
    sys.exit("break-off already made (MB footprints exist); use --redo to re-pack the node")

# ---- current outline (for the corner-following shift of the anchored parts in --side=top) -----------------------------------
old_edges = [d for d in list(board.GetDrawings()) if d.GetLayer() == pcbnew.Edge_Cuts and d.GetShape() in (pcbnew.SHAPE_T_SEGMENT, pcbnew.SHAPE_T_ARC)]
EW = TOMM(old_edges[0].GetWidth()) if old_edges else 0.05
pts = [(TOMM(p.x), TOMM(p.y)) for d in old_edges for p in (d.GetStart(), d.GetEnd())]
assert abs(min(x for x, _ in pts) - HX0) < 0.05, "handheld outline does not start at x = 0"
cur_H = max(y for _, y in pts)                                   # the handheld's bottom edge (its top edge is y = 0)
cur_W = max(x for x, y in pts if -0.05 <= y <= cur_H + 0.05)   # ... and its right edge (only meaningful when the node is above it, as in --side=top)


# ---- packing ----------------------------------------------------------------------------------------------------------
def court_rect(fp):
    """courtyard (F.CrtYd) bounding box of a footprint in its current position / orientation, mm: (l, t, r, b)"""
    l = t = 1e9
    r = b = -1e9
    for it in list(fp.GraphicalItems()):
        if it.GetLayer() == pcbnew.F_CrtYd:
            bb = it.GetBoundingBox()
            l, t, r, b = min(l, TOMM(bb.GetLeft())), min(t, TOMM(bb.GetTop())), max(r, TOMM(bb.GetRight())), max(b, TOMM(bb.GetBottom()))
    if l > r:
        bb = fp.GetBoundingBox(False, False)
        l, t, r, b = TOMM(bb.GetLeft()), TOMM(bb.GetTop()), TOMM(bb.GetRight()), TOMM(bb.GetBottom())
    return l, t, r, b


def set_pose(fp, x, y, rot):
    fp.SetPosition(V(0, 0))
    fp.SetOrientation(pcbnew.EDA_ANGLE(rot, pcbnew.DEGREES_T))
    fp.SetPosition(V(x, y))


labels = json.load(open(os.path.join(HERE, "labels.json"), encoding="utf8"))


def label_reach(fp, ref):
    """pin-name texts (silkscreen.py) stick out of the courtyard sideways: rectangle (l, t, r, b) they cover, footprint at origin, rotation 0"""
    pins = (labels.get(ref) or {}).get("pins") or {}
    pads = [p for p in fp.Pads() if p.GetNumber() in pins]
    if not pads:
        return None
    cols = sorted({round(TOMM(p.GetPosition().x), 2) for p in fp.Pads()})
    mid = (cols[0] + cols[-1]) / 2.0
    l = t = 1e9
    r = b = -1e9
    for p in pads:
        x, y = TOMM(p.GetPosition().x), TOMM(p.GetPosition().y)
        start = 0.85 + TOMM(max(p.GetSize().x, p.GetSize().y)) / 2.0        # same offset as silkscreen.py
        n = len(pins[p.GetNumber()]) * 1.0 + 0.3
        if len(cols) == 1 or x >= mid:
            l, r = min(l, x), max(r, x + start + n)
        else:
            l, r = min(l, x - start - n), max(r, x)
        t, b = min(t, y - 0.5), max(b, y + 0.5)
    return l, t, r, b


SMD_PASSIVE = re.compile(r"^[RC]_(0402|0603|0805|1206)_")
FLIP_LR = getattr(pcbnew, "FLIP_DIRECTION_LEFT_RIGHT", True)


def is_passive(fp):
    return SMD_PASSIVE.match(str(fp.GetFPID().GetLibItemName())) is not None


def has_tht(fp):
    return any(p.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH, pcbnew.PAD_ATTRIB_NPTH) for p in fp.Pads())


for fp in fps.values():                           # a re-run starts from the front side
    if fp.GetLayer() == pcbnew.B_Cu:
        fp.Flip(fp.GetPosition(), FLIP_LR)

PASSIVE = {r for r, f in fps.items() if is_passive(f)}
BACK_REFS = PASSIVE if BACK else set()            # the node's SMD passives go on the back (hand-solderable, and they free the front)
FRONT_REFS = [r for r in node_refs if r not in BACK_REFS]
THT = {r for r, f in fps.items() if has_tht(f)}   # through-hole parts block both sides
RF_KEEPOUT = {"U9", "J17"}                        # nothing under the RFM95W / u.FL
rel = {}                                          # ref -> {rot: courtyard rect relative to the footprint origin (with text / pin-name room)}
plain = {}                                        # same without the text room (for the back side)
for ref, fp in fps.items():
    rel[ref] = {}
    for rot in (0, 90, 180):
        set_pose(fp, 0, 0, rot)
        rel[ref][rot] = court_rect(fp)
    set_pose(fp, 0, 0, 0)
    plain[ref] = dict(rel[ref])
    reach0 = label_reach(fp, ref)

    def rotated(rc, rot):                          # a rectangle (l, t, r, b) around the origin turned by rot degrees (y down, counter-clockwise on screen)
        l, t, r, b = rc
        return {0: rc, 90: (t, -r, b, -l), 180: (-r, -b, -l, -t)}[rot]

    tw = (len(ref) if ref in PASSIVE else max(len(ref), len((labels.get(ref) or {}).get("value") or fp.GetValue()))) * 1.0 + 0.4      # texts are horizontal, ~1 mm per character
    for rot in list(rel[ref]):
        l, t, r, b = rel[ref][rot]
        if reach0:                                # labelled headers: the pin names stick out sideways, and turn with the part
            rl_, rt_, rr_, rb_ = rotated(reach0, rot)
            l, t, r, b = min(l, rl_), min(t, rt_), max(r, rr_), max(b, rb_)
        if r - l < tw:
            l, r = l - (tw - (r - l)) / 2.0, r + (tw - (r - l)) / 2.0
        rel[ref][rot] = (l, t, r, b)
    if ref in PASSIVE:                            # SMD passives: only the reference is printed (above the part), the value goes to the fab layer; never rotated
        rel[ref] = {0: rel[ref][0]}


def expand(l, t, r, b, ref=None):
    top, bottom = (1.5, 0.4) if ref in PASSIVE else (GY / 2.0, GY / 2.0)          # passives: one text line above, nothing below
    return (l - GX / 2.0, t - top, r + GX / 2.0, b + bottom)


def hit(a, b):
    return a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]


def first_fit(ref, Wn, H, blocked):
    """bottom-left first fit of one part into a Wn x H node: (rot, left, top) or None"""
    for rot in sorted(r_ for r_ in rel[ref] if r_ in (0, 90)):
        rl, rt, rr, rb = rel[ref][rot]
        w, h = rr - rl, rb - rt
        y = MARGIN_Y
        while y + h <= H - MARGIN_Y + 1e-6:
            x = MARGIN
            while x + w <= Wn - MARGIN + 1e-6:
                box = expand(x, y, x + w, y + h, ref)
                if not any(hit(box, o) for o in blocked):
                    return rot, x, y
                x += STEP
            y += STEP
    return None


def pack(Wn, H, key):
    """pack the node's front side, then (BACK) its passives on the back; returns (front, back) dicts ref -> (rot, left, top) or None"""
    front, blocked = {}, []

    def put(ref, rot, left, top):
        rl, rt, rr, rb = rel[ref][rot]
        front[ref] = (rot, left, top)
        blocked.append(expand(left, top, left + rr - rl, top + rb - rt, ref))

    # USB-C faces out of the free outer edge (front 1.1 mm past the edge, like J2 on the first board)
    if SIDE == "top":
        rl, rt, rr, rb = rel["J16"][180]
        put("J16", 180, 14.0 + rl, 2.55 + rt)                                    # facing up, 14 mm from the left
        uw, uh = rel["U9"][0][2] - rel["U9"][0][0], rel["U9"][0][3] - rel["U9"][0][1]
        put("U9", 0, Wn - MARGIN - uw, MARGIN_Y)                                 # RFM95W top right ...
        jw, jh = rel["J17"][0][2] - rel["J17"][0][0], rel["J17"][0][3] - rel["J17"][0][1]
        put("J17", 0, Wn - MARGIN - uw - GX - jw, MARGIN_Y + uh - jh)             # ... u.FL left of it, level with its bottom edge
        order = []
    else:
        rl, rt, rr, rb = rel["J16"][90]
        put("J16", 90, (Wn - 2.55) + rl, (H - 12.0) + rt)                         # facing right, near the bottom of the strip
        order = ["U9", "J17"]                                                    # the radio first, its u.FL right after it (first fit lands them side by side)
    for ref in order + sorted([r for r in FRONT_REFS if r not in front and r not in order], key=key):
        spot = first_fit(ref, Wn, H, blocked)
        if spot is None:
            return None
        put(ref, *spot)
    back = {}
    if BACK_REFS:
        bblocked = []
        for ref, (rot, left, top) in front.items():           # through-hole pins and the RF area are in the way on the back too
            if ref in THT or ref in RF_KEEPOUT:
                l0, t0, r0, b0 = plain[ref][rot]
                ox, oy = left - rel[ref][rot][0], top - rel[ref][rot][1]
                bblocked.append((ox + l0 - 0.3, oy + t0 - 0.3, ox + r0 + 0.3, oy + b0 + 0.3))
        for ref in sorted(BACK_REFS, key=key):
            spot = first_fit(ref, Wn, H, bblocked)
            if spot is None:
                return None
            rot, x, y = spot
            rl, rt, rr, rb = rel[ref][rot]
            back[ref] = spot
            bblocked.append(expand(x, y, x + rr - rl, y + rb - rt, ref))
    return front, back


def area_key(r):
    return -(rel[r][0][2] - rel[r][0][0]) * (rel[r][0][3] - rel[r][0][1])


def height_key(r):
    return (-(rel[r][0][3] - rel[r][0][1]), area_key(r))


def box_area(r):
    return (rel[r][0][2] - rel[r][0][0] + GX) * (rel[r][0][3] - rel[r][0][1] + (1.9 if r in PASSIVE else GY))


def best_height(Wn, hmax):
    """smallest whole-mm node height <= hmax that packs at width Wn (over two part orders): (H, (front, back)) or None"""
    best = None
    lower = max(sum(box_area(r) for r in FRONT_REFS), sum(box_area(r) for r in BACK_REFS)) / (Wn - 2 * MARGIN)
    for key in (area_key, height_key):
        H = max(16, int(lower))
        while H <= (hmax if best is None else best[0] - 1):
            res = pack(Wn, H, key)
            if res:
                best = (H, res)
                break
            H += 1
    return best


if SIDE == "top":
    NW = TOTAL_W
    best = best_height(NW, 160)
    assert best, "cannot fit"
else:
    if NODE_W_ARG:
        NW = NODE_W_ARG
        best = best_height(NW, TOTAL_H)
        if not best:
            sys.exit("the node parts do not fit a %.1f mm wide strip (<= %.0f mm tall): try a wider one, or leave --node-width out to find the narrowest" % (NW, TOTAL_H))
    else:
        best = None
        for NW in range(18, 60):
            best = best_height(float(NW), TOTAL_H)
            if best:
                break
        assert best, "no strip width up to 60 mm works"
        NW = float(NW)
H, (placed, placed_back) = best                    # H = node height (right: along the edge, top: the strip's thickness)


def courts(refs):
    return sum((rel[r][0][2] - rel[r][0][0]) * (rel[r][0][3] - rel[r][0][1]) for r in refs)


# ---- the two boards ---------------------------------------------------------------------------------------------------------
if SIDE == "top":
    HX1, HY1 = HX0 + TOTAL_W, TOTAL_H - GAP - H                  # handheld: 100 wide, what the node leaves tall
    NX0, NY0, NX1, NY1 = HX0, HY0 - GAP - H, HX1, HY0 - GAP     # node above it
else:
    HX1, HY1 = HX0 + TOTAL_W - GAP - NW, HY0 + TOTAL_H           # handheld: full height, what the node leaves wide
    NX0, NY0, NX1, NY1 = HX1 + GAP, HY0, HX1 + GAP + NW, HY0 + H  # node on its right, level with its top
print("panel %.1f x %.1f mm (%s): handheld %.1f x %.1f, slot %.1f, node %.1f x %.1f" % (TOTAL_W, TOTAL_H, SIDE, HX1 - HX0, HY1 - HY0, GAP, NX1 - NX0, NY1 - NY0))
print("node front: %d parts, courtyards fill %.0f %%; back: %d SMD passives, %.0f %%" % (len(FRONT_REFS), 100.0 * courts(FRONT_REFS) / ((NX1 - NX0) * (NY1 - NY0)), len(BACK_REFS), 100.0 * courts(BACK_REFS) / ((NX1 - NX0) * (NY1 - NY0))))

# ---- outline ----------------------------------------------------------------------------------------------------------
for d in old_edges:
    board.Remove(d)


def shape(kind):
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(kind)
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(MM(EW))
    board.Add(s)
    return s


def line(ax, ay, bx, by):
    s = shape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(V(ax, ay))
    s.SetEnd(V(bx, by))


def arc(cx, cy, sx, sy, ex, ey, mdx, mdy):
    s = shape(pcbnew.SHAPE_T_ARC)
    k = math.sqrt(0.5) * R
    s.SetArcGeometry(V(sx, sy), V(cx + mdx * k, cy + mdy * k), V(ex, ey))


def rounded_rect(x0, y0, x1, y1, skip):
    """a rounded board: 4 corner arcs and the straight edges except the one called skip ('top', 'bottom', 'left', 'right') that faces the slot"""
    if skip != "left":
        line(x0, y0 + R, x0, y1 - R)
    if skip != "right":
        line(x1, y0 + R, x1, y1 - R)
    if skip != "top":
        line(x0 + R, y0, x1 - R, y0)
    if skip != "bottom":
        line(x0 + R, y1, x1 - R, y1)
    arc(x0 + R, y0 + R, x0, y0 + R, x0 + R, y0, -1, -1)
    arc(x1 - R, y0 + R, x1 - R, y0, x1, y0 + R, 1, -1)
    arc(x1 - R, y1 - R, x1, y1 - R, x1 - R, y1, 1, 1)
    arc(x0 + R, y1 - R, x0 + R, y1, x0, y1 - R, -1, 1)


if SIDE == "top":
    TABS = [(NX1 - NX0) * f for f in (0.15, 0.5, 0.85)]            # tab centres along x
    rounded_rect(HX0, HY0, HX1, HY1, "top")
    rounded_rect(NX0, NY0, NX1, NY1, "bottom")
    cuts = [HX0 + R]
    for c in TABS:
        cuts += [c - TAB_W / 2.0, c + TAB_W / 2.0]
    cuts.append(HX1 - R)
    for a, b in zip(cuts[0::2], cuts[1::2]):                      # the slot-facing edges between the tabs, on both boards
        line(a, HY0, b, HY0)
        line(a, NY1, b, NY1)
    for c in TABS:                                                # the tab sides
        for x in (c - TAB_W / 2.0, c + TAB_W / 2.0):
            line(x, NY1, x, HY0)
else:
    TABS = [H * f for f in (0.15, 0.5, 0.85)]                      # tab centres along y (inside the node's height)
    rounded_rect(HX0, HY0, HX1, HY1, "right")
    rounded_rect(NX0, NY0, NX1, NY1, "left")
    cuts_n = [NY0 + R]
    for c in TABS:
        cuts_n += [NY0 + c - TAB_W / 2.0, NY0 + c + TAB_W / 2.0]
    cuts_n.append(NY1 - R)
    for a, b in zip(cuts_n[0::2], cuts_n[1::2]):                  # node's left edge between the tabs, and the handheld's edge facing it
        line(NX0, a, NX0, b)
        line(HX1, a, HX1, b)
    if HY1 - R > NY1 - R + 0.01:
        line(HX1, NY1 - R, HX1, HY1 - R)                          # the rest of the handheld's right edge, below the node
    for c in TABS:                                                # the tab sides
        for y in (NY0 + c - TAB_W / 2.0, NY0 + c + TAB_W / 2.0):
            line(HX1, y, NX0, y)

# ---- mouse-bite footprint + instances ---------------------------------------------------------------------------------
os.makedirs(LIBDIR, exist_ok=True)
pads = ""
for i in range(BITE_N):
    x = (i - (BITE_N - 1) / 2.0) * BITE_PITCH
    pads += ('\t(pad "" np_thru_hole circle\n\t\t(at %g 0)\n\t\t(size %g %g)\n\t\t(drill %g)\n\t\t(layers "*.Cu" "*.Mask")\n\t\t(uuid "%s")\n\t)\n'
             % (round(x, 4), BITE_D, BITE_D, BITE_D, uuid.uuid4()))
fp_text = ('(footprint "%s"\n\t(version 20260206)\n\t(generator "pcbnew")\n\t(generator_version "10.0")\n\t(layer "F.Cu")\n'
           '\t(descr "Mouse-bite perforation for a break-off tab: %d x %g mm NPTH holes, %g mm pitch, in the slot next to the board edge")\n'
           '\t(tags "mouse bite perforation tab break-off panel")\n' % (NAME, BITE_N, BITE_D, BITE_PITCH))
for nm, val, y, layer in (("Reference", "REF**", -1.5, "F.SilkS"), ("Value", NAME, 1.5, "F.Fab")):
    fp_text += ('\t(property "%s" "%s"\n\t\t(at 0 %g 0)\n\t\t(layer "%s")\n\t\t(hide yes)\n\t\t(uuid "%s")\n\t\t(effects\n\t\t\t(font\n'
                '\t\t\t\t(size 1 1)\n\t\t\t\t(thickness 0.15)\n\t\t\t)\n\t\t)\n\t)\n' % (nm, val, y, layer, uuid.uuid4()))
fp_text += '\t(attr board_only exclude_from_pos_files exclude_from_bom)\n' + pads + ')\n'
open(os.path.join(LIBDIR, NAME + ".kicad_mod"), "w", encoding="utf8", newline="\n").write(fp_text)

for f in [f for f in list(board.GetFootprints()) if f.GetReference().startswith("MB")]:
    board.Remove(f)
for i, c in enumerate(TABS, 1):
    mb = pcbnew.FootprintLoad(LIBDIR, NAME)
    mb.SetFPID(pcbnew.LIB_ID("MiniPC_v2", NAME))
    mb.SetReference("MB%d" % i)
    if SIDE == "top":
        mb.SetPosition(V(NX0 + c, HY0 + BITE_Y))
    else:
        mb.SetOrientation(pcbnew.EDA_ANGLE(90, pcbnew.DEGREES_T))             # holes run along y
        mb.SetPosition(V(HX1 - BITE_Y, NY0 + c))
    mb.Reference().SetVisible(False)
    mb.Value().SetVisible(False)
    board.Add(mb)

# ---- the handheld parts the user placed against the bottom-right corner ----------------------------------------------------
if SIDE == "top":
    dW, dH = (HX1 - HX0) - cur_W, (HY1 - HY0) - cur_H            # they follow the corner
    if abs(dW) > 0.01 or abs(dH) > 0.01:
        for r_ in ANCHORED:
            f_ = board.FindFootprintByReference(r_)
            if f_ is not None:
                f_.SetPosition(f_.GetPosition() + pcbnew.VECTOR2I(int(MM(dW)), int(MM(dH))))
                print("  moved %s by (%+.1f, %+.1f) mm with the bottom-right corner" % (r_, dW, dH))
else:
    u1 = board.FindFootprintByReference("U1")
    sw8 = board.FindFootprintByReference("SW8")
    if u1 is not None:                                           # ESP32: antenna off the bottom edge, not towards the node
        u1.SetOrientation(pcbnew.EDA_ANGLE(180, pcbnew.DEGREES_T))
        u1.SetPosition(V(HX1 - 12.5, HY1 - U1_ANT))
        print("  U1 (ESP32) turned to the bottom edge: antenna points down, off the board")
    if sw8 is not None:
        sw8.SetPosition(V(HX1 - 6.35, HY1 - 37.25))              # same distance from the right and bottom edges as on the 80.5 x 90 board
        print("  SW8 kept 6.35 mm from the right edge and 37.25 mm above the bottom edge")
    j5 = board.FindFootprintByReference("J5")                    # the screen (72.5 mm long module) must stay on the board
    if j5 is not None:
        bb = j5.GetBoundingBox(False, False)
        if TOMM(bb.GetWidth()) > (HX1 - HX0) - 2.0:              # landscape does not fit this handheld: portrait, header along the left edge, module towards the right
            j5.SetOrientation(pcbnew.EDA_ANGLE(-90, pcbnew.DEGREES_T))
            bb = j5.GetBoundingBox(False, False)
            j5.SetPosition(j5.GetPosition() + pcbnew.VECTOR2I(int(MM(HX0 + 1.5) - bb.GetLeft()), int(MM(HY0 + 1.5) - bb.GetTop())))
            bb = j5.GetBoundingBox(False, False)
            print("  screen J5 turned to portrait (header down the left edge): %.1f x %.1f mm at x %.1f, y %.1f" % (TOMM(bb.GetWidth()), TOMM(bb.GetHeight()), TOMM(bb.GetLeft()), TOMM(bb.GetTop())))

# ---- place the node parts ---------------------------------------------------------------------------------------------
for ref, (rot, left, top), on_back in [(r, s, False) for r, s in placed.items()] + [(r, s, True) for r, s in placed_back.items()]:
    fp = fps[ref]
    rl, rt, rr, rb = rel[ref][rot]
    set_pose(fp, NX0 + left - rl, NY0 + top - rt, rot)
    if on_back:                                     # flipped about its own origin (the passives are symmetric): same spot, other side
        fp.Flip(fp.GetPosition(), FLIP_LR)
    cx, cy = NX0 + left + (rr - rl) / 2.0, NY0 + top
    ref_y, val_y = cy - TXT, NY0 + top + (rb - rt) + TXT
    if ref == "J16":                                # USB-C hangs over the free edge: reference under it, value on its body
        ref_y, val_y = val_y, NY0 + top - rt
    if ref in PASSIVE:                              # reference above the part, value (fab layer only) on it
        ref_y, val_y = cy - 0.9, NY0 + top + (rb - rt) / 2.0
        fp.Value().SetLayer(pcbnew.B_Fab if on_back else pcbnew.F_Fab)
    for fld, y in ((fp.Reference(), ref_y), (fp.Value(), val_y)):
        fld.SetPosition(V(cx, y))
        fld.SetTextAngle(pcbnew.EDA_ANGLE(0, pcbnew.DEGREES_T))
        fld.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_CENTER)
        fld.SetVertJustify(pcbnew.GR_TEXT_V_ALIGN_CENTER)

ps = pcbnew.SHAPE_POLY_SET()
closed = board.GetBoardPolygonOutlines(ps, False)
print("outline closed:", closed, "| outline polygons:", ps.OutlineCount(), "| handheld x %.1f .. %.1f, y %.1f .. %.1f | node x %.1f .. %.1f, y %.1f .. %.1f" % (HX0, HX1, HY0, HY1, NX0, NX1, NY0, NY1))
print("footprints on the board:", sum(1 for f in board.GetFootprints()))

if WRITE:
    pro = os.path.splitext(PCB)[0] + ".kicad_pro"
    bak = open(pro, "rb").read() if os.path.exists(pro) else None
    pcbnew.SaveBoard(PCB, board)
    if bak is not None:
        open(pro, "wb").write(bak)          # SaveBoard rewrites the project file: put the user's settings back
    chk = pcbnew.LoadBoard(PCB)
    bb = chk.GetBoardEdgesBoundingBox()
    print("  saved; footprints:", len(list(chk.GetFootprints())), "| board edges bbox %.2f x %.2f mm" % (TOMM(bb.GetWidth()), TOMM(bb.GetHeight())))
