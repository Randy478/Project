"""Minimal KiCad symbol-library helper: extract a symbol block and list its pins."""
import os
import re

KICAD = os.path.expandvars(r"%LOCALAPPDATA%\Programs\KiCad\10.0\share\kicad")
SYMDIR = os.path.join(KICAD, "symbols")
FPDIR = os.path.join(KICAD, "footprints")

_cache = {}


def _lib_text(lib):
    if lib not in _cache:
        with open(os.path.join(SYMDIR, lib + ".kicad_sym"), encoding="utf8") as f:
            _cache[lib] = f.read()
    return _cache[lib]


def _balanced(text, start):
    """text[start] == '(' -> index just past the matching ')' (respects strings)."""
    depth = 0
    i = start
    in_str = False
    while i < len(text):
        c = text[i]
        if in_str:
            if c == "\\":
                i += 1
            elif c == '"':
                in_str = False
        else:
            if c == '"':
                in_str = True
            elif c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
                if depth == 0:
                    return i + 1
        i += 1
    raise ValueError("unbalanced")


def raw_symbol(lib, name):
    """Return the raw top-level symbol block text (as in the .kicad_sym file)."""
    t = _lib_text(lib)
    m = re.search(r'\n\t\(symbol "%s"\n' % re.escape(name), t)
    if not m:
        raise KeyError(f"{lib}:{name}")
    s = m.start() + 1
    return t[s:_balanced(t, s)]


def pins(block):
    """-> {number: dict(name,x,y,angle,type,hide,unit)} for every pin in a symbol block."""
    out = {}
    pos = 0
    while True:
        m = re.search(r"\(pin (\w+) (\w+)\s*\(at ([-\d.]+) ([-\d.]+) (\d+)\)", block[pos:])
        if not m:
            break
        st = pos + m.start()
        en = _balanced(block, st)
        body = block[st:en]
        name = re.search(r'\(name "([^"]*)"', body)
        num = re.search(r'\(number "([^"]*)"', body)
        # unit index from the enclosing "(symbol "X_<unit>_<style>"" is approximated by ignoring it
        out.setdefault(num.group(1), dict(
            name=name.group(1), x=float(m.group(3)), y=float(m.group(4)), angle=int(m.group(5)),
            type=m.group(1), hide="(hide yes)" in body))
        pos = en
    return out


if __name__ == "__main__":
    import sys
    lib, name = sys.argv[1].split(":", 1)
    b = raw_symbol(lib, name)
    print("extends:", re.findall(r'\(extends "([^"]*)"\)', b))
    fp = re.search(r'\(property "Footprint" "([^"]*)"', b)
    print("footprint:", fp.group(1) if fp else None)
    for n, p in sorted(pins(b).items(), key=lambda kv: (len(kv[0]), kv[0])):
        print(f"{n:>4} {p['name']:<14} {p['type']:<14} at({p['x']},{p['y']},{p['angle']}){' HIDDEN' if p['hide'] else ''}")
