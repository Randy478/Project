# Third-party parts

- `ATGM336H-5N31.kicad_sym` - GPS+BDS module symbol, from https://github.com/frohro/Balloon-Beacon (atgm336h-5n31.kicad_sym),
  upgraded to the KiCad 10 format with `kicad-cli sym upgrade`. Its pin map is the u-blox MAX-M8 map (the ATGM336H is pin-compatible):
  pins 1-6, 8-12, 14-17 match KiCad's stock `RF_GPS:MAX-8C`; pins 7/13/18 (VCC_IO / LNA_EN / SAFEBOOT on the u-blox) are NC/Reserved here.
  Verify against the Zhongkewei datasheet before ordering a PCB. Footprint used: KiCad stock `RF_GPS:ublox_MAX` (same 18-pad pattern as the
  module's LCSC footprint, which is that footprint rotated by 90 degrees).
- Display module pin names: Waveshare 2.42inch OLED Module wiki (VCC, GND, DIN, CLK, CS, DC, RES). Other vendors order the 7 header pins differently.
