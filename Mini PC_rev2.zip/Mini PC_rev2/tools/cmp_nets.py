import os, re, sys, json, collections
sys.path.insert(0, os.path.dirname(__file__))
from sexp import parse, child, children
def nets(path):
    t = parse(open(path, encoding="utf8").read())
    out = {}
    for n in children(child(t, "nets"), "net"):
        name = child(n, "name")[1]
        out[name] = frozenset((child(x, "ref")[1], child(x, "pin")[1]) for x in children(n, "node"))
    return out
a, b = nets("orig.net"), nets("new.net")
rm = {"J5", "J6"}
# compare as partitions of pins (net names can change when a pin disappears)
pa = {frozenset(p for p in s if p[0] not in rm) for s in a.values()}
pb = {frozenset(s) for s in b.values()}
pa.discard(frozenset())
print("orig nets:", len(a), "| new nets:", len(b))
print("identical connectivity (ignoring J5/J6 pins):", pa == pb)
if pa != pb:
    print("only in orig:", [sorted(x) for x in pa - pb][:5]); print("only in new:", [sorted(x) for x in pb - pa][:5])
for lab, f in (("orig", "erc_orig.json"), ("new", "erc_new.json")):
    d = json.load(open(f, encoding="utf8"))
    print("ERC", lab, collections.Counter((v["type"], v["severity"]) for s in d["sheets"] for v in s["violations"]).most_common(8))
