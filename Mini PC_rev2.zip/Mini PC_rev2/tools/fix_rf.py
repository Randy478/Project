"""Hand-route the handheld LoRa antenna feed (KiCad CLOSED, KiCad's python):
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\fix_rf.py MiniPC_v2.kicad_pcb [--write]
The autorouter took LORA_ANT (RFM95W U7 pad 9 -> u.FL J10, both on the back) through two vias and In2 to get around U7's GND
pad 10. This replaces it with one 50 ohm (0.3244 mm) B.Cu trace, no vias: out of pad 9 to the right, down past pad 10, into the
u.FL pin; reference plane = the In2 ground pour right under it. Locked."""
import os
import sys

import pcbnew

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0])
WRITE = "--write" in sys.argv
MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))
NET, W = "/LORA_ANT", 0.3244

_keep = pcbnew.LoadBoard(PCB)
board = pcbnew.LoadBoard(PCB)
pad = lambda ref, n: [p for p in board.FindFootprintByReference(ref).Pads() if p.GetNumber() == str(n)][0]
a = pad("U7", 9); a = (TOMM(a.GetX()), TOMM(a.GetY()))
g = pad("U7", 10)
g_right = TOMM(g.GetX()) + TOMM(g.GetSize(pcbnew.B_Cu).x) / 2
c = pad("J10", 1); c = (TOMM(c.GetX()), TOMM(c.GetY()))
xr = g_right + 0.3 + W / 2 + 0.35                    # vertical run: RF clearance (0.3) + margin from the GND pad
pts = [a, (xr, a[1]), (xr, c[1] - (c[0] - xr)), c]   # last leg at 45 deg into the u.FL pin

for t in [t for t in board.GetTracks() if t.GetNetname() == NET]:
    board.Delete(t)
for p, q in zip(pts, pts[1:]):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(V(*p)); t.SetEnd(V(*q)); t.SetWidth(MM(W)); t.SetLayer(pcbnew.B_Cu); t.SetNet(board.FindNet(NET)); t.SetLocked(True)
    board.Add(t); t.thisown = 0
print("LORA_ANT:", " -> ".join("(%.2f, %.2f)" % p for p in pts))
pcbnew.ZONE_FILLER(board).Fill(board.Zones())
if WRITE:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
