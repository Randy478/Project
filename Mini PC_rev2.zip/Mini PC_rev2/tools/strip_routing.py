"""Remove all routing from the board but keep the placement (KiCad CLOSED, KiCad's python):
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\strip_routing.py MiniPC_v2.kicad_pcb [--write]
Deletes every track, via and board-level zone / rule area (ground planes, pours, keep-outs - route_prep.py and post_route.py add
them again). Footprints (incl. their pads' zone-connection settings), positions, the outline and the mouse bites stay. Used by build_pcb.py --keep-placement after parts were moved by hand."""
import os
import sys

import pcbnew

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0])
_keep = pcbnew.LoadBoard(PCB)
board = pcbnew.LoadBoard(PCB)
items = list(board.GetTracks())
zones = list(board.Zones())
for it in items + zones:                       # removals last (they upset KiCad's python wrappers)
    board.Delete(it)
print("removed %d tracks / vias, %d zones" % (len(items), len(zones)))
if "--write" in sys.argv:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
