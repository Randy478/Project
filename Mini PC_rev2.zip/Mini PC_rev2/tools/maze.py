"""Small grid maze router (A*) for the last few connections the autorouter leaves open. Used by fix_opens.py.
Routes one connection of one net on F.Cu / In2.Cu / B.Cu (In1 is the ground plane), 0.1 mm grid, inside a window around the
two ends. A cell is usable on a layer when a track of width w centred there keeps `clr` from every other net's track, via and
pad on that layer and stays 0.3 mm inside the board; vias (0.6 / 0.3) need that on all three layers plus 0.25 mm hole-to-hole.
Rule areas that forbid tracks / vias and the other nets' solid pours (PACK+ / ESC+) are walls; the big ground pours are not
(they are refilled around the new copper). Own-net copper is free space."""
import heapq
import math

import pcbnew

MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
LAYERS = (pcbnew.F_Cu, pcbnew.In2_Cu, pcbnew.B_Cu)
SOFT_ZONES = ("GND pour F", "GND pour B", "GND pour In2", "N_GND pour F", "N_GND pour B", "N_GND pour In2", "GND plane", "N_GND plane")


def route(board, net, a, b, a_layers, b_layers, w_mm, clr_mm=0.2, step_mm=0.1, margin_mm=6.0, via_d=0.6, via_drill=0.3,
          max_expand=1500000):
    """a, b: VECTOR2I; a_layers / b_layers: layer ids the ends may be reached on. Adds the copper to the board and returns
    a description, or None when no path exists."""
    step = MM(step_mm)
    x0 = min(a.x, b.x) - MM(margin_mm); x1 = max(a.x, b.x) + MM(margin_mm)
    y0 = min(a.y, b.y) - MM(margin_mm); y1 = max(a.y, b.y) + MM(margin_mm)
    ebb = board.GetBoardEdgesBoundingBox()
    x0, y0 = max(x0, ebb.GetLeft()), max(y0, ebb.GetTop())
    x1, y1 = min(x1, ebb.GetRight()), min(y1, ebb.GetBottom())
    nx, ny = int((x1 - x0) / step) + 1, int((y1 - y0) / step) + 1
    NL = len(LAYERS)
    cx = lambda i: x0 + i * step
    cy = lambda j: y0 + j * step
    trk = [bytearray(nx * ny) for _ in range(NL)]      # 1 = no track centre here
    via = bytearray(nx * ny)                            # 1 = no via centre here
    # +0.02 mm: straight lines between grid cells (string pulling) can pass a little closer than the cell centres checked
    r_trk, r_via = MM(w_mm / 2 + clr_mm + 0.02), MM(via_d / 2 + clr_mm + 0.02)

    # board outline, 0.3 mm in (+ half the track / via)
    outline = pcbnew.SHAPE_POLY_SET()
    board.GetBoardPolygonOutlines(outline, True)
    in_t = pcbnew.SHAPE_POLY_SET(outline); in_t.Deflate(int(MM(0.3 + w_mm / 2)), pcbnew.CORNER_STRATEGY_ROUND_ALL_CORNERS, int(MM(0.01)))
    in_v = pcbnew.SHAPE_POLY_SET(outline); in_v.Deflate(int(MM(0.3 + via_d / 2)), pcbnew.CORNER_STRATEGY_ROUND_ALL_CORNERS, int(MM(0.01)))
    for j in range(ny):
        for i in range(nx):
            p = pcbnew.VECTOR2I(int(cx(i)), int(cy(j)))
            k = j * nx + i
            if not in_t.Contains(p):
                for l in range(NL):
                    trk[l][k] = 1
            if not in_v.Contains(p):
                via[k] = 1

    def stamp(shape, li, extra_trk, extra_via, bb):
        i0 = max(0, int((bb.GetLeft() - extra_via - x0) / step)); i1 = min(nx - 1, int((bb.GetRight() + extra_via - x0) / step) + 1)
        j0 = max(0, int((bb.GetTop() - extra_via - y0) / step)); j1 = min(ny - 1, int((bb.GetBottom() + extra_via - y0) / step) + 1)
        for j in range(j0, j1 + 1):
            row = j * nx
            for i in range(i0, i1 + 1):
                p = pcbnew.VECTOR2I(int(cx(i)), int(cy(j)))
                k = row + i
                if li is not None and not trk[li][k] and shape.Collide(pcbnew.SEG(p, p), int(extra_trk)):
                    trk[li][k] = 1
                if not via[k] and shape.Collide(pcbnew.SEG(p, p), int(extra_via)):
                    via[k] = 1

    win = pcbnew.BOX2I()
    win.SetOrigin(pcbnew.VECTOR2I(int(x0), int(y0)))
    win.SetEnd(pcbnew.VECTOR2I(int(x1), int(y1)))
    for t in board.GetTracks():
        if t.GetNetname() == net or not t.GetBoundingBox().Intersects(win):
            continue
        for li, lay in enumerate(LAYERS):
            if t.IsOnLayer(lay):
                stamp(t.GetEffectiveShape(lay), li, r_trk, r_via, t.GetBoundingBox())
        if t.GetClass() == "PCB_VIA":                   # hole-to-hole for our vias
            stamp(pcbnew.SHAPE_CIRCLE(t.GetPosition(), int(t.GetDrill() / 2)), None, 0, MM(via_drill / 2 + 0.25), t.GetBoundingBox())
    for f in board.GetFootprints():
        if not f.GetBoundingBox(False).Intersects(win):
            continue
        for p in f.Pads():
            if not p.GetBoundingBox().Intersects(win):
                continue
            if p.GetNetname() != net or not p.GetNetname():
                for li, lay in enumerate(LAYERS):
                    if p.IsOnLayer(lay) or p.HasHole():
                        stamp(p.GetEffectiveShape(lay), li, r_trk, r_via, p.GetBoundingBox())
            if p.HasHole():
                d = max(p.GetDrillSize().x, p.GetDrillSize().y) / 2
                stamp(pcbnew.SHAPE_CIRCLE(p.GetPosition(), int(d)), None, 0, MM(via_drill / 2 + 0.25), p.GetBoundingBox())
    for z in board.Zones():
        if not z.GetBoundingBox().Intersects(win):
            continue
        if z.GetIsRuleArea():
            for li, lay in enumerate(LAYERS):
                if z.IsOnLayer(lay) and (z.GetDoNotAllowTracks() or z.GetDoNotAllowVias()):
                    stamp(z.Outline(), li if z.GetDoNotAllowTracks() else None, r_trk, r_via if z.GetDoNotAllowVias() else 0, z.GetBoundingBox())
        elif z.GetNetname() != net and z.GetZoneName() not in SOFT_ZONES:
            for li, lay in enumerate(LAYERS):
                if z.IsOnLayer(lay):
                    stamp(z.Outline(), li, r_trk, r_via, z.GetBoundingBox())

    def cell(p):
        return min(nx - 1, max(0, int(round((p.x - x0) / step)))), min(ny - 1, max(0, int(round((p.y - y0) / step))))

    ai, aj = cell(a); bi, bj = cell(b)
    starts = [LAYERS.index(l) for l in a_layers if l in LAYERS]
    goals = {LAYERS.index(l) for l in b_layers if l in LAYERS}
    # the ends sit inside their own pad / track, whose other-net neighbours may block the cells right there: free only the cells
    # (within 1 mm of the end) that lie INSIDE that own-net copper, so the first / last hop never cuts past a neighbour
    own = {}
    for li, lay in enumerate(LAYERS):
        sh = [t.GetEffectiveShape(lay) for t in board.GetTracks() if t.GetNetname() == net and t.IsOnLayer(lay)
              and t.GetBoundingBox().Intersects(win)]
        sh += [p.GetEffectiveShape(lay) for f in board.GetFootprints() for p in f.Pads()
               if p.GetNetname() == net and (p.IsOnLayer(lay) or p.HasHole()) and p.GetBoundingBox().Intersects(win)]
        own[li] = sh
    R1 = int(round(1.0 / step_mm))
    for (ci, cj), lays in (((ai, aj), starts), ((bi, bj), goals)):
        for dj in range(-R1, R1 + 1):
            for di in range(-R1, R1 + 1):
                ii, jj = ci + di, cj + dj
                if 0 <= ii < nx and 0 <= jj < ny:
                    p = pcbnew.VECTOR2I(int(cx(ii)), int(cy(jj)))
                    for l in lays:
                        if trk[l][jj * nx + ii] and any(shp.Collide(pcbnew.SEG(p, p), 0) for shp in own[l]):
                            trk[l][jj * nx + ii] = 0
        for l in lays:                                    # the end cell itself (the exact point is own copper)
            trk[l][cj * nx + ci] = 0
    VIA_COST = 12.0
    h = lambda i, j: math.hypot(i - bi, j - bj)
    openq, came, g = [], {}, {}
    for l in starts:
        s = (l, ai, aj)
        g[s] = 0.0
        heapq.heappush(openq, (h(ai, aj), 0.0, s))
    dirs = [(1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0), (1, 1, 1.4142), (1, -1, 1.4142), (-1, 1, 1.4142), (-1, -1, 1.4142)]
    found, n = None, 0
    while openq and n < max_expand:
        _, gc, s = heapq.heappop(openq)
        if gc > g.get(s, 1e18):
            continue
        n += 1
        l, i, j = s
        if i == bi and j == bj and l in goals:
            found = s
            break
        for di, dj, c in dirs:
            ii, jj = i + di, j + dj
            if 0 <= ii < nx and 0 <= jj < ny and not trk[l][jj * nx + ii]:
                t = (l, ii, jj); ng = gc + c
                if ng < g.get(t, 1e18):
                    g[t] = ng; came[t] = s
                    heapq.heappush(openq, (ng + h(ii, jj), ng, t))
        if not via[j * nx + i]:
            for l2 in range(NL):
                if l2 != l and not trk[l2][j * nx + i]:
                    t = (l2, i, j); ng = gc + VIA_COST
                    if ng < g.get(t, 1e18):
                        g[t] = ng; came[t] = s
                        heapq.heappush(openq, (ng + h(i, j), ng, t))
    if found is None:
        return None
    path = [found]
    while path[-1] in came:
        path.append(came[path[-1]])
    path.reverse()

    # path -> tracks + vias (each run string-pulled to a few straight segments)
    netinfo = board.FindNet(net)
    V = lambda i, j: pcbnew.VECTOR2I(int(cx(i)), int(cy(j)))

    def add_seg(p, q, lay):
        if p == q:
            return
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(p); t.SetEnd(q); t.SetWidth(int(MM(w_mm))); t.SetLayer(lay); t.SetNet(netinfo)
        board.Add(t); t.thisown = 0

    nseg, nvia = 0, 0
    runs = []                                            # [(layer, [(i, j), ...])]
    for l, i, j in path:
        if runs and runs[-1][0] == l:
            runs[-1][1].append((i, j))
        else:
            runs.append((l, [(i, j)]))
    def clear_line(l, p, q):
        """every grid cell along p -> q (sampled at half a cell) is usable on layer l"""
        m = int(max(abs(q[0] - p[0]), abs(q[1] - p[1])) * 2) + 1
        for s in range(m + 1):
            i = int(round(p[0] + (q[0] - p[0]) * s / m)); j = int(round(p[1] + (q[1] - p[1]) * s / m))
            if trk[l][j * nx + i]:
                return False
        return True

    for k, (l, pts) in enumerate(runs):
        # string pulling: from each kept point jump to the farthest later point reachable in a straight, clear line
        simp, i = [pts[0]], 0
        while i < len(pts) - 1:
            j = len(pts) - 1
            while j > i + 1 and not clear_line(l, pts[i], pts[j]):
                j -= 1
            simp.append(pts[j]); i = j
        pts_v = [V(*p) for p in simp]
        if k == 0:
            pts_v.insert(0, a)
        if k == len(runs) - 1:
            pts_v.append(b)
        for p, q in zip(pts_v, pts_v[1:]):
            add_seg(p, q, LAYERS[l]); nseg += 1
        if k < len(runs) - 1:
            vv = pcbnew.PCB_VIA(board)
            vv.SetPosition(V(*pts[-1])); vv.SetWidth(int(MM(via_d))); vv.SetDrill(int(MM(via_drill))); vv.SetNet(netinfo)
            board.Add(vv); vv.thisown = 0; nvia += 1
    return "maze %s: %d segments, %d vias (%d cells searched)" % (net, nseg, nvia, n)
