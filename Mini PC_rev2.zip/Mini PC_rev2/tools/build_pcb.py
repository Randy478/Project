"""Place + route the whole panel in one go (KiCad CLOSED). Any python works for this driver; the steps run in KiCad's python:
    python tools\\build_pcb.py [--from-scratch | --keep-placement | --import-only] [--passes=40]
  --import-only     the board is already prepped and routing\\minipc.ses exists: start at the session import (step 4)
  --from-scratch    start again from backup\\MiniPC_v2.before_placement.kicad_pcb (all parts, nothing placed / routed)
  --keep-placement  keep the parts where they are on MiniPC_v2.kicad_pcb (e.g. moved by hand in KiCad): skips place_v2.py,
                    strips any old tracks / vias / zones first (strip_routing.py), then routes as usual
Steps (each script has its own notes):
  1 place_v2.py     placement, outline, slot + mouse bites, J5 / U1 courtyards
  2 route_prep.py   net classes, ground planes, PACK+ / ESC+ pours, hand-drawn locked copper, RF keep-out, DSN export
  3 Freerouting     routing\\minipc.dsn -> routing\\minipc.ses
  4 route_import.py session back onto the board
  5 post_route.py   ground pours on F / In2 / B, stitching vias, 'pins joined inside the part' flags
  6 fix_opens.py    loop with KiCad DRC: closes what the router left open, solid-connects starved pins, nudges vias
                   that are too close to something (max 3 rounds)
  7 silk_fix.py     reference texts clear of pads / silkscreen
  8 final DRC (with schematic parity) -> routing\\drc_final.json, renders -> routing\\top.png / bottom.png"""
import json
import os
import shutil
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PCB = os.path.join(ROOT, "MiniPC_v2.kicad_pcb")
OUT = os.path.join(ROOT, "routing")
KIBIN = os.path.join(os.environ["LOCALAPPDATA"], "Programs", "KiCad", "10.0", "bin")
KIPY, KICLI = os.path.join(KIBIN, "python.exe"), os.path.join(KIBIN, "kicad-cli.exe")
FREEROUTING = r"C:\Users\pc\Documents\usbc-dock\tools\freerouting\freerouting\freerouting.exe"
PASSES = next((a.split("=", 1)[1] for a in sys.argv if a.startswith("--passes=")), "40")
os.makedirs(OUT, exist_ok=True)


def step(name, cmd, **kw):
    print("== %s" % name, flush=True)
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, **kw)
    for line in (r.stdout + r.stderr).splitlines():
        if "image handler" not in line and "memory leak" not in line and line.strip():
            print("   " + line)
    if r.returncode != 0:
        sys.exit("step '%s' failed (exit %d)" % (name, r.returncode))


def tool(script, *a):
    step(script, [KIPY, os.path.join(ROOT, "tools", script), PCB, *a])


def drc(path, parity=False):
    cmd = [KICLI, "pcb", "drc", "--format", "json", "--severity-all", "-o", path, PCB]
    if parity:
        cmd.insert(3, "--schematic-parity")
    subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    d = json.load(open(path, encoding="utf8"))
    # errors + the warnings that are real fab problems (holes drilled into each other, copper ending nowhere)
    errs = [v for v in d["violations"] if v["severity"] == "error" or v["type"] in ("hole_to_hole", "track_dangling", "via_dangling")]
    return d, errs, d.get("unconnected_items", [])


DSN, SES = os.path.join(OUT, "minipc.dsn"), os.path.join(OUT, "minipc.ses")
if "--import-only" not in sys.argv:                    # --import-only: the board is prepped and routing\minipc.ses exists
    if "--from-scratch" in sys.argv:
        shutil.copy2(os.path.join(ROOT, "backup", "MiniPC_v2.before_placement.kicad_pcb"), PCB)
    if "--keep-placement" in sys.argv:
        shutil.copy2(PCB, os.path.join(ROOT, "backup", "MiniPC_v2.hand_placed.kicad_pcb"))
        tool("strip_routing.py", "--write")
    else:
        tool("place_v2.py", "--write")
    shutil.copy2(PCB, os.path.join(ROOT, "backup", "MiniPC_v2.placed.kicad_pcb"))
    tool("route_prep.py", DSN, "--write")
    # single-threaded (-mt 1): Freerouting warns its multi-threaded optimizer makes clearance violations, and one multi-threaded
    # run on this board wrote an empty session file; one retry if the session still comes out empty
    for attempt in (1, 2):
        if os.path.exists(SES):
            os.remove(SES)
        print("== Freerouting (%s passes, attempt %d)" % (PASSES, attempt), flush=True)
        with open(os.path.join(OUT, "fr.log"), "w") as log:
            subprocess.run([FREEROUTING, "-de", DSN, "-do", SES, "-mp", PASSES, "-mt", "1"], cwd=OUT, stdout=log, stderr=subprocess.STDOUT)
        if os.path.exists(SES) and os.path.getsize(SES) > 1000:
            break
if not os.path.exists(SES) or os.path.getsize(SES) < 1000:
    sys.exit("Freerouting wrote no session (see routing\\fr.log)")
tool("route_import.py", SES, "--write")
tool("post_route.py", "--write")
for rnd in range(1, 5):
    path = os.path.join(OUT, "drc_round%d.json" % rnd)
    d, errs, unc = drc(path)
    starved = [v for v in errs if v["type"] == "starved_thermal"]
    print("== DRC round %d: %d errors (%d starved thermals), %d unconnected" % (rnd, len(errs), len(starved), len(unc)), flush=True)
    if not unc and not errs:
        break
    tool("fix_opens.py", path, "--write")
tool("silk_fix.py", "--write")
d, errs, unc = drc(os.path.join(OUT, "drc_final.json"), parity=True)
warn = [v for v in d["violations"] if v["severity"] != "error"]
print("== FINAL DRC: %d errors, %d warnings, %d unconnected, %d schematic parity issues"
      % (len(errs), len(warn), len(unc), len(d.get("schematic_parity", []))))
for v in errs:
    print("   E %s | %s" % (v["type"], " / ".join(i["description"][:60] for i in v["items"])))
for u in unc:
    print("   U %s" % " / ".join(i["description"][:60] for i in u["items"]))
for side in ("top", "bottom"):
    subprocess.run([KICLI, "pcb", "render", "-o", os.path.join(OUT, side + ".png"), "--side", side, "-w", "1500", "-h", "1500",
                    "--use-board-stackup-colors", PCB],
                   cwd=ROOT, capture_output=True)
print("renders: routing\\top.png, routing\\bottom.png")
