"""After route_import.py (KiCad CLOSED, KiCad's python):
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\post_route.py MiniPC_v2.kicad_pcb [--write]
  * ground pours on F.Cu, In2.Cu and B.Cu: GND on the handheld, N_GND on the node (priority 0, under the PACK+ / ESC+ pours),
    thermal reliefs, isolated islands removed. In1.Cu already is the solid ground plane of each board.
  * ground stitching vias (0.6 / 0.3) on a 5 mm grid wherever a via fits with 0.25 mm to all other copper on every layer, so
    the outer pours are tied to the plane (and to each other) all over the board, not only at the parts' ground pins
  * refills all zones"""
import math
import os
import sys

import pcbnew

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0])
WRITE = "--write" in sys.argv
MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))

_keep = pcbnew.LoadBoard(PCB)
board = pcbnew.LoadBoard(PCB)
rect = lambda x0, y0, x1, y1: [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
COPPER = (pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu)

# parts whose duplicate-numbered pins are joined inside the part (6 mm tactile switches: 2 x pin 1, 2 x pin 2; USB-C shell
# tabs 'SH'): tell KiCad, so one connection per pin group is enough (the autorouter only wires one of each pair)
JOINED = []
for f in board.GetFootprints():
    nums = [p.GetNumber() for p in f.Pads() if p.GetNumber()]
    if len(nums) != len(set(nums)) and (f.GetFPID().GetUniStringLibItemName().startswith(("SW_PUSH", "USB_C", "RotaryEncoder"))):
        f.SetDuplicatePadNumbersAreJumpers(True)
        JOINED.append(f.GetReference())
print("duplicate pins joined inside the part:", " ".join(sorted(JOINED)))

# don't add twice
names = {z.GetZoneName() for z in board.Zones()}


def zone(net, layer, pts, name):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer); z.SetNet(board.FindNet(net)); z.SetAssignedPriority(0); z.SetZoneName(name)
    ol = z.Outline(); ol.NewOutline()
    for x, y in pts:
        ol.Append(MM(x), MM(y))
    z.SetLocalClearance(MM(0.25)); z.SetMinThickness(MM(0.25))
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
    z.SetThermalReliefGap(MM(0.3)); z.SetThermalReliefSpokeWidth(MM(0.4))
    z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
    board.Add(z); z.thisown = 0


for lay, ln in ((pcbnew.F_Cu, "F"), (pcbnew.In2_Cu, "In2"), (pcbnew.B_Cu, "B")):
    if "GND pour %s" % ln not in names:
        zone("GND", lay, rect(22.0, 0.0, 100.0, 100.0), "GND pour %s" % ln)
        zone("/N_GND", lay, rect(0.0, 0.0, 20.0, 100.0), "N_GND pour %s" % ln)
pcbnew.ZONE_FILLER(board).Fill(board.Zones())

# ---------------------------------------------------------------- stitching vias
VIA_D, VIA_DRILL, CLR = 0.6, 0.3, 0.25
outline = pcbnew.SHAPE_POLY_SET()
board.GetBoardPolygonOutlines(outline, True)
items = []                                       # (layer set, shape, netname) of every copper item
for t in board.GetTracks():
    for lay in COPPER:
        if t.IsOnLayer(lay):
            items.append((lay, t.GetEffectiveShape(lay), t.GetNetname(), t.GetClass() == "PCB_VIA"))
for f in board.GetFootprints():
    for p in f.Pads():
        for lay in COPPER:
            if p.IsOnLayer(lay) or p.HasHole():
                items.append((lay, p.GetEffectiveShape(lay), p.GetNetname(), p.HasHole()))
holes = [(TOMM(p.GetX()), TOMM(p.GetY()), TOMM(max(p.GetDrillSize().x, p.GetDrillSize().y)) / 2)
         for f in board.GetFootprints() for p in f.Pads() if p.HasHole()]
holes += [(TOMM(t.GetX()), TOMM(t.GetY()), TOMM(t.GetDrill()) / 2) for t in board.GetTracks() if t.GetClass() == "PCB_VIA"]
keepouts = [z for f in board.GetFootprints() for z in f.Zones() if z.GetIsRuleArea()] + [z for z in board.Zones() if z.GetIsRuleArea()]
zones_by = {}
for z in board.Zones():
    if not z.GetIsRuleArea():
        zones_by.setdefault((z.GetLayer(), z.GetNetname()), []).append(z)


def in_fill(layer, net, pt):
    for z in zones_by.get((layer, net), []):
        if z.GetFilledPolysList(layer).Contains(pt):
            return True
    return False


added = 0
for gx in [x * 5.0 + 2.5 for x in range(20)]:
    for gy in [y * 5.0 + 2.5 for y in range(20)]:
        net = "/N_GND" if gx < 20 else "GND" if gx > 22 else None
        if net is None:
            continue
        pt = V(gx, gy)
        if not outline.Contains(pt) or any(z.Outline().Collide(pcbnew.SEG(pt, pt), int(MM(VIA_D / 2 + 0.1))) for z in keepouts):
            continue
        # the via must land in the ground fill on both outer layers (so it really stitches) and clear everything else
        if not (in_fill(pcbnew.F_Cu, net, pt) and in_fill(pcbnew.B_Cu, net, pt)):
            continue
        circ = pcbnew.SHAPE_CIRCLE(pt, int(MM(VIA_D / 2 + CLR)))
        if any(n != net and s.Collide(circ) for (l, s, n, h) in items):
            continue
        if any(math.hypot(gx - hx, gy - hy) < hr + VIA_DRILL / 2 + 0.3 for hx, hy, hr in holes):
            continue
        # outline distance (copper to edge >= 0.3)
        if any(abs(gx - e) < 0.6 for e in (0, 20, 22, 100)) or gy < 0.6 or gy > 99.4:
            continue
        v = pcbnew.PCB_VIA(board)
        v.SetPosition(pt); v.SetWidth(MM(VIA_D)); v.SetDrill(MM(VIA_DRILL)); v.SetNet(board.FindNet(net))
        board.Add(v); v.thisown = 0
        added += 1
print("stitching vias added:", added)
pcbnew.ZONE_FILLER(board).Fill(board.Zones())
if WRITE:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
