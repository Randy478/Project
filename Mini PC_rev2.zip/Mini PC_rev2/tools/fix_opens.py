"""Close what the autorouter left open, driven by KiCad's own DRC report (KiCad CLOSED, KiCad's python):
    kicad-cli pcb drc --format json --severity-all -o routing\\drc.json MiniPC_v2.kicad_pcb
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\fix_opens.py MiniPC_v2.kicad_pcb routing\\drc.json [--write]
  * unconnected pad <-> pad of one net: a straight track, on the first layer (F.Cu, B.Cu, In2.Cu) where it clears every other
    net's track / via / pad by 0.25 mm (pours are refilled around it); if none fits, the grid maze router (maze.py)
  * unconnected ground fragment (GND / N_GND track or pad): a 0.6 / 0.3 via to the In1 ground plane at the nearest free spot,
    with a short stub
  * starved thermal on an SMD pad: that pad gets a solid zone connection (through-hole pins keep their spokes: warning only)
  * ground-pour islands without a via or through-hole pin of their own: one stitching via each, where one fits
Prints what it could not fix; run DRC again afterwards (build_pcb.py loops it)."""
import json
import math
import os
import re
import sys

import pcbnew

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import maze  # noqa: E402

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB, DRC = os.path.abspath(args[0]), os.path.abspath(args[1])
WRITE = "--write" in sys.argv
MM, TOMM = pcbnew.FromMM, pcbnew.ToMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))
GROUNDS = ("GND", "/N_GND")
POWER = ("+3V3", "/N_3V3", "/N_5V", "VBAT", "VBUS", "/VBUSF", "/VBSW", "/VIN", "/BATN", "/LED3V3", "/GPS3V3", "/N_USBV", "/N_BEC")
LAYERS = (pcbnew.F_Cu, pcbnew.B_Cu, pcbnew.In2_Cu)
ALL_CU = (pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu)

_keep = pcbnew.LoadBoard(PCB)
board = pcbnew.LoadBoard(PCB)
drc = json.load(open(DRC, encoding="utf8"))
keepouts = [z for z in board.Zones() if z.GetIsRuleArea()]


def clear_on(layer, shape, net, clr):
    for t in board.GetTracks():
        if t.GetNetname() != net and t.IsOnLayer(layer) and t.GetEffectiveShape(layer).Collide(shape, clr):
            return False
    for f in board.GetFootprints():
        for p in f.Pads():
            if p.GetNetname() != net and (p.IsOnLayer(layer) or p.HasHole()) and p.GetEffectiveShape(layer).Collide(shape, clr):
                return False
    for z in keepouts:
        if z.IsOnLayer(layer) and z.GetDoNotAllowTracks() and z.Outline().Collide(shape):
            return False
    return True


def add_track(a, b, w, layer, net):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(a); t.SetEnd(b); t.SetWidth(int(w)); t.SetLayer(layer); t.SetNet(board.FindNet(net))
    board.Add(t); t.thisown = 0


def add_via(c, net):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(c); v.SetWidth(MM(0.6)); v.SetDrill(MM(0.3)); v.SetNet(board.FindNet(net))
    board.Add(v); v.thisown = 0


def holes():
    return [(t.GetPosition(), t.GetDrill() / 2) for t in board.GetTracks() if t.GetClass() == "PCB_VIA"] + \
           [(p.GetPosition(), max(p.GetDrillSize().x, p.GetDrillSize().y) / 2) for f in board.GetFootprints() for p in f.Pads() if p.HasHole()]


def via_fits(c, net, hl):
    circ = pcbnew.SHAPE_CIRCLE(c, int(MM(0.3)))
    if not all(clear_on(l, circ, net, MM(0.2)) for l in ALL_CU):
        return False
    return all(math.hypot(c.x - h.x, c.y - h.y) >= r + MM(0.15) + MM(0.25) for h, r in hl)


PAD_RE = re.compile(r"pad (\S+) \[(.+?)\] of (\S+)", re.IGNORECASE)
TRK_RE = re.compile(r"(Track|Via) \[(.+?)\] on (\S+)")


def find_pad(ref, num):
    f = board.FindFootprintByReference(ref)
    return [p for p in f.Pads() if p.GetNumber() == num] if f else []


def parse(item):
    """-> ('pad', net, pad) | ('track', net, layer, point) | None"""
    d, pos = item["description"], V(item["pos"]["x"], item["pos"]["y"])
    m = PAD_RE.search(d)
    if m:
        ps = find_pad(m.group(3), m.group(1))
        if ps:
            return ("pad", m.group(2), min(ps, key=lambda p: (p.GetX() - pos.x) ** 2 + (p.GetY() - pos.y) ** 2))
    m = TRK_RE.search(d)
    if m:
        best = None
        for t in board.GetTracks():
            if t.GetNetname() == m.group(2):
                for p in ((t.GetPosition(),) if t.GetClass() == "PCB_VIA" else (t.GetStart(), t.GetEnd())):
                    dd = (p.x - pos.x) ** 2 + (p.y - pos.y) ** 2
                    if best is None or dd < best[0]:
                        best = (dd, t.GetLayer() if t.GetClass() != "PCB_VIA" else pcbnew.F_Cu, pcbnew.VECTOR2I(p.x, p.y))
        if best:
            return ("track", m.group(2), best[1], best[2])
    return None


done, failed = [], []

# ---------------------------------------------------------------- starved thermals -> solid connection on that pin
for v in drc["violations"]:
    if v["type"] == "starved_thermal":
        for it in v["items"]:
            m = PAD_RE.search(it["description"])
            if m:
                # SMD pads only: a through-hole pin that misses a spoke on one crowded layer is still joined on the others and
                # through the In1 plane (DRC reports it as a warning, see MiniPC_v2.kicad_pro); a solid connection to all four
                # layers would make it very hard to hand-solder
                pads = [p for p in find_pad(m.group(3), m.group(1)) if not p.HasHole()]
                for p in pads:
                    p.SetLocalZoneConnection(pcbnew.ZONE_CONNECTION_FULL)
                if pads:
                    done.append("solid zone connection: %s pad %s" % (m.group(3), m.group(1)))


# ---------------------------------------------------------------- vias too close to something / inside a keep-out -> nudge them
def via_near(pos):
    best = None
    for t in board.GetTracks():
        if t.GetClass() == "PCB_VIA":
            d = math.hypot(t.GetX() - pos.x, t.GetY() - pos.y)
            if d < MM(0.05) and (best is None or d < best[0]):
                best = (d, t)
    return best[1] if best else None


def nudge(v, max_mm=0.5):
    """move via v to the nearest spot (<= max_mm) where it and its tracks (dragged along) clear everything by 0.21 mm"""
    old, net, r = v.GetPosition(), v.GetNetname(), v.GetWidth(pcbnew.F_Cu) / 2
    old_xy = (old.x, old.y)
    trs = [t for t in board.GetTracks() if t.GetClass() == "PCB_TRACK" and t.GetNetname() == net
           and old_xy in ((t.GetStart().x, t.GetStart().y), (t.GetEnd().x, t.GetEnd().y))]
    hl = [(h, rr) for h, rr in holes() if (h.x, h.y) != old_xy]
    for k in range(1, int(max_mm / 0.05) + 1):
        for a in range(16):
            c = pcbnew.VECTOR2I(int(old.x + MM(0.05 * k) * math.cos(a * math.pi / 8)), int(old.y + MM(0.05 * k) * math.sin(a * math.pi / 8)))
            if not all(clear_on(l, pcbnew.SHAPE_CIRCLE(c, int(r)), net, MM(0.21)) for l in ALL_CU):
                continue
            if any(math.hypot(c.x - h.x, c.y - h.y) < rr + v.GetDrill() / 2 + MM(0.26) for h, rr in hl):
                continue
            ok = True
            for t in trs:
                o = t.GetEnd() if (t.GetStart().x, t.GetStart().y) == old_xy else t.GetStart()
                if not clear_on(t.GetLayer(), pcbnew.SHAPE_SEGMENT(o, c, t.GetWidth()), net, MM(0.21)):
                    ok = False
                    break
            if ok:
                for t in trs:
                    if (t.GetStart().x, t.GetStart().y) == old_xy:
                        t.SetStart(c)
                    else:
                        t.SetEnd(c)
                v.SetPosition(c)
                return "via %s nudged %.2f mm to (%.2f, %.2f)" % (net, 0.05 * k, TOMM(c.x), TOMM(c.y))
    return None


for v in drc["violations"]:
    if v["severity"] != "error" or v["type"] not in ("clearance", "hole_clearance", "items_not_allowed", "hole_to_hole"):
        continue
    for it in v["items"]:
        if not it["description"].startswith("Via ["):
            continue
        via = via_near(V(it["pos"]["x"], it["pos"]["y"]))
        if via is None:
            continue
        net = via.GetNetname()
        lone = not any(t.GetClass() == "PCB_TRACK" and t.GetNetname() == net and via.GetPosition() in (t.GetStart(), t.GetEnd())
                       for t in board.GetTracks())
        if lone and net in GROUNDS:                       # a stitching via in the wrong place: just drop it
            board.Delete(via)
            done.append("stitching via %s at (%.2f, %.2f) removed (%s)" % (net, it["pos"]["x"], it["pos"]["y"], v["type"]))
            break
        r = nudge(via, 1.0)
        if r:
            done.append(r)
        else:
            # rip it up: the via and the tracks ending on it go; the next DRC round sees the open and maze-routes it with
            # the right clearances
            pos = via.GetPosition()
            gone = [t for t in board.GetTracks() if t.GetClass() == "PCB_TRACK" and t.GetNetname() == net and pos in (t.GetStart(), t.GetEnd())]
            for t in gone:
                board.Delete(t)
            board.Delete(via)
            done.append("ripped up the %s via at (%.2f, %.2f) + %d tracks (%s): rerouted next round" % (net, it["pos"]["x"], it["pos"]["y"], len(gone), v["type"]))
        break

# ---------------------------------------------------------------- same-net vias drilled (almost) on top of each other -> merge
for v in drc["violations"]:
    if v["type"] != "hole_to_hole" or len(v["items"]) != 2 or not all(i["description"].startswith("Via [") for i in v["items"]):
        continue
    va, vb = (via_near(V(i["pos"]["x"], i["pos"]["y"])) for i in v["items"])
    if va is None or vb is None or va.GetNetname() != vb.GetNetname():
        continue
    if math.hypot(va.GetX() - vb.GetX(), va.GetY() - vb.GetY()) > MM(0.6):
        continue
    keep, drop = (va, vb) if va.IsLocked() or not vb.IsLocked() else (vb, va)
    old, new = drop.GetPosition(), keep.GetPosition()
    for t in board.GetTracks():
        if t.GetClass() == "PCB_TRACK" and t.GetNetname() == drop.GetNetname():
            if t.GetStart() == old:
                t.SetStart(new)
            if t.GetEnd() == old:
                t.SetEnd(new)
    board.Delete(drop)
    done.append("merged two %s vias %.2f mm apart at (%.2f, %.2f)" % (keep.GetNetname(), TOMM(math.hypot(old.x - new.x, old.y - new.y)), TOMM(new.x), TOMM(new.y)))

# ---------------------------------------------------------------- unlocked tracks too close to something: rip them up, the next
# DRC round sees the open and maze-routes it with the right clearances (locked hand-drawn copper is never touched)
ripped = set()
for v in drc["violations"]:
    if v["severity"] != "error" or v["type"] not in ("clearance", "tracks_crossing", "shorting_items"):
        continue
    for it in v["items"]:
        if not it["description"].startswith("Track ["):
            continue
        pos = V(it["pos"]["x"], it["pos"]["y"])
        for t in board.GetTracks():
            if t.GetClass() == "PCB_TRACK" and not t.IsLocked() and t.m_Uuid.AsString() not in ripped and t.HitTest(pos, int(MM(0.01))):
                ripped.add(t.m_Uuid.AsString())
                done.append("ripped up a %s track at (%.2f, %.2f) (%s): rerouted next round" % (t.GetNetname(), it["pos"]["x"], it["pos"]["y"], v["type"]))
                board.Delete(t)
                break


# ---------------------------------------------------------------- unconnected items
def drop_ground_via(net, layer, at):
    hl = holes()
    for rad in [i * 0.2 for i in range(0, 20)]:
        n = max(1, int(rad * 20))
        for k in range(n):
            a = 2 * math.pi * k / n
            c = pcbnew.VECTOR2I(int(at.x + MM(rad * math.cos(a))), int(at.y + MM(rad * math.sin(a))))
            if via_fits(c, net, hl) and (rad == 0 or clear_on(layer, pcbnew.SHAPE_SEGMENT(at, c, int(MM(0.2))), net, MM(0.15))):
                add_via(c, net)
                if rad > 0:
                    add_track(at, c, MM(0.2), layer, net)
                return "via %s at (%.2f, %.2f)" % (net, TOMM(c.x), TOMM(c.y))
    return None


for v in drc.get("unconnected_items", []):
    its = [parse(i) for i in v["items"]]
    if any(i is None for i in its) or len(its) != 2:
        if not all("Zone" in i["description"] for i in v["items"]):
            failed.append(" / ".join(i["description"][:60] for i in v["items"]))
        continue
    net = its[0][1]
    if net in GROUNDS:
        for it in its:                                   # tie both ends to the plane (a via on each fragment)
            if it[0] == "pad":
                p = it[2]
                lay = pcbnew.F_Cu if p.IsOnLayer(pcbnew.F_Cu) else pcbnew.B_Cu
                r = None if p.HasHole() else drop_ground_via(net, lay, p.GetPosition())
            else:
                r = drop_ground_via(net, it[2], it[3])
            if not r and not (it[0] == "pad" and it[2].HasHole()):
                # no room for a via (e.g. a TQFP ground pin on the board edge): maze-route to one of the nearest ground vias
                at = it[2].GetPosition() if it[0] == "pad" else it[3]
                lays = ([l for l in LAYERS if it[2].IsOnLayer(l)] if it[0] == "pad" else [it[2]])
                gv = sorted((t for t in board.GetTracks() if t.GetClass() == "PCB_VIA" and t.GetNetname() == net),
                            key=lambda t: (t.GetX() - at.x) ** 2 + (t.GetY() - at.y) ** 2)
                for w_, c_ in ((0.25, 0.2), (0.15, 0.15)):          # 0.15 / 0.15 mm: the fab minimum here is 0.1 / 0.1
                    for t in [t for t in gv if math.hypot(t.GetX() - at.x, t.GetY() - at.y) > MM(1.0)][:3]:
                        r = maze.route(board, net, at, t.GetPosition(), lays, list(LAYERS), w_, clr_mm=c_, margin_mm=3.0)
                        if r:
                            r += " (%.2f mm, to the ground via at %.2f, %.2f)" % (w_, TOMM(t.GetX()), TOMM(t.GetY()))
                            break
                    if r:
                        break
            if r:
                done.append(r)
            elif not (it[0] == "pad" and it[2].HasHole()):
                failed.append("no room for a %s via near %s" % (net, v["items"][its.index(it)]["description"][:60]))
        continue
    a = its[0][2].GetPosition() if its[0][0] == "pad" else its[0][3]
    b = its[1][2].GetPosition() if its[1][0] == "pad" else its[1][3]
    w = MM(0.4) if net in POWER else MM(0.2)
    # a track end can only be joined on its own layer (a pad: any layer it is on / through-hole: all)
    def ok_layers(it):
        if it[0] == "track":
            return {it[2]}
        p = it[2]
        return set(LAYERS) if p.HasHole() else {l for l in LAYERS if p.IsOnLayer(l)}
    lays = [l for l in LAYERS if l in ok_layers(its[0]) and l in ok_layers(its[1])]
    for lay in lays:
        if clear_on(lay, pcbnew.SHAPE_SEGMENT(a, b, int(w)), net, MM(0.25)):
            add_track(a, b, w, lay, net)
            done.append("link %s on %s (%.2f, %.2f)-(%.2f, %.2f)" % (net, board.GetLayerName(lay), TOMM(a.x), TOMM(a.y), TOMM(b.x), TOMM(b.y)))
            break
    else:
        r = maze.route(board, net, a, b, list(ok_layers(its[0])), list(ok_layers(its[1])), TOMM(w), clr_mm=0.2)
        if r is None and w > MM(0.25):
            r = maze.route(board, net, a, b, list(ok_layers(its[0])), list(ok_layers(its[1])), 0.25, clr_mm=0.2)
        if r:
            done.append(r)
        else:
            failed.append("no path for %s (%.2f, %.2f)-(%.2f, %.2f)" % (net, TOMM(a.x), TOMM(a.y), TOMM(b.x), TOMM(b.y)))

pcbnew.ZONE_FILLER(board).Fill(board.Zones())

# ---------------------------------------------------------------- ground-pour islands without their own via
POURS = ("GND pour F", "GND pour B", "GND pour In2", "N_GND pour F", "N_GND pour B", "N_GND pour In2")


def reaches_via(pad):
    """does a chain of same-net tracks lead from this pad to a via or a through-hole pin (i.e. to the plane)?"""
    net, tol = pad.GetNetname(), MM(0.02)
    trs = [t for t in board.GetTracks() if t.GetClass() == "PCB_TRACK" and t.GetNetname() == net]
    anchors = [t.GetPosition() for t in board.GetTracks() if t.GetClass() == "PCB_VIA" and t.GetNetname() == net] +               [p.GetPosition() for f in board.GetFootprints() for p in f.Pads() if p.HasHole() and p.GetNetname() == net]
    lay = pcbnew.F_Cu if pad.IsOnLayer(pcbnew.F_Cu) else pcbnew.B_Cu
    front = [t for t in trs if t.GetLayer() == lay and (pad.HitTest(t.GetStart()) or pad.HitTest(t.GetEnd()))]
    seen = set()
    while front:
        t = front.pop()
        k = t.m_Uuid.AsString()
        if k in seen:
            continue
        seen.add(k)
        for e in (t.GetStart(), t.GetEnd()):
            if any(abs(e.x - a.x) <= tol and abs(e.y - a.y) <= tol for a in anchors):
                return True
            front += [u for u in trs if u.m_Uuid.AsString() not in seen and u.IsOnLayer(t.GetLayer())
                      and any(abs(e.x - q.x) <= tol and abs(e.y - q.y) <= tol for q in (u.GetStart(), u.GetEnd()))]
    return False


isl = 0
for z in list(board.Zones()):
    if z.GetZoneName() not in POURS:
        continue
    lay, net = z.GetLayer(), z.GetNetname()
    fp = z.GetFilledPolysList(lay)
    for i in range(fp.OutlineCount()):
        one = pcbnew.SHAPE_POLY_SET(); one.AddOutline(fp.Outline(i))
        for hh in range(fp.HoleCount(i)):                # the island's own cut-outs: a via in one does not touch it
            one.AddHole(fp.Hole(i, hh))
        hl = holes()
        own = [t.GetPosition() for t in board.GetTracks() if t.GetClass() == "PCB_VIA" and t.GetNetname() == net] +               [p.GetPosition() for f in board.GetFootprints() for p in f.Pads() if p.HasHole() and p.GetNetname() == net]
        if any(one.Contains(pcbnew.VECTOR2I(int(h.x), int(h.y))) for h in own):    # already tied to the plane
            continue
        inner = pcbnew.SHAPE_POLY_SET(one)
        inner.Deflate(int(MM(0.32)), pcbnew.CORNER_STRATEGY_ROUND_ALL_CORNERS, int(MM(0.01)))
        if inner.OutlineCount() == 0:
            continue
        bb, step, ok = inner.BBox(), int(MM(0.25)), False
        for yy in range(bb.GetTop(), bb.GetBottom() + 1, step):
            for xx in range(bb.GetLeft(), bb.GetRight() + 1, step):
                c = pcbnew.VECTOR2I(xx, yy)
                if inner.Contains(c) and via_fits(c, net, hl):
                    add_via(c, net); ok = True; isl += 1
                    break
            if ok:
                break
        if not ok:
            # no room for a via: route the island's own SMD ground pad(s) to one of the nearest ground vias instead
            pads = [p for f in board.GetFootprints() for p in f.Pads()
                    if p.GetNetname() == net and not p.HasHole() and p.IsOnLayer(lay) and one.Contains(p.GetPosition())]
            gv = [t for t in board.GetTracks() if t.GetClass() == "PCB_VIA" and t.GetNetname() == net]
            for pd in [p for p in pads if not reaches_via(p)][:1]:
                at = pd.GetPosition()
                near_v = sorted(gv, key=lambda t: (t.GetX() - at.x) ** 2 + (t.GetY() - at.y) ** 2)
                r = None
                for w_, c_ in ((0.25, 0.2), (0.15, 0.15)):
                    for t in [t for t in near_v if not one.Contains(t.GetPosition())][:4]:
                        r = maze.route(board, net, at, t.GetPosition(), [lay], list(LAYERS), w_, clr_mm=c_, margin_mm=4.0)
                        if r:
                            break
                    if r:
                        break
                if r:
                    done.append(r + " (island %s pad %s)" % (pd.GetParentFootprint().GetReference(), pd.GetNumber()))
                    isl += 1
                else:
                    failed.append("island of %s on %s: no via spot and no route from %s pad %s" % (net, board.GetLayerName(lay), pd.GetParentFootprint().GetReference(), pd.GetNumber()))
done.append("island stitching vias / routes: %d" % isl)
pcbnew.ZONE_FILLER(board).Fill(board.Zones())


# ---------------------------------------------------------------- dead ends (left by rip-ups): tracks with a free end, vias on
# fewer than two things. Only removes copper that connects nothing, repeated until stable.
def touches(pt, lay, net, skip):
    seg = pcbnew.SEG(pt, pt)
    for t in board.GetTracks():
        if t.m_Uuid.AsString() != skip and t.GetNetname() == net and t.IsOnLayer(lay) and t.GetEffectiveShape(lay).Collide(seg, 1000):
            return True
    for f in board.GetFootprints():
        for p in f.Pads():
            if p.GetNetname() == net and (p.IsOnLayer(lay) or p.HasHole()) and p.GetEffectiveShape(lay).Collide(seg, 1000):
                return True
    for z in board.Zones():
        if not z.GetIsRuleArea() and z.GetNetname() == net and z.IsOnLayer(lay) and z.GetFilledPolysList(lay).Contains(pt):
            return True
    return False


dead = 0
for _ in range(10):
    gone = []
    for t in board.GetTracks():
        net = t.GetNetname()
        if t.IsLocked() or not net:
            continue
        if t.GetClass() == "PCB_TRACK":
            me = t.m_Uuid.AsString()
            if not touches(t.GetStart(), t.GetLayer(), net, me) or not touches(t.GetEnd(), t.GetLayer(), net, me):
                gone.append(t)
        elif t.GetClass() == "PCB_VIA":
            n = sum(1 for l in ALL_CU if touches(t.GetPosition(), l, net, t.m_Uuid.AsString()))
            if n < 2:
                gone.append(t)
    if not gone:
        break
    for t in gone:
        board.Delete(t)
    dead += len(gone)
    pcbnew.ZONE_FILLER(board).Fill(board.Zones())
done.append("dead-end tracks / vias removed: %d" % dead)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import manual  # noqa: E402
nd = manual.dedupe(board)                              # identical tracks / vias (two rounds re-routing the same spot)
if nd:
    pcbnew.ZONE_FILLER(board).Fill(board.Zones())
done.append("duplicate tracks / vias removed: %d" % nd)
print("\n".join(done))
for f in failed:
    print("!! " + f)
if WRITE:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
