"""Routing preparation, run after place_v2.py (KiCad CLOSED, KiCad's python):
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\route_prep.py MiniPC_v2.kicad_pcb routing\\minipc.dsn [--write]
  * net classes (MiniPC_v2.kicad_pro): Power 0.4 mm / 0.2 mm, vias 0.6 / 0.3 (0.5 mm does not fit the 0.5 mm pitch MAX17048 or
    SOT-23 pins and the autorouter cannot neck down); GND / N_GND leave the Power class (they are planes, only short via stubs);
    HighCurrent becomes 0.25 mm: the 3S pack current runs in the pours below, the class only carries the Kelvin / divider taps
  * In1.Cu = ground plane layer (type power, the autorouter does not route on it): GND zone under the handheld, N_GND under the node
  * node power block: PACK+ and ESC+ pours on F.Cu + In2.Cu (solid pad connection, stitched with 0.8 / 0.4 vias)
  * hand-drawn, LOCKED copper (manual.py): Kelvin sense traces of the 1 mohm shunt, the battery divider tap, the MAX17048 VBAT
    neck-down stub
  * exports the Specctra DSN for Freerouting. In the DSN ONLY, the two Kelvin traces + their pads are put on temporary nets
    (/N_SENSEP, /N_SENSEM): they share PACK+ / ESC+ with the pours (the shunt joins them inside), and the autorouter would otherwise
    'complete' the net by tying the sense pads to the pours. route_import.py drops those wires and redraws the real ones.
Then:  freerouting.exe -de routing\\minipc.dsn -do routing\\minipc.ses -mp 40
       python tools\\route_import.py MiniPC_v2.kicad_pcb routing\\minipc.ses --write"""
import json
import os
import sys

import pcbnew

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import manual  # noqa: E402

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0])
DSN = os.path.abspath(args[1])
WRITE = "--write" in sys.argv
PRO = os.path.splitext(PCB)[0] + ".kicad_pro"
MM = pcbnew.FromMM
V = manual.V

# ---------------------------------------------------------------- net classes (project file, before the board is loaded)
pro = json.load(open(PRO, encoding="utf8"))
ns = pro["net_settings"]
for c in ns["classes"]:
    if c["name"] == "Power":
        c.update(track_width=0.4, clearance=0.2, via_diameter=0.6, via_drill=0.3)
    if c["name"] == "HighCurrent":
        c.update(track_width=0.25, clearance=0.2, via_diameter=0.6, via_drill=0.3)
ns["netclass_patterns"] = [p for p in ns["netclass_patterns"] if p["pattern"] not in ("GND", "/N_GND")]
if WRITE:
    json.dump(pro, open(PRO, "w", encoding="utf8"), indent=2)

_keep = pcbnew.LoadBoard(PCB)
board = pcbnew.LoadBoard(PCB)
NET = board.FindNet


def zone(net, layer, pts, solid=False, prio=0, name=""):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer); z.SetNet(NET(net)); z.SetAssignedPriority(prio); z.SetZoneName(name)
    ol = z.Outline(); ol.NewOutline()
    for x, y in pts:
        ol.Append(MM(x), MM(y))
    z.SetLocalClearance(MM(0.3) if solid else MM(0.2))
    z.SetMinThickness(MM(0.2))
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL if solid else pcbnew.ZONE_CONNECTION_THERMAL)
    z.SetThermalReliefGap(MM(0.3)); z.SetThermalReliefSpokeWidth(MM(0.4))
    board.Add(z); z.thisown = 0
    return z


rect = lambda x0, y0, x1, y1: [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]

# ---------------------------------------------------------------- planes
board.SetLayerType(pcbnew.In1_Cu, pcbnew.LT_POWER)
zone("GND", pcbnew.In1_Cu, rect(22.0, 0.0, 100.0, 100.0), name="GND plane")
zone("/N_GND", pcbnew.In1_Cu, rect(0.0, 0.0, 20.0, 100.0), name="N_GND plane")

# ---------------------------------------------------------------- node power block
for lay in (pcbnew.F_Cu, pcbnew.In2_Cu):
    zone("/N_PACKP", lay, manual.PACK, solid=True, prio=5, name="PACK+ pour")
    zone("/N_ESCP", lay, manual.ESC, solid=True, prio=5, name="ESC+ pour")
for p in manual.STITCH_P:
    manual.via(board, p, "/N_PACKP", 0.8, 0.4)
for p in manual.STITCH_E:
    manual.via(board, p, "/N_ESCP", 0.8, 0.4)

# keep-out under the handheld RFM95W (back side): no tracks / vias between its pad columns
ko = pcbnew.ZONE(board)
ko.SetIsRuleArea(True); ko.SetLayer(pcbnew.B_Cu); ko.SetZoneName("U7 no-route")
ko.SetDoNotAllowTracks(True); ko.SetDoNotAllowVias(True); ko.SetDoNotAllowPads(False)
ko.SetDoNotAllowFootprints(False); ko.SetDoNotAllowZoneFills(False)
ol = ko.Outline(); ol.NewOutline()
for x, y in manual.u7_keepout_rect(board):
    ol.Append(MM(x), MM(y))
board.Add(ko); ko.thisown = 0

sense = manual.add_all(board)
pcbnew.ZONE_FILLER(board).Fill(board.Zones())
if WRITE:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
    if manual.add_jumper_groups(PCB):
        print("R17: jumper pad groups (1 2) (3 4) added")

# ---------------------------------------------------------------- DSN with the Kelvin traces on temporary nets
for name, items in sense.items():
    net = pcbnew.NETINFO_ITEM(board, name)
    board.Add(net); net.thisown = 0
    for it in items:
        it.SetNet(net)
ok = pcbnew.ExportSpecctraDSN(board, DSN)
print("DSN", "OK" if ok else "FAILED", DSN)
