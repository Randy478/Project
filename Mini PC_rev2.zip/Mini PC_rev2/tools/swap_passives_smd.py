"""Swap every through-hole (or 0805) resistor / capacitor footprint on the PCB for a 1206 SMD one (keeps position, rotation, reference, value, nets and the
schematic link, so 'Update PCB from Schematic' afterwards finds nothing to change). Run with KiCad CLOSED, with KiCad's own python:
    python swap_passives_smd.py <pcb> [--write]
Needed because the handheld + the break-off node must fit one 100 x 100 mm panel (axial resistors are 12.3 x 3.1 mm each)."""
import os
import sys

import pcbnew

HERE = os.path.dirname(os.path.abspath(__file__))
args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0] if args else os.path.join(HERE, "..", "MiniPC_v2.kicad_pcb"))
WRITE = "--write" in sys.argv
KFP = os.path.expandvars(r"%LOCALAPPDATA%\Programs\KiCad\10.0\share\kicad\footprints")
MAP = {
    "R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal": ("Resistor_SMD", "R_1206_3216Metric"),
    "R_0805_2012Metric": ("Resistor_SMD", "R_1206_3216Metric"),
    "C_Disc_D3.8mm_W2.6mm_P2.50mm": ("Capacitor_SMD", "C_1206_3216Metric"),
    "CP_Radial_D5.0mm_P2.50mm": ("Capacitor_SMD", "C_1206_3216Metric"),
    "C_0805_2012Metric": ("Capacitor_SMD", "C_1206_3216Metric"),
}

_keep = pcbnew.LoadBoard(PCB)          # KiCad's python needs the board loaded twice
board = pcbnew.LoadBoard(PCB)
todo = [f for f in list(board.GetFootprints()) if str(f.GetFPID().GetLibItemName()) in MAP]
n = 0
for old in todo:
    nick, name = MAP[str(old.GetFPID().GetLibItemName())]
    new = pcbnew.FootprintLoad(os.path.join(KFP, nick + ".pretty"), name)
    assert new is not None, name
    new.SetFPID(pcbnew.LIB_ID(nick, name))
    new.SetOrientation(old.GetOrientation())
    new.SetPosition(old.GetPosition())
    new.SetReference(old.GetReference())
    new.SetValue(old.GetValue())
    new.SetPath(old.GetPath())
    new.SetSheetname(old.GetSheetname())
    new.SetSheetfile(old.GetSheetfile())
    for pad in list(new.Pads()):
        op = old.FindPadByNumber(pad.GetNumber())
        assert op is not None, (old.GetReference(), pad.GetNumber())
        pad.SetNet(op.GetNet())
    board.Remove(old)
    board.Add(new)
    n += 1
print("swapped %d resistors / capacitors for 1206 SMD" % n)
if WRITE:
    pro = os.path.splitext(PCB)[0] + ".kicad_pro"
    bak = open(pro, "rb").read() if os.path.exists(pro) else None
    pcbnew.SaveBoard(PCB, board)
    if bak is not None:
        open(pro, "wb").write(bak)          # SaveBoard rewrites the project file: put the user's settings back
    chk = pcbnew.LoadBoard(PCB)
    left = [f.GetReference() for f in chk.GetFootprints() if str(f.GetFPID().GetLibItemName()) in MAP]
    print("  saved; footprints:", len(list(chk.GetFootprints())), "| passives left on the old footprints:", left)
