"""Move the two custom symbols the original schematic carried (MyLibraries:SSD1306, New_Library:ESP32-S3-WROOM-1) into a project
library (MiniPC_v2.kicad_sym) so the project no longer depends on files under C:/Users/Administrator/. Idempotent."""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from sexp import balanced_end

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCH = os.path.join(ROOT, "MiniPC_v2.kicad_sch")
LIB = "MiniPC_v2"
OLD = ["MyLibraries:SSD1306", "New_Library:ESP32-S3-WROOM-1"]

t = open(SCH, encoding="utf8").read()
blocks = []
for old in OLD:
    m = re.search(r'\n\t\t\(symbol "%s"' % re.escape(old), t)
    if not m:
        print("already localised or missing:", old)
        continue
    st = t.index("(", m.start())
    block = t[st:balanced_end(t, st)]
    name = old.split(":", 1)[1]
    blocks.append(block.replace('(symbol "%s"' % old, '(symbol "%s"' % name, 1))
if blocks:
    t = t.replace("MyLibraries:", LIB + ":").replace("New_Library:", LIB + ":")
    open(SCH, "w", encoding="utf8", newline="\n").write(t)
    body = "\n".join("\t" + l for blk in blocks for l in blk.split("\n"))
    lib = ('(kicad_symbol_lib\n\t(version 20251024)\n\t(generator "kicad_symbol_editor")\n\t(generator_version "10.0")\n'
           + body + "\n)\n")
    open(os.path.join(ROOT, LIB + ".kicad_sym"), "w", encoding="utf8", newline="\n").write(lib)
open(os.path.join(ROOT, "sym-lib-table"), "w", encoding="utf8", newline="\n").write(
    '(sym_lib_table\n\t(version 7)\n\t(lib (name "%s")(type "KiCad")(uri "${KIPRJMOD}/%s.kicad_sym")(options "")(descr "Parts carried over from the original Mini PC"))\n)\n' % (LIB, LIB))
open(os.path.join(ROOT, "fp-lib-table"), "w", encoding="utf8", newline="\n").write('(fp_lib_table\n\t(version 7)\n)\n')
print("project library written with", len(blocks), "symbol(s)")
