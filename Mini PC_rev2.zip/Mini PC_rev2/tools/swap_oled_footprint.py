"""Swap J5 on the PCB to the full-size screen footprint (MiniPC_v2.pretty/OLED_2.42_SSD1309_Module), keeping its nets, reference, value and
schematic link, so 'Update PCB from Schematic' afterwards finds nothing to change. Run with KiCad CLOSED, with KiCad's own python:
    python swap_oled_footprint.py <pcb> [--at X,Y] [--write]
--at X,Y   place pad 1 at X,Y mm (default: keep the position J5 has now); the module extends 41 mm upwards and 28.4 mm left / 43.6 mm right of it.
Run tools/silkscreen.py --write afterwards (pin names under the header)."""
import os
import sys

import pcbnew

HERE = os.path.dirname(os.path.abspath(__file__))
args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0] if args else os.path.join(HERE, "..", "MiniPC_v2.kicad_pcb"))
WRITE = "--write" in sys.argv
AT = None
if "--at" in sys.argv:
    AT = [float(v) for v in sys.argv[sys.argv.index("--at") + 1].split(",")]
LIBDIR = os.path.join(HERE, "..", "MiniPC_v2.pretty")
NAME = "OLED_2.42_SSD1309_Module"
MM = pcbnew.FromMM

_keep = pcbnew.LoadBoard(PCB)          # KiCad's python needs the board loaded twice
board = pcbnew.LoadBoard(PCB)
old = board.FindFootprintByReference("J5")
if old is None:
    sys.exit("J5 not found")
if str(old.GetFPID().GetLibItemName()) == NAME:
    print("J5 already uses", NAME)
new = pcbnew.FootprintLoad(os.path.abspath(LIBDIR), NAME)
if new is None:
    sys.exit("footprint not found in " + LIBDIR)
new.SetFPID(pcbnew.LIB_ID("MiniPC_v2", NAME))
pos = pcbnew.VECTOR2I(MM(AT[0]), MM(AT[1])) if AT else old.GetPosition()
new.SetPosition(pos)
new.SetOrientation(old.GetOrientation())
new.SetReference(old.GetReference())
new.SetValue(old.GetValue())
new.SetPath(old.GetPath())
new.SetSheetname(old.GetSheetname())
new.SetSheetfile(old.GetSheetfile())
for pad in list(new.Pads()):
    op = old.FindPadByNumber(pad.GetNumber())
    assert op is not None, "pad " + pad.GetNumber()
    pad.SetNet(op.GetNet())
nets = {p.GetNumber(): p.GetNetname() for p in new.Pads()}
print("J5 ->", NAME, "at", pcbnew.ToMM(pos.x), pcbnew.ToMM(pos.y), "nets", nets)
board.Remove(old)
board.Add(new)

if WRITE:
    pro = os.path.splitext(PCB)[0] + ".kicad_pro"
    bak = open(pro, "rb").read() if os.path.exists(pro) else None
    pcbnew.SaveBoard(PCB, board)
    if bak is not None:
        open(pro, "wb").write(bak)          # SaveBoard rewrites the project file: put the user's settings back
    chk = pcbnew.LoadBoard(PCB)
    j5 = chk.FindFootprintByReference("J5")
    print("  saved; J5 is", j5.GetFPID().GetUniStringLibId(), "| pad nets:", {p.GetNumber(): p.GetNetname() for p in j5.Pads()},
          "| footprints:", len(list(chk.GetFootprints())))
