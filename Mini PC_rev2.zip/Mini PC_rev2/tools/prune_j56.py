"""Remove J5 (TP4056 charger) and J6 (step-up module) from the original Mini PC schematic, then prune the wires/junctions that were
only there to reach them. Writes ../MiniPC_v2.kicad_sch (new root UUID, new project name). Original file is never touched.
  python prune_j56.py [--dry]"""
import math
import os
import re
import sys
import uuid

sys.path.insert(0, os.path.dirname(__file__))
from sexp import parse, child, children, props, balanced_end

SRC = r"D:\Projects\Mini PC\Mini PC.kicad_sch"
OUT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "MiniPC_v2.kicad_sch"))
REMOVE = {"J5", "J6"}
DRY = "--dry" in sys.argv
text = open(SRC, encoding="utf8").read()

# ---- top-level blocks with spans ------------------------------------------------------------
root_start = text.index("(kicad_sch")
blocks = []          # (start, end, node)
i = text.index("\n\t(", root_start) + 1
while i < len(text):
    while i < len(text) and text[i] in " \t\r\n":
        i += 1
    if i >= len(text) or text[i] != "(":
        break
    e = balanced_end(text, i)
    blocks.append((i, e, parse(text[i:e])))
    i = e
    if text[i:i + 2].strip() == ")" or text[i:].lstrip().startswith(")"):
        pass
print("top-level blocks:", len(blocks))


def pt(node):
    a = child(node, "at")
    return float(a[1]), float(a[2])


libsyms = {}
lib_node = next(n for _, _, n in blocks if n[0] == "lib_symbols")
for s in lib_node[1:]:
    if isinstance(s, list) and s and s[0] == "symbol":
        libsyms[s[1]] = s


def pin_points(inst):
    lid = child(inst, "lib_id")[1]
    at = child(inst, "at")
    ox, oy = float(at[1]), float(at[2])
    rot = int(float(at[3])) if len(at) > 3 else 0
    mir = child(inst, "mirror")
    mir = mir[1] if mir else None
    ls = libsyms[lid]
    out = {}

    def walk(n):
        for c in n:
            if isinstance(c, list) and c:
                if c[0] == "pin" and child(c, "at") and child(c, "number"):
                    a = child(c, "at")
                    out[child(c, "number")[1]] = (float(a[1]), float(a[2]))
                walk(c)
    walk(ls)
    res = {}
    for num, (px, py) in out.items():
        x, y = px, py
        if mir == "x":
            y = -y
        elif mir == "y":
            x = -x
        r = math.radians(rot)
        xr = x * math.cos(r) - y * math.sin(r)
        yr = x * math.sin(r) + y * math.cos(r)
        res[num] = (round(ox + xr, 2), round(oy - yr, 2))
    return res


symbols = {}
for s, e, n in blocks:
    if n[0] == "symbol" and child(n, "lib_id"):
        symbols[props(n)["Reference"]] = (s, e, n)

wires = []           # (start, end, (x1,y1),(x2,y2))
junctions = []       # (start, end, (x,y))
for s, e, n in blocks:
    if n[0] == "wire":
        p = child(n, "pts")
        xy = [(round(float(c[1]), 2), round(float(c[2]), 2)) for c in p if isinstance(c, list) and c[0] == "xy"]
        wires.append((s, e, xy[0], xy[1]))
    elif n[0] == "junction":
        a = child(n, "at")
        junctions.append((s, e, (round(float(a[1]), 2), round(float(a[2]), 2))))


def dangling_points(live_syms, live_wires, live_juncs):
    pins = set()
    for r in live_syms:
        pins.update(pin_points(symbols[r][2]).values())
    jset = {j[2] for j in live_juncs}
    count = {}
    for w in live_wires:
        for p in (w[2], w[3]):
            count[p] = count.get(p, 0) + 1
    return {p for p, c in count.items() if c == 1 and p not in pins and p not in jset}


all_refs = list(symbols)
keep_refs = [r for r in all_refs if r not in REMOVE]
d0 = dangling_points(all_refs, wires, junctions)
print("originally dangling wire ends (left alone):", len(d0))

# pins of the removed parts and the wires touching them
for r in sorted(REMOVE):
    pp = pin_points(symbols[r][2])
    hits = {num: [k for k, w in enumerate(wires) if p in (w[2], w[3])] for num, p in pp.items()}
    print(r, props(symbols[r][2])["Value"], "pins:", {n: (p, len(hits[n])) for n, p in pp.items()})

live_w = list(range(len(wires)))
removed_w = []
while True:
    cur_w = [wires[k] for k in live_w]
    dp = dangling_points(keep_refs, cur_w, junctions)
    bad = [k for k in live_w if (wires[k][2] in dp and wires[k][2] not in d0) or (wires[k][3] in dp and wires[k][3] not in d0)]
    if not bad:
        break
    for k in bad:
        live_w.remove(k)
        removed_w.append(k)
print("wire segments removed:", len(removed_w), "of", len(wires))

# junctions that no longer join >= 3 things (only those touching removed wires)
touched = set()
for k in removed_w:
    touched.update((wires[k][2], wires[k][3]))
pins_keep = set()
for r in keep_refs:
    pins_keep.update(pin_points(symbols[r][2]).values())
removed_j = []
for k, (s, e, p) in enumerate(junctions):
    if p in touched:
        n_conn = sum(1 for w in (wires[q] for q in live_w) if p in (w[2], w[3])) + (1 if p in pins_keep else 0)
        if n_conn < 3:
            removed_j.append(k)
print("junctions removed:", len(removed_j), "of", len(junctions))

if DRY:
    sys.exit(0)

# ---- rebuild the file -------------------------------------------------------------------------
kill = [(symbols[r][0], symbols[r][1]) for r in REMOVE]
kill += [(wires[k][0], wires[k][1]) for k in removed_w]
kill += [(junctions[k][0], junctions[k][1]) for k in removed_j]
# drop the unused library symbols of the removed parts
for r in REMOVE:
    lid = child(symbols[r][2], "lib_id")[1]
    if not any(child(symbols[q][2], "lib_id")[1] == lid for q in keep_refs):
        m = re.search(r'\n\t\t\(symbol "%s"' % re.escape(lid), text)
        if m:
            st = m.start() + 1
            kill.append((st, balanced_end(text, st + 2 if False else text.index("(", st))))
kill.sort(reverse=True)
out = text
for s, e in kill:
    # swallow the whole line(s): leading indentation + trailing newline
    ls = out.rfind("\n", 0, s) + 1
    le = out.find("\n", e) + 1
    out = out[:ls] + out[le:]

old_root = child(parse(text), "uuid")[1]
new_root = str(uuid.uuid5(uuid.NAMESPACE_URL, "MiniPC_v2/root"))
out = out.replace(old_root, new_root)
out = out.replace('(project "Mini PC"', '(project "MiniPC_v2"')
open(OUT, "w", encoding="utf8", newline="\n").write(out)
print("wrote", OUT, "| new root uuid", new_root)
