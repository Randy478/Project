﻿"""Reset the PCB to an empty 100 x 100 mm board with rounded corners: every footprint, track, via, zone, drawing, text and group is removed, only the
board outline (4 lines + 4 arcs on Edge.Cuts, origin at 0,0) stays, with the layer stack / design settings / net classes untouched.
Run with KiCad CLOSED, with KiCad's own python:    python reset_pcb.py <pcb> [size_mm] [radius_mm] --write
The schematic is not touched: 'Update PCB from Schematic' brings the parts back (parked beside the board). Earlier layouts: backup/ ."""
import math
import os
import sys

import pcbnew

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB = os.path.abspath(args[0])
SIZE = float(args[1]) if len(args) > 1 else 100.0
R = float(args[2]) if len(args) > 2 else 2.0
WRITE = "--write" in sys.argv
MM = pcbnew.FromMM
V = lambda x, y: pcbnew.VECTOR2I(int(round(MM(x))), int(round(MM(y))))

_keep = pcbnew.LoadBoard(PCB)          # KiCad's python needs the board loaded twice
board = pcbnew.LoadBoard(PCB)
old_edges = [d for d in list(board.GetDrawings()) if d.GetLayer() == pcbnew.Edge_Cuts]
EW = pcbnew.ToMM(old_edges[0].GetWidth()) if old_edges else 0.05
groups = {
    "footprints": list(board.GetFootprints()),
    "tracks / vias": list(board.GetTracks()),
    "zones": list(board.Zones()),
    "drawings / texts": list(board.GetDrawings()),
    "groups": list(board.Groups()),
}
for name, items in groups.items():
    print("removing %4d %s" % (len(items), name))
for name in ("groups", "footprints", "tracks / vias", "zones", "drawings / texts"):
    for it in groups[name]:
        board.Remove(it)

x0 = y0 = 0.0
x1 = y1 = SIZE


def shape(kind):
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(kind)
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(MM(EW))
    board.Add(s)
    return s


def line(ax, ay, bx, by):
    s = shape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(V(ax, ay))
    s.SetEnd(V(bx, by))


def arc(cx, cy, sx, sy, ex, ey, mdx, mdy):
    s = shape(pcbnew.SHAPE_T_ARC)
    k = math.sqrt(0.5) * R
    s.SetArcGeometry(V(sx, sy), V(cx + mdx * k, cy + mdy * k), V(ex, ey))


line(x0 + R, y0, x1 - R, y0)
line(x1, y0 + R, x1, y1 - R)
line(x1 - R, y1, x0 + R, y1)
line(x0, y1 - R, x0, y0 + R)
arc(x0 + R, y0 + R, x0, y0 + R, x0 + R, y0, -1, -1)
arc(x1 - R, y0 + R, x1 - R, y0, x1, y0 + R, 1, -1)
arc(x1 - R, y1 - R, x1, y1 - R, x1 - R, y1, 1, 1)
arc(x0 + R, y1 - R, x0 + R, y1, x0, y1 - R, -1, 1)

# nets that no part uses any more: drop them as well (best effort, the call differs between KiCad versions)
for call in (lambda: board.RemoveUnusedNets(None), lambda: board.RemoveUnusedNets()):
    try:
        call()
        break
    except Exception as e:
        last = e

if WRITE:
    pro = os.path.splitext(PCB)[0] + ".kicad_pro"
    bak = open(pro, "rb").read() if os.path.exists(pro) else None
    pcbnew.SaveBoard(PCB, board)
    if bak is not None:
        open(pro, "wb").write(bak)          # SaveBoard rewrites the project file: put the user's settings back
    chk = pcbnew.LoadBoard(PCB)
    bb = chk.GetBoardEdgesBoundingBox()
    print("saved: %d footprints, %d tracks, %d zones, %d drawings (outline), board edges %.2f x %.2f mm, nets in the file: %d"
          % (len(list(chk.GetFootprints())), len(list(chk.GetTracks())), len(list(chk.Zones())), len(list(chk.GetDrawings())),
             pcbnew.ToMM(bb.GetWidth()), pcbnew.ToMM(bb.GetHeight()), chk.GetNetCount()))
