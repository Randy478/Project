"""Add C35 = 1 uF (1206) from the ESP32's EN pin to GND (KiCad CLOSED, KiCad's python):
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\add_en_cap.py [--sch] [--pcb <board.kicad_pcb> ...]
Espressif's ESP32-S3-WROOM-1 reference circuit puts an RC on EN (10 k pull-up R4 + 1 uF to GND) so the chip comes out of reset only
after its supply is stable; rev 2 had the pull-up but no capacitor (the rev-1 board did not have one either).
  --sch   inserts the symbol into MiniPC_v2.kicad_sch next to R4 (label EN on pin 1, a GND power symbol on pin 2), same style
          as add_parts.py; skipped if C35 already exists
  --pcb   adds the matching footprint (Capacitor_SMD:C_1206_3216Metric, nets /EN + GND, linked to the symbol) to each board given,
          parked off the board; place_v2.py then puts it next to U1's EN pin. Skipped where C35 exists."""
import os
import re
import sys
import uuid

import pcbnew

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SCH = os.path.join(ROOT, "MiniPC_v2.kicad_sch")
FPLIB = os.path.join(os.environ["LOCALAPPDATA"], "Programs", "KiCad", "10.0", "share", "kicad", "footprints", "Capacitor_SMD.pretty")
REF, VALUE, FP = "C35", "1uF", "Capacitor_SMD:C_1206_3216Metric"
X, Y = 77.47, 64.77                                  # schematic position, next to R4 (EN pull-up)
U = lambda tag: str(uuid.uuid5(uuid.NAMESPACE_URL, "MiniPC_v2/en-cap/" + tag))
SYM_UUID = U("symbol")


def block_after(s, i):
    d, j = 0, i
    while True:
        d += s[j] == "("; d -= s[j] == ")"; j += 1
        if d == 0:
            return s[i:j]


def add_sch():
    s = open(SCH, encoding="utf8").read()
    if '(property "Reference" "%s"' % REF in s:
        print("schematic: %s already there" % REF)
        return
    # clone C31 (Device:C, C_1206) and the GND power symbol of C14
    k = s.find('(property "Reference" "C31"')
    cap = block_after(s, s.rfind("\t(symbol\n", 0, k) + 1)
    k = s.find('(property "Reference" "#PWR028"')
    gnd = block_after(s, s.rfind("\t(symbol\n", 0, k) + 1)
    ox, oy = re.search(r'\(at ([\d.\-]+) ([\d.\-]+) 0\)', cap).groups()
    gx, gy = re.search(r'\(at ([\d.\-]+) ([\d.\-]+) 0\)', gnd).groups()
    shift = lambda blk, x0, y0, x1, y1: re.sub(r'\(at ([\d.\-]+) ([\d.\-]+)',
                                               lambda m: "(at %s %s" % (round(float(m.group(1)) - float(x0) + x1, 4), round(float(m.group(2)) - float(y0) + y1, 4)), blk)
    cap = shift(cap, ox, oy, X, Y)
    cap = cap.replace('"Reference" "C31"', '"Reference" "%s"' % REF).replace('(reference "C31")', '(reference "%s")' % REF)
    cap = re.sub(r'\(property "Value" "[^"]*"', '(property "Value" "%s"' % VALUE, cap, count=1)
    n = [0]

    def newuuid(m):
        n[0] += 1
        return '(uuid "%s")' % (SYM_UUID if n[0] == 1 else U("cap-%d" % n[0]))
    cap = re.sub(r'\(uuid "[^"]*"\)', newuuid, cap)
    pwr = max(int(p) for p in re.findall(r'"#PWR(\d+)"', s)) + 1
    gnd = shift(gnd, gx, gy, X, Y + 3.81)
    gnd = gnd.replace('"#PWR028"', '"#PWR%03d"' % pwr)
    n2 = [0]

    def newuuid2(m):
        n2[0] += 1
        return '(uuid "%s")' % U("gnd-%d" % n2[0])
    gnd = re.sub(r'\(uuid "[^"]*"\)', newuuid2, gnd)
    label = ('\t(label "EN"\n\t\t(at %s %s 90)\n\t\t(effects\n\t\t\t(font\n\t\t\t\t(size 1.27 1.27)\n\t\t\t)\n\t\t\t(justify left bottom)\n'
             '\t\t)\n\t\t(uuid "%s")\n\t)\n') % (X, round(Y - 3.81, 4), U("label"))
    note = ('\t(text "C35: EN RC (R4 10k + 1uF), Espressif reference circuit"\n\t\t(exclude_from_sim no)\n\t\t(at %s %s 0)\n\t\t(effects\n'
            '\t\t\t(font\n\t\t\t\t(size 1.27 1.27)\n\t\t\t)\n\t\t\t(justify left bottom)\n\t\t)\n\t\t(uuid "%s")\n\t)\n') % (X + 3.81, round(Y + 1.27, 4), U("note"))
    i = s.rfind("\n\t(sheet_instances")
    s = s[:i + 1] + "\t" + cap + "\n" + label + "\t" + gnd + "\n" + note + s[i + 1:]
    open(SCH, "w", encoding="utf8").write(s)
    print("schematic: %s %s added at (%.2f, %.2f), EN label + #PWR%03d" % (REF, VALUE, X, Y, pwr))


def set_description(f):
    """same Description field as the symbol (Device:C), or the schematic-parity check flags it"""
    for fld in f.GetFields():
        if fld.GetName() == "Description":
            fld.SetText("Unpolarized capacitor")
            return


def add_pcb(path):
    _k = pcbnew.LoadBoard(path)
    b = pcbnew.LoadBoard(path)
    old = b.FindFootprintByReference(REF)
    if old is not None:
        set_description(old)
        pcbnew.SaveBoard(path, b, True)
        print("%s: %s already there (description field refreshed)" % (os.path.basename(path), REF))
        return
    f = pcbnew.FootprintLoad(FPLIB, "C_1206_3216Metric")
    set_description(f)
    f.SetFPIDAsString(FP)
    f.SetReference(REF)
    f.SetValue(VALUE)
    f.Value().SetLayer(pcbnew.F_Fab)                 # passives: only the reference on silkscreen (README)
    f.SetPath(pcbnew.KIID_PATH("/" + SYM_UUID))
    f.SetSheetname("/")
    f.SetSheetfile("MiniPC_v2.kicad_sch")
    for p in f.Pads():
        p.SetNet(b.FindNet("/EN" if p.GetNumber() == "1" else "GND"))
    f.SetPosition(pcbnew.VECTOR2I(int(pcbnew.FromMM(110)), int(pcbnew.FromMM(60))))
    b.Add(f); f.thisown = 0
    pcbnew.SaveBoard(path, b, True)
    print("%s: %s footprint added (nets /EN, GND)" % (os.path.basename(path), REF))


if "--sch" in sys.argv:
    add_sch()
if "--pcb" in sys.argv:
    for p in sys.argv[sys.argv.index("--pcb") + 1:]:
        if not p.startswith("--"):
            add_pcb(os.path.abspath(p))
