"""Add the new parts to MiniPC_v2.kicad_sch AND wire every part (net labels on the pin ends, no-connect flags on unused pins, PWR_FLAGs), replacing the old 4-pin I2C OLED header (Brd1)
with a 7-pin SPI OLED header for the 2.42in SSD1309 module.
Run after: prune_j56.py -> localize_libs.py -> strip_connections.py.  Idempotent (refuses to run twice).
Also writes tools/parts_groups.json (used by gen_pcb_v2.py) and adds the MAX17048 symbol to MiniPC_v2.kicad_sym."""
import json
import math
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
import sch_lib
from sch_lib import Schematic, CUSTOM, CUSTOM_LIB, snap, sym
from sexp import parse, child, props, balanced_end

sch_lib.QUIET = True
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCH = os.path.join(ROOT, "MiniPC_v2.kicad_sch")
LIBFILE = os.path.join(ROOT, "MiniPC_v2.kicad_sym")
KFP = os.path.expandvars(r"%LOCALAPPDATA%\Programs\KiCad\10.0\share\kicad\footprints")
KSYM = os.path.expandvars(r"%LOCALAPPDATA%\Programs\KiCad\10.0\share\kicad\symbols")

text = open(SCH, encoding="utf8").read()
if "AMS1117 + D1 were deleted" in text:
    sys.exit("already added")


# ------------------------------------------------------------------ custom symbol: MAX17048 fuel gauge (not in KiCad's library)
def make_symbol(name, ref, value, footprint, desc, body, pins):
    x1, y1, x2, y2 = body
    p = []
    for num, pname, ptype, x, y, ang, hide in pins:
        p.append(f'\t\t(pin {ptype} line\n\t\t\t(at {x} {y} {ang})\n\t\t\t(length 2.54)\n'
                 + ("\t\t\t(hide yes)\n" if hide else "")
                 + f'\t\t\t(name "{pname}"\n\t\t\t\t(effects\n\t\t\t\t\t(font\n\t\t\t\t\t\t(size 1.27 1.27)\n\t\t\t\t\t)\n\t\t\t\t)\n\t\t\t)\n'
                 + f'\t\t\t(number "{num}"\n\t\t\t\t(effects\n\t\t\t\t\t(font\n\t\t\t\t\t\t(size 1.27 1.27)\n\t\t\t\t\t)\n\t\t\t\t)\n\t\t\t)\n\t\t)\n')

    def prop(n, v, y, hide=False):
        return (f'\t(property "{n}" "{v}"\n\t\t(at 0 {y} 0)\n' + ("\t\t(hide yes)\n" if hide else "")
                + '\t\t(show_name no)\n\t\t(do_not_autoplace no)\n\t\t(effects\n\t\t\t(font\n\t\t\t\t(size 1.27 1.27)\n\t\t\t)\n\t\t)\n\t)\n')
    return (f'(symbol "{name}"\n\t(pin_names\n\t\t(offset 1.016)\n\t)\n\t(exclude_from_sim no)\n\t(in_bom yes)\n\t(on_board yes)\n'
            f'\t(in_pos_files yes)\n\t(duplicate_pin_numbers_are_jumpers no)\n'
            + prop("Reference", ref, y1 + 2.54) + prop("Value", value, y2 - 2.54)
            + prop("Footprint", footprint, 0, True) + prop("Datasheet", "", 0, True) + prop("Description", desc, 0, True)
            + f'\t(symbol "{name}_0_1"\n\t\t(rectangle\n\t\t\t(start {x1} {y1})\n\t\t\t(end {x2} {y2})\n\t\t\t(stroke\n\t\t\t\t(width 0.254)\n'
              f'\t\t\t\t(type default)\n\t\t\t)\n\t\t\t(fill\n\t\t\t\t(type background)\n\t\t\t)\n\t\t)\n\t)\n'
            + f'\t(symbol "{name}_1_1"\n' + "".join(p) + '\t)\n)')


MAX17048 = make_symbol(
    "MAX17048", "U", "MAX17048", "Package_DFN_QFN:TDFN-8-1EP_2x2mm_P0.5mm_EP0.8x1.2mm",
    "1S LiPo fuel gauge, ModelGauge, I2C (0x36), 3uA. TDFN-8 2x2. Pinout from Maxim datasheet 19-6171.",
    (-7.62, 7.62, 7.62, -7.62),
    [("1", "CTG", "passive", -10.16, -5.08, 0, False),
     ("2", "CELL", "passive", -2.54, 10.16, 270, False),
     ("3", "VDD", "power_in", 2.54, 10.16, 270, False),
     ("4", "GND", "power_in", 0, -10.16, 90, False),
     ("9", "EP", "passive", 0, -10.16, 90, True),
     ("5", "ALRT", "open_collector", 10.16, 2.54, 180, False),
     ("6", "QSTRT", "input", -10.16, -2.54, 0, False),
     ("7", "SCL", "input", -10.16, 0, 0, False),
     ("8", "SDA", "bidirectional", -10.16, 2.54, 0, False)])
CUSTOM[f"{CUSTOM_LIB}:MAX17048"] = MAX17048

# 2.42in OLED module (pin names from the Waveshare wiki; other vendors order the header pins differently)
OLED242 = make_symbol(
    "OLED_2.42_SSD1309", "J", "OLED 2.42in SSD1309", "MiniPC_v2:OLED_2.42_SSD1309_Module",     # tools/make_oled_footprint.py: full 72 x 43.5 mm module outline
    "2.42in 128x64 OLED module, SSD1309, 4-wire SPI. Pin names from the Waveshare 2.42inch OLED Module wiki; other vendors order the pins differently.",
    (-7.62, 10.16, 7.62, -10.16),
    [("1", "VCC", "power_in", -10.16, 7.62, 0, False), ("2", "GND", "power_in", -10.16, 5.08, 0, False),
     ("3", "DIN", "input", -10.16, 2.54, 0, False), ("4", "CLK", "input", -10.16, 0, 0, False),
     ("5", "CS", "input", -10.16, -2.54, 0, False), ("6", "DC", "input", -10.16, -5.08, 0, False),
     ("7", "RES", "input", -10.16, -7.62, 0, False)])
CUSTOM[f"{CUSTOM_LIB}:OLED_2.42_SSD1309"] = OLED242

# CC1101 sub-GHz transceiver as a ready-made 8-pin module (the common green 433 MHz board / Ebyte E07-M1101D / Waveshare CC1101 RF Board; 1.27 mm pitch socket)
CC1101 = make_symbol(
    "CC1101_Module", "U", "CC1101 module 433 MHz", "Connector_PinSocket_1.27mm:PinSocket_1x08_P1.27mm_Vertical",
    "TI CC1101 sub-GHz transceiver module (300-928 MHz chip, most modules tuned for 433 MHz), SPI, 1.8-3.6 V. Pin order from the Ebyte E07-M1101D manual.",
    (-7.62, 12.7, 7.62, -10.16),
    [("1", "GND", "power_in", -10.16, 10.16, 0, False), ("2", "VCC", "power_in", -10.16, 7.62, 0, False),
     ("3", "GDO0", "output", -10.16, 5.08, 0, False), ("4", "CSN", "input", -10.16, 2.54, 0, False),
     ("5", "SCK", "input", -10.16, 0, 0, False), ("6", "MOSI", "input", -10.16, -2.54, 0, False),
     ("7", "MISO/GDO1", "tri_state", -10.16, -5.08, 0, False), ("8", "GDO2", "output", -10.16, -7.62, 0, False)])
CUSTOM[f"{CUSTOM_LIB}:CC1101_Module"] = CC1101

# ATGM336H-5N31 GPS module: third-party symbol (see third_party/SOURCES.md), footprint = KiCad stock RF_GPS:ublox_MAX
_tp = open(os.path.join(os.path.dirname(__file__), "third_party", "ATGM336H-5N31.kicad_sym"), encoding="utf8").read()
_i = _tp.index('(symbol "ATGM336H-5N31"')
ATGM = _tp[_i:balanced_end(_tp, _i)]
ATGM = re.sub(r'\(property "Footprint" "[^"]*"', '(property "Footprint" "RF_GPS:ublox_MAX"', ATGM)
ATGM = re.sub(r'\(property "Datasheet" "[^"]*"', '(property "Datasheet" "https://www.lcsc.com/product-detail/C90770.html"', ATGM)
ATGM = re.sub(r'\(property "Description" "[^"]*"',
              '(property "Description" "Zhongkewei ATGM336H-5N31 GPS+BDS module, u-blox MAX-M8 pin-compatible (symbol: github.com/frohro/Balloon-Beacon)"', ATGM)
CUSTOM[f"{CUSTOM_LIB}:ATGM336H-5N31"] = ATGM

lib = open(LIBFILE, encoding="utf8").read()
for _name, _blk in (("MAX17048", MAX17048), ("OLED_2.42_SSD1309", OLED242), ("CC1101_Module", CC1101)):    # ATGM336H symbol no longer used (GPS = plug-in GP-02 board)
    if '(symbol "%s"' % _name not in lib:
        lib = lib.rstrip().rstrip(")").rstrip() + "\n" + "\n".join("\t" + l for l in _blk.split("\n")) + "\n)\n"
open(LIBFILE, "w", encoding="utf8", newline="\n").write(lib)

# ------------------------------------------------------------------ setup
tree = parse(text)
existing = [props(n)["Reference"] for n in tree if isinstance(n, list) and n and n[0] == "symbol" and child(n, "lib_id")]
s = Schematic("A1")
for r in existing:
    if r != "Brd1":
        s.reserve(r)

FP_R = "Resistor_SMD:R_1206_3216Metric"   # 1206 (big, easy to hand-solder); 4 Oct 2026: SMD passives so the handheld + node fit the 100 x 100 mm panel (was THT axial, rev-1 style)
FP_C = "Capacitor_SMD:C_1206_3216Metric"                      # 100 nF / 22 pF ceramic
FP_CB = "Capacitor_SMD:C_1206_3216Metric"                         # 1 uF / 10 uF ceramic (X5R/X7R, 16 V)
FP_SMD_BTN = "Button_Switch_SMD:SW_SPST_B3U-1000P"
FP_DIODE = "Diode_THT:D_DO-41_SOD81_P3.81mm_Vertical_CathodeUp"                # 1N5819 Schottky (through-hole)
FP_WIRE2 = "Connector_Wire:SolderWire-0.25sqmm_1x02_P4.2mm_D0.65mm_OD1.7mm"
FP_WIRE1 = "Connector_Wire:SolderWire-2.5sqmm_1x01_D2.4mm_OD3.6mm"
FP_BTN6 = "Button_Switch_THT:SW_PUSH_6mm_H4.3mm"


def find_lib(name):
    for f in os.listdir(KSYM):
        if f.endswith(".kicad_sym") and ('(symbol "%s"' % name) in open(os.path.join(KSYM, f), encoding="utf8").read():
            return f[:-10]
    raise SystemExit("symbol not found in any library: " + name)


# ------------------------------------------------------------------ wiring helpers (net labels / power symbols on pin ends, no wires)
libsyms = {}
for _n in tree:
    if isinstance(_n, list) and _n and _n[0] == "lib_symbols":
        for _sy in _n[1:]:
            if isinstance(_sy, list) and _sy and _sy[0] == "symbol":
                libsyms[_sy[1]] = _sy
inst_nodes = {props(n)["Reference"]: n for n in tree if isinstance(n, list) and n and n[0] == "symbol" and child(n, "lib_id")}


def _walk_pins(node, out):
    for c in node:
        if isinstance(c, list) and c:
            if c[0] == "pin" and child(c, "at") and child(c, "number"):
                a = child(c, "at")
                out.append((child(c, "number")[1], float(a[1]), float(a[2]), int(float(a[3]))))
            _walk_pins(c, out)


def existing_pins(ref):
    """pin number -> (x, y, outward angle) for an instance that is already in the file (rotation / mirror aware)."""
    n = inst_nodes[ref]
    lid = child(n, "lib_id")[1]
    at = child(n, "at")
    ox, oy = float(at[1]), float(at[2])
    rot = int(float(at[3])) if len(at) > 3 else 0
    mir = child(n, "mirror")
    mir = mir[1] if mir else None
    raw = []
    _walk_pins(libsyms[lid], raw)
    res = {}
    for num, px, py, pa in raw:
        x, y, a = px, py, pa
        if mir == "x":
            y, a = -y, (-a) % 360
        elif mir == "y":
            x, a = -x, (180 - a) % 360
        r = math.radians(rot)
        xr = x * math.cos(r) - y * math.sin(r)
        yr = x * math.sin(r) + y * math.cos(r)
        res[num] = (round(ox + xr, 4), round(oy - yr, 4), (a + rot + 180) % 360)
    return res


_done = set()
_orig_attach = s.attach


def _attach(net, px, py, out_angle, stub=0.0):
    key = (round(px, 2), round(py, 2), net)
    if key in _done:
        return
    _done.add(key)
    _orig_attach(net, px, py, out_angle, stub)


s.attach = _attach
placed = {}      # ref -> (libid, x, y, set of connected pin numbers)  (new parts)
old_conn = {}    # ref -> set of connected pin numbers                  (parts that were already in the file)


def wire_old(ref, nets):
    pts = existing_pins(ref)
    for num, net in nets.items():
        px, py, oa = pts[num]
        s.attach(net, px, py, oa)
    old_conn.setdefault(ref, set()).update(nets)


groups = {}
cur = [None]


def group(title, x, y):
    cur[0] = title
    groups[title] = []
    s.text(title, x, y, 3.2, True)


# ------------------------------------------------------------------ silkscreen names: short Value text (printed on the board) + pin names beside headers
LBL = {}    # ref -> {"value": silkscreen name, "pins": {pad number: pin name}}   (written to labels.json for silkscreen.py)
P4 = ["SDA", "SCL", "3V3", "GND"]
LABEL_MAP = {      # old long Value text -> (silkscreen Value, pin names in pad order). The long text is kept in a hidden "Note" field.
    "2.42in OLED SSD1309 128x64": ("OLED 2.42", ["VCC", "GND", "DIN", "CLK", "CS", "DC", "RES"]),
    "LiPo JST-PH": ("LIPO", ["+", "-"]),
    "1S LiPo charger module (IN+ IN- OUT+ OUT- B+ B- - check yours)": ("CHARGER", ["IN+", "IN-", "OUT+", "OUT-", "B+", "B-"]),
    "TPS63020 3.3V module (VIN+ GND VOUT+ GND - check your board)": ("3V3 MOD", ["VIN", "GND", "3V3", "GND"]),
    "D_BAT 1N5819 (battery -> VIN)": ("D_BAT", None),
    "D_USB 1N5819 (USB 5V -> VIN)": ("D_USB", None),
    "POWER SWITCH (cuts the battery)": ("BATT SW", None),
    "CC1101 module (433 MHz, own antenna)": ("CC1101", ["GND", "VCC", "GDO0", "CSN", "SCK", "MOSI", "MISO", "GDO2"]),
    "GY-91 (VIN 3V3 GND SCL SDA SDO NCS CSB - check your board)": ("GY-91", ["VIN", "3V3", "GND", "SCL", "SDA", "SDO", "NCS", "CSB"]),
    "LDR GL5528": ("LDR", None),
    "PCF8574T (7 buttons, INT -> ESP32 wake pin)": ("PCF8574", None),
    "RFM95W-868S2": ("LORA 868", None),
    "u.FL ANT (868/915 MHz)": ("LORA ANT", None),
    "u.FL ANT (868 MHz)": ("LORA ANT", None),
    "DRV2605L module (VIN GND SCL SDA IN EN - check your board)": ("HAPTIC", ["VIN", "GND", "SCL", "SDA", "IN", "EN"]),
    "ERM motor (to module pads)": ("MOTOR", None),
    "EC11 encoder (placeholder: swap for a low-profile one)": ("ENCODER", None),
    "SW_Exit": ("EXIT", None),
    "AO3401A LED gate (GPIO low = on)": ("LED GATE", None),
    "AO3401A GPS gate (GPIO low = on)": ("GPS GATE", None),
    "S8050 / 2N3904 (TO-92)": ("BUZ DRV", None),
    "1N5819 flyback": ("BUZ D", None),
    "I2C PORT A (SDA SCL 3V3 GND)": ("I2C A", P4),
    "I2C PORT B (SDA SCL 3V3 GND)": ("I2C B", P4),
    "UART PORT = GPS GP-02 plugs here (mod-TX mod-RX 3V3 GND)": ("GPS UART", ["M-TX", "M-RX", "3V3", "GND"]),
    "BEC IN 5V (servo plug: GND +5V signal)": ("BEC IN", ["GND", "5V", "SIG"]),
    "ATmega32U4-AU (from the Pro Micro)": ("ATmega32U4", None),
    "16 MHz (from the Pro Micro)": ("16MHz", None),
    "USB-C 12P (from the Pro Micro; same HRO footprint as J2)": ("USB-C", None),
    "1mR shunt (Kelvin)": ("SHUNT 1mR", None),
    "AMS1117-3.3 (from the old Mini PC)": ("AMS1117-3.3", None),
    "ICSP (MISO 5V SCK MOSI RST GND)": ("ICSP", ["MISO", "5V", "SCK", "MOSI", "RST", "GND"]),
    "Schottky USB 5V -> rail": ("D_USB", None),
    "Schottky BEC 5V -> rail": ("D_BEC", None),
    "GPS PLUG (mod-TX mod-RX 3V3 GND)": ("GPS", ["M-TX", "M-RX", "3V3", "GND"]),
    "BARO PLUG (SDA SCL 3V3 GND)": ("BARO", P4),
    "AIRSPEED PLUG (SDA SCL 3V3 GND)": ("AIRSPEED", P4),
    "SPARE I2C PLUG (SDA SCL 3V3 GND)": ("I2C SPARE", P4),
    "PACK+ (3S battery +)": ("PACK+", None),
    "ESC+ (to the ESC)": ("ESC+", None),
    "PACK- = GND (battery -)": ("PACK-", None),
}


def put(libid, x, y, value=None, fp=None, nets=None, label=None, pins=None):
    if ":" not in libid:
        libid = find_lib(libid) + ":" + libid
    if label is None and value in LABEL_MAP:
        label, pins = LABEL_MAP[value]
    note = {"Note": value} if label and value and label != value else None
    ref = s.place(libid, x, y, nets or {}, value=label or value, fp=fp, extra=note)
    fpn = fp if fp else s._lib(libid).fp
    if not fpn:
        raise SystemExit("no footprint for " + libid)
    lib_, name = fpn.split(":", 1)
    assert os.path.exists(os.path.join(KFP, lib_ + ".pretty", name + ".kicad_mod")), "missing footprint " + fpn
    placed[ref] = (libid, snap(x), snap(y), set((nets or {}).keys()))
    groups[cur[0]].append(ref)
    if label or pins:
        LBL[ref] = {"value": label or value, "pins": {str(i + 1): n for i, n in enumerate(pins)} if pins else {}}
    return ref


def R(v, x, y, nets=None, fp=FP_R):
    return put("Device:R", x, y, v, fp, nets)


def C(v, x, y, nets=None):
    return put("Device:C", x, y, v, FP_CB if v in ("1uF", "4.7uF", "10uF", "22uF") else FP_C, nets)


G, V3 = "GND", "+3V3"                      # handheld rails (power symbols)
NG, N5, N3 = "N_GND", "N_5V", "N_3V3"      # flight-node rails (a separate board: every node net is prefixed N_)
PIN4 = "Connector_PinHeader_2.54mm:PinHeader_1x04_P2.54mm_Vertical"
PIN6 = "Connector_PinHeader_2.54mm:PinHeader_1x06_P2.54mm_Vertical"
PIN8 = "Connector_PinHeader_2.54mm:PinHeader_1x08_P2.54mm_Vertical"

s.text("Display: 2.42in SSD1309 128x64 OLED module (non-square, 2:1 landscape). AMS1117 + D1 were deleted - the TPS63020 module makes the 3.3 V. Modules on headers: charger, 3.3 V, GY-91, DRV2605L, GPS (UART port).", 20, 135, 2.0)

# ================================================================== ROW 1
group("Display: 2.42in OLED", 20, 150)
put(f"{CUSTOM_LIB}:OLED_2.42_SSD1309", 50, 190, "2.42in OLED SSD1309 128x64",
    nets={"1": V3, "2": G, "3": "MOSI", "4": "SCK", "5": "OLED_CS", "6": "OLED_DC", "7": "OLED_RES"})
C("10uF", 80, 190, {"1": V3, "2": G})
C("0.1uF", 95, 190, {"1": V3, "2": G})

group("LiPo charger MODULE (your 1S TP4056 board)", 120, 150)
put("Connector_Generic_MountingPin:Conn_01x02_MountingPin", 135, 195, "LiPo JST-PH",
    "Connector_JST:JST_PH_S2B-PH-SM4-TB_1x02-1MP_P2.00mm_Horizontal", nets={"1": "VBAT", "2": "BATN", "MP": "NC"})
put("Connector_Generic:Conn_01x06", 200, 200, "1S LiPo charger module (IN+ IN- OUT+ OUT- B+ B- - check yours)", PIN6,
    nets={"1": "VBUSF", "2": G, "3": "VBAT", "4": G, "5": "VBAT", "6": "BATN"})
C("10uF", 150, 250, {"1": "VBAT", "2": G})

group("3.3 V: TPS63020 module + OR-ing diodes", 300, 150)
put("Connector_Generic:Conn_01x04", 345, 195, "TPS63020 3.3V module (VIN+ GND VOUT+ GND - check your board)", PIN4,
    nets={"1": "VIN", "2": G, "3": V3, "4": G})
put("Device:D_Schottky", 325, 232, "D_BAT 1N5819 (battery -> VIN)", FP_DIODE, nets={"2": "VBSW", "1": "VIN"})
put("Device:D_Schottky", 375, 232, "D_USB 1N5819 (USB 5V -> VIN)", FP_DIODE, nets={"2": "VBUSF", "1": "VIN"})
C("10uF", 305, 255, {"1": "VIN", "2": G})
C("10uF", 318, 255, {"1": V3, "2": G})
s.text("POWER: USB 5 V -> PTC 1 A -> (a) charger board IN+ (set its Rprog to ~3k = 400 mA, so charge + load stay under USB's 500 mA) and (b) D_USB -> VIN node.", 120, 267, 1.5)
s.text("Battery (charger board OUT+/OUT-, protected) -> slide switch -> D_BAT -> VIN node. The two diodes keep USB 5 V out of the battery and the battery out of USB; with USB present the load runs from USB, so charging is never disturbed.", 120, 270.5, 1.5)
s.text("VIN node -> TPS63020 module (set to 3.3 V) -> 3V3 rail. Nothing but the 3V3 rail ever touches the module's output (no back-feed). MAX17048 CELL/VDD go straight to the battery (OUT+, before the switch).", 120, 274, 1.5)

group("Fuel gauge (shown on the display) + power switch", 430, 150)
put(f"{CUSTOM_LIB}:MAX17048", 470, 200, "MAX17048",
    nets={"1": G, "2": "VBAT", "3": "VBAT", "4": G, "5": "NC", "6": G, "7": "SCL", "8": "SDA", "9": G})
C("0.1uF", 455, 245, {"1": "VBAT", "2": G})
put("Switch:SW_SPDT", 530, 200, "POWER SWITCH (cuts the battery)", "Button_Switch_SMD:SW_SPDT_PCM12",
    nets={"2": "VBAT", "1": "VBSW", "3": "NC"})

group("USB protection", 570, 150)
put("Power_Protection:USBLC6-2SC6", 595, 200, "USBLC6-2SC6",
    nets={"1": "USB_DPC", "6": "USB_DPC", "3": "USB_DMC", "4": "USB_DMC", "2": G, "5": "VBUSF"})
put("Device:Polyfuse", 635, 200, "PTC 1A", "Fuse:Fuse_1206_3216Metric", nets={"1": "VBUS", "2": "VBUSF"})
C("10uF", 665, 200, {"1": "VBUSF", "2": G})

group("CC1101 433 MHz module", 710, 150)
put(f"{CUSTOM_LIB}:CC1101_Module", 740, 190, "CC1101 module (433 MHz, own antenna)",
    nets={"1": G, "2": V3, "3": "CC_GDO0", "4": "CC_CSN", "5": "SCK", "6": "MOSI", "7": "MISO", "8": "CC_GDO2"})
C("10uF", 775, 190, {"1": V3, "2": G})
C("0.1uF", 790, 190, {"1": V3, "2": G})

# ================================================================== ROW 2
group("GY-91 module: motion + compass + pressure", 20, 290)
put("Connector_Generic:Conn_01x08", 60, 330, "GY-91 (VIN 3V3 GND SCL SDA SDO NCS CSB - check your board)", PIN8,
    nets={"1": "NC", "2": V3, "3": G, "4": "SCL", "5": "SDA", "6": G, "7": V3, "8": V3})
C("0.1uF", 40, 380, {"1": V3, "2": G})
R("4.7k", 70, 380, {"1": V3, "2": "SDA"})
R("4.7k", 85, 380, {"1": V3, "2": "SCL"})

group("Ambient light: LDR + divider (ADC)", 170, 290)
put("Device:R_Photo", 200, 330, "LDR GL5528", "OptoDevice:R_LDR_5.1x4.3mm_P3.4mm_Vertical", nets={"1": V3, "2": "LDR"})
R("10k", 225, 330, {"1": "LDR", "2": G})
C("0.1uF", 245, 330, {"1": "LDR", "2": G})

group("I2C GPIO expander (PCF8574): d-pad, exit, encoder push", 500, 290)
put("Interface_Expansion:PCF8574T", 545, 335, "PCF8574T (7 buttons, INT -> ESP32 wake pin)",
    nets={"16": V3, "8": G, "14": "SCL", "15": "SDA", "1": G, "2": G, "3": G, "13": "PCF_INT",
          "4": "BTN_UP", "5": "BTN_DOWN", "6": "BTN_LEFT", "7": "BTN_RIGHT", "9": "BTN_MID", "10": "BTN_EXIT", "11": "ENC_SW", "12": "NC"})
C("0.1uF", 525, 385, {"1": V3, "2": G})
R("10k", 560, 385, {"1": V3, "2": "PCF_INT"})

group("LoRa sub-GHz radio + antenna port (u.FL)", 360, 290)
put("RF_Module:RFM95W-868S2", 395, 335, "RFM95W-868S2", "RF_Module:HOPERF_RFM9XW_SMD",
    nets={"1": G, "8": G, "10": G, "13": V3, "2": "MISO", "3": "MOSI", "4": "SCK", "5": "LORA_NSS", "6": "LORA_RST", "14": "LORA_DIO0", "9": "LORA_ANT"})
put("Connector:Conn_Coaxial", 450, 335, "u.FL ANT (868/915 MHz)", "Connector_Coaxial:U.FL_Hirose_U.FL-R-SMT-1_Vertical",
    nets={"1": "LORA_ANT", "2": G})
C("10uF", 380, 385, {"1": V3, "2": G})
C("0.1uF", 395, 385, {"1": V3, "2": G})

s.text("GPS: an ATGM336H GP-02 board (ceramic antenna on the board) plugs into the UART PORT on the right -", 500, 405, 1.5)
s.text("no GPS chip, antenna connector or bias parts on this PCB. Its supply is the switched GPS3V3 rail.", 500, 409, 1.5)

# ================================================================== ROW 3
group("Haptics: DRV2605L MODULE + coin motor", 20, 430)
put("Connector_Generic:Conn_01x06", 60, 470, "DRV2605L module (VIN GND SCL SDA IN EN - check your board)", PIN6,
    nets={"1": V3, "2": G, "3": "SCL", "4": "SDA", "5": G, "6": V3})
put("Motor:Motor_DC", 110, 470, "ERM motor (to module pads)", FP_WIRE2, nets={"1": "NC", "2": "NC"})

group("RGB status LEDs (WS2812B-2020 chain)", 140, 430)
_prev = "WS_DATA"
for i in range(4):
    _next = "WS%d" % (i + 1) if i < 3 else "NC"
    put("WS2812B-2020", 155 + 22 * i, 470, "WS2812B-2020", nets={"3": _prev, "1": _next, "4": "LED3V3", "2": G}, label="LED%d" % (i + 1))
    _prev = _next
C("0.1uF", 155, 520, {"1": "LED3V3", "2": G})
C("0.1uF", 177, 520, {"1": "LED3V3", "2": G})
C("10uF", 199, 520, {"1": "LED3V3", "2": G})

group("Inputs: rotary encoder + exit button", 290, 430)
put("Device:RotaryEncoder_Switch", 325, 470, "EC11 encoder (placeholder: swap for a low-profile one)",
    "Rotary_Encoder:RotaryEncoder_Alps_EC11E-Switch_Vertical_H20mm", nets={"A": "ENC_A", "B": "ENC_B", "C": G, "S1": "ENC_SW", "S2": G})
put("Switch:SW_Push", 375, 470, "SW_Exit", FP_BTN6, nets={"1": "BTN_EXIT", "2": G})
R("10k", 325, 520, {"1": V3, "2": "ENC_A"})
R("10k", 340, 520, {"1": V3, "2": "ENC_B"})

group("Switched rails (deep sleep): LEDs + GPS port", 20, 546)
put("Transistor_FET:AO3401A", 45, 566, "AO3401A LED gate (GPIO low = on)", nets={"1": "LED_EN", "2": V3, "3": "LED3V3"})
R("100k", 70, 566, {"1": V3, "2": "LED_EN"})
put("Transistor_FET:AO3401A", 105, 566, "AO3401A GPS gate (GPIO low = on)", nets={"1": "GPS_EN", "2": V3, "3": "GPS3V3"})
R("100k", 130, 566, {"1": V3, "2": "GPS_EN"})

group("Buzzer driver (NPN + flyback diode)", 190, 546)
put("Transistor_BJT:S8050", 215, 566, "S8050 / 2N3904 (TO-92)", nets={"1": G, "2": "BUZ_B", "3": "BUZ_C"})
R("1k", 240, 566, {"1": "BUZ", "2": "BUZ_B"})
put("Device:D_Schottky", 265, 566, "1N5819 flyback", FP_DIODE, nets={"1": V3, "2": "BUZ_C"})

# ================================================================== HANDHELD: add-on ports (row 2, right side)
group("Add-on ports: 1 IO1, 2 IO2, 3 VCC, 4 GND", 660, 290)
s.text("Same pin order as the first board's J1/J3 headers beside the display. VCC = 3.3 V here.", 660, 301, 1.5)
put("Connector_Generic:Conn_01x04", 685, 335, "I2C PORT A (SDA SCL 3V3 GND)", PIN4, nets={"1": "SDA", "2": "SCL", "3": V3, "4": G})
put("Connector_Generic:Conn_01x04", 735, 335, "I2C PORT B (SDA SCL 3V3 GND)", PIN4, nets={"1": "SDA", "2": "SCL", "3": V3, "4": G})
put("Connector_Generic:Conn_01x04", 785, 335, "UART PORT = GPS GP-02 plugs here (mod-TX mod-RX 3V3 GND)", PIN4,
    nets={"1": "UART_RX", "2": "UART_TX", "3": "GPS3V3", "4": G})

# ================================================================== BREAK-OFF BOARD (separate module, snapped off the panel later)
# AR620 has NO telemetry/X-Bus port, so this node reports over LoRa to the handheld (which already has LoRa + the OLED).
group("BREAK-OFF BOARD: EasyGlider flight node (3S battery, GPS, baro, airspeed) -> LoRa -> Mini PC", 420, 438)
s.box(415, 428, 718, 580)
s.text("Separate module - NOT wired to the handheld (every net here is prefixed N_). Measures the 3S pack (divider + high-side Kelvin shunt) and sends battery %, current, mAh used,", 420, 447, 1.5)
s.text("GPS position, altitude and airspeed over LoRa (868 MHz); the Mini PC logs the flight for replay (the ATmega32U4 has no flash for a node log).", 420, 450.5, 1.5)
s.text("Plug-in sensors on 4-pin ports (no soldering): GPS (UART, hardware Serial1), BARO (I2C, e.g. MS5611/BMP390), AIRSPEED (I2C, e.g. MS4525DO/SDP3x), spare I2C.", 420, 454, 1.5)
s.text("BRAIN = the Pro Micro's own parts: ATmega32U4-AU + 16 MHz crystal + USB-C port (native USB, Caterina bootloader, no USB-serial chip), LEDs, ICSP (its RST pin is the reset: touch it to GND to enter the bootloader, no button).", 420, 457.5, 1.5)
s.text("5 V logic from the receiver BEC via a Schottky (BEC must be 5.0-5.5 V; USB 5 V enters via a second Schottky, so neither back-feeds). AMS1117-3.3 only feeds the RFM95W + modules; 1k/2k dividers level-shift MOSI, SCK, NSS, RESET.", 420, 461, 1.5)
put("Connector_Generic:Conn_01x03", 428, 474, "BEC IN 5V (servo plug: GND +5V signal)", "Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical",
    nets={"1": NG, "2": "N_BEC", "3": "NC"})
put("MCU_Microchip_ATmega:ATmega32U4-A", 455, 508, "ATmega32U4-AU (from the Pro Micro)",
    nets={"2": N5, "14": N5, "34": N5, "24": N5, "44": N5, "15": NG, "23": NG, "35": NG, "43": NG, "5": NG,
          "6": "N_UCAP", "7": "N_USBV", "3": "N_DM", "4": "N_DP", "13": "N_RST", "16": "N_XTAL2", "17": "N_XTAL1",
          "33": "N_HWB", "42": "N_AREF", "9": "N_MCU_SCK", "10": "N_MCU_MOSI", "11": "N_MISO", "30": "N_MCU_NSS",
          "29": "N_MCU_RST", "1": "N_DIO0", "19": "N_SDA", "18": "N_SCL", "20": "N_RX", "21": "N_TX",
          "36": "N_BATSENSE", "37": "N_CUR", "32": "N_LEDPIN"})
put("Device:Crystal", 510, 482, "16 MHz (from the Pro Micro)", "Crystal:Crystal_SMD_HC49-SD", nets={"1": "N_XTAL1", "2": "N_XTAL2"})
put("Connector:USB_C_Receptacle_USB2.0_14P", 600, 500, "USB-C 12P (from the Pro Micro; same HRO footprint as J2)", "Connector_USB:USB_C_Receptacle_HRO_TYPE-C-31-M-12",
    nets={"A1": NG, "A12": NG, "B1": NG, "B12": NG, "SH": NG, "A4": "N_USBV", "A9": "N_USBV", "B4": "N_USBV", "B9": "N_USBV",
          "A5": "N_CC1", "B5": "N_CC2", "A6": "N_DPC", "B6": "N_DPC", "A7": "N_DMC", "B7": "N_DMC"})
put("RF_Module:RFM95W-868S2", 692, 510, "RFM95W-868S2", "RF_Module:HOPERF_RFM9XW_SMD",
    nets={"1": NG, "8": NG, "10": NG, "13": N3, "2": "N_MISO", "3": "N_MOSI_L", "4": "N_SCK_L", "5": "N_NSS_L", "6": "N_RST_L",
          "14": "N_DIO0", "9": "N_ANT"})
put("Connector:Conn_Coaxial", 703, 480, "u.FL ANT (868 MHz)", "Connector_Coaxial:U.FL_Hirose_U.FL-R-SMT-1_Vertical", nets={"1": "N_ANT", "2": NG})
put("Amplifier_Current:INA180A2", 510, 530, "INA180A2", nets={"1": "N_CUR", "2": NG, "3": "N_PACKP", "4": "N_ESCP", "5": N5})
put("Device:R_Shunt", 545, 533, "1mR shunt (Kelvin)", "Resistor_SMD:R_Shunt_Vishay_WSK2512_6332Metric_T1.19mm",
    nets={"1": "N_PACKP", "2": "N_PACKP", "3": "N_ESCP", "4": "N_ESCP"})
put("Regulator_Linear:AMS1117-3.3", 585, 530, "AMS1117-3.3 (from the old Mini PC)", nets={"3": N5, "1": NG, "2": N3})
put("Connector_Generic:Conn_02x03_Odd_Even", 625, 533, "ICSP (MISO 5V SCK MOSI RST GND)", "Connector_PinHeader_2.54mm:PinHeader_2x03_P2.54mm_Vertical",
    nets={"1": "N_MISO", "2": N5, "3": "N_MCU_SCK", "4": "N_MCU_MOSI", "5": "N_RST", "6": NG})
put("Device:D_Schottky", 688, 533, "Schottky USB 5V -> rail", FP_DIODE, nets={"2": "N_USBV", "1": N5})
put("Device:D_Schottky", 706, 533, "Schottky BEC 5V -> rail", FP_DIODE, nets={"2": "N_BEC", "1": N5})
put("Connector_Generic:Conn_01x04", 495, 548, "GPS PLUG (mod-TX mod-RX 3V3 GND)", PIN4, nets={"1": "N_RX", "2": "N_TX", "3": N3, "4": NG})
put("Connector_Generic:Conn_01x04", 545, 548, "BARO PLUG (SDA SCL 3V3 GND)", PIN4, nets={"1": "N_SDA", "2": "N_SCL", "3": N3, "4": NG})
put("Connector_Generic:Conn_01x04", 595, 548, "AIRSPEED PLUG (SDA SCL 3V3 GND)", PIN4, nets={"1": "N_SDA", "2": "N_SCL", "3": N3, "4": NG})
put("Connector_Generic:Conn_01x04", 645, 548, "SPARE I2C PLUG (SDA SCL 3V3 GND)", PIN4, nets={"1": "N_SDA", "2": "N_SCL", "3": N3, "4": NG})
put("Device:LED", 690, 548, "PWR LED", "LED_SMD:LED_0603_1608Metric", nets={"2": "N_PWRA", "1": NG})
put("Device:LED", 710, 548, "L LED", "LED_SMD:LED_0603_1608Metric", nets={"2": "N_LA", "1": NG})
put("Connector_Generic:Conn_01x01", 548, 470, "PACK+ (3S battery +)", FP_WIRE1, nets={"1": "N_PACKP"})
put("Connector_Generic:Conn_01x01", 548, 478, "ESC+ (to the ESC)", FP_WIRE1, nets={"1": "N_ESCP"})
put("Connector_Generic:Conn_01x01", 548, 486, "PACK- = GND (battery -)", FP_WIRE1, nets={"1": NG})

_caps = [("22pF", "N_XTAL1", NG), ("22pF", "N_XTAL2", NG),
         ("0.1uF", N5, NG), ("0.1uF", N5, NG), ("0.1uF", N5, NG), ("0.1uF", N5, NG), ("0.1uF", "N_AREF", NG),
         ("0.1uF", N3, NG), ("0.1uF", N5, NG), ("0.1uF", "N_BATSENSE", NG),
         ("1uF", "N_UCAP", NG), ("10uF", N5, NG), ("10uF", N3, NG), ("10uF", "N_USBV", NG)]
for i, (v, a, b) in enumerate(_caps):
    C(v, 430 + 11 * i, 558, {"1": a, "2": b})
_res = [("10k", N5, "N_RST"), ("10k", "N_HWB", NG), ("5.1k", "N_CC1", NG), ("5.1k", "N_CC2", NG),
        ("22", "N_DPC", "N_DP"), ("22", "N_DMC", "N_DM"), ("1k", N5, "N_PWRA"), ("1k", "N_LEDPIN", "N_LA"),
        ("1k", "N_MCU_MOSI", "N_MOSI_L"), ("2k", "N_MOSI_L", NG), ("1k", "N_MCU_SCK", "N_SCK_L"), ("2k", "N_SCK_L", NG),
        ("1k", "N_MCU_NSS", "N_NSS_L"), ("2k", "N_NSS_L", NG), ("1k", "N_MCU_RST", "N_RST_L"), ("2k", "N_RST_L", NG),
        ("100k", "N_PACKP", "N_BATSENSE"), ("22k", "N_BATSENSE", NG), ("4.7k", N3, "N_SDA"), ("4.7k", N3, "N_SCL")]
for i, (v, a, b) in enumerate(_res):
    R(v, 430 + 11 * i, 572, {"1": a, "2": b})

# ================================================================== the parts that were already on the board (rev 1): wire them for rev 2
wire_old("U1", {"1": G, "40": G, "41": G, "2": V3, "3": "EN", "27": "IO0", "12": "SDA", "17": "SCL", "20": "SCK", "19": "MOSI", "21": "MISO",
                "18": "OLED_CS", "22": "OLED_DC", "8": "OLED_RES", "9": "LORA_NSS", "10": "LORA_RST", "11": "LORA_DIO0",
                "23": "CC_CSN", "31": "CC_GDO0", "32": "CC_GDO2", "4": "PCF_INT", "5": "PWR_BTN", "6": "LDR", "7": "LED_EN",
                "24": "ENC_A", "25": "ENC_B", "35": "WS_DATA", "34": "BUZ", "36": "UART_RX", "37": "UART_TX",
                "39": "IO1", "38": "IO2", "13": "USB_DM", "14": "USB_DP", "33": "GPS_EN"})
wire_old("J2", {"A1": G, "A12": G, "B1": G, "B12": G, "SH": G, "A4": "VBUS", "A9": "VBUS", "B4": "VBUS", "B9": "VBUS",
                "A5": "CC1", "B5": "CC2", "A6": "USB_DPC", "B6": "USB_DPC", "A7": "USB_DMC", "B7": "USB_DMC"})
wire_old("R1", {"1": "CC2", "2": G})
wire_old("R2", {"1": "CC1", "2": G})
wire_old("R3", {"1": "USB_DM", "2": "USB_DMC"})
wire_old("R6", {"1": "USB_DP", "2": "USB_DPC"})
wire_old("R4", {"1": "EN", "2": V3})
wire_old("R5", {"1": "IO0", "2": V3})
wire_old("C1", {"1": V3, "2": G})
wire_old("C2", {"1": G, "2": V3})
wire_old("C3", {"1": G, "2": V3})
wire_old("SW1", {"1": "IO0", "2": G})
wire_old("SW2", {"1": "EN", "2": G})
for _sw, _net in (("SW3", "BTN_UP"), ("SW4", "BTN_DOWN"), ("SW5", "BTN_LEFT"), ("SW6", "BTN_RIGHT"), ("SW7", "BTN_MID"), ("SW8", "PWR_BTN")):
    wire_old(_sw, {"1": _net, "2": G})
wire_old("BZ1", {"1": V3, "2": "BUZ_C"})
wire_old("J1", {"1": "IO1", "2": "IO2", "3": V3, "4": G})
wire_old("J3", {"1": "IO1", "2": "IO2", "3": V3, "4": G})
wire_old("J4", {"1": G, "2": V3, "3": "SDA", "4": "SCL"})
OLD_LABELS = {"SW1": ("BOOT", None), "SW2": ("RESET", None), "SW3": ("UP", None), "SW4": ("DOWN", None), "SW5": ("LEFT", None),
              "SW6": ("RIGHT", None), "SW7": ("MIDDLE", None), "SW8": ("PWR", None), "BZ1": ("BUZZER", None), "J2": ("USB-C", None),
              "U1": ("ESP32-S3", None), "J1": ("EXP 1", ["IO1", "IO2", "3V3", "GND"]), "J3": ("EXP 2", ["IO1", "IO2", "3V3", "GND"]),
              "J4": ("RTC", ["GND", "3V3", "SDA", "SCL"])}
for _r, (_v, _p) in OLD_LABELS.items():
    LBL[_r] = {"value": _v, "pins": {str(i + 1): n for i, n in enumerate(_p)} if _p else {}}

# ---- power flags (ERC only) in a free corner
s.text("PWR_FLAG: ERC only - tells the checker these rails are driven (no real part).", 235, 112, 1.5)
for _i, _net in enumerate(["GND", "+3V3", "VBAT", "VIN", "VBUS", "VBUSF", "LED3V3"]):
    s.pwrflag(_net, 240 + 10 * _i, 100)
for _i, _net in enumerate([NG, N5]):    # N_3V3 is already driven by the AMS1117 output
    s.pwrflag(_net, 735 + 10 * _i, 448)

# ---- every pin that is still open becomes an explicit no-connect (so ERC stays quiet and nothing is forgotten)
_nc_report = []
for _ref, (_lid, _x, _y, _conn) in placed.items():
    _spins = sym(_lid).pins
    _busy = {(round(_x + _spins[n]["x"], 2), round(_y - _spins[n]["y"], 2)) for n in _conn if n in _spins}
    for _num, _p in _spins.items():
        _pt = (round(_x + _p["x"], 2), round(_y - _p["y"], 2))
        if _num not in _conn and not _p["hide"] and _pt not in _busy:
            s.noconnect(_pt[0], _pt[1])
            _busy.add(_pt)
            _nc_report.append("%s.%s(%s)" % (_ref, _num, _p["name"]))
for _ref, _conn in old_conn.items():
    _pts = existing_pins(_ref)
    _busy = {(round(_pts[n][0], 2), round(_pts[n][1], 2)) for n in _conn}
    for _num, (_px, _py, _oa) in _pts.items():
        if _num not in _conn and (round(_px, 2), round(_py, 2)) not in _busy:
            s.noconnect(_px, _py)
            _busy.add((round(_px, 2), round(_py, 2)))
            _nc_report.append("%s.%s" % (_ref, _num))
print("auto no-connect on", len(_nc_report), "pins:", " ".join(_nc_report))

# shared SPI MISO line: the RFM95W releases it when not selected, so it is tri-state, not a plain output
_rfm = s.libs["RF_Module:RFM95W-868S2"]
_rfm.block = re.sub(r'\(pin output line(\s*\(at [^)]*\)\s*\(length [^)]*\)\s*\(name "MISO")', r'(pin tri_state line\1', _rfm.block)
assert "tri_state" in _rfm.block

# ---- splice into the existing file
new_items = "".join(s.items)
lib_blocks = ""
for lid, sy in sorted(s.libs.items()):
    if ('(symbol "%s"' % lid) not in text:
        lib_blocks += sy.lib_block() + "\n"

REMOVE_LIBS = ("MiniPC_v2:SSD1306", "Regulator_Linear:AMS1117", "Device:D")   # Brd1 (old OLED header), U2 (AMS1117), D1
for lid in REMOVE_LIBS:
    pat = r'\n\t\(symbol\n\t\t\(lib_id "%s"\)' % re.escape(lid)
    m = re.search(pat, text)
    assert m, "instance of %s not found" % lid
    st = text.index("(", m.start())
    en = balanced_end(text, st)
    ls = text.rfind("\n", 0, st) + 1
    text = text[:ls] + text[text.find("\n", en) + 1:]
    assert not re.search(pat, text), "more than one instance of %s" % lid
    m = re.search(r'\n\t\t\(symbol "%s"' % re.escape(lid), text)      # and its now-unused embedded library symbol
    if m:
        st = text.index("(", m.start())
        en = balanced_end(text, st)
        ls = text.rfind("\n", 0, st) + 1
        text = text[:ls] + text[text.find("\n", en) + 1:]

def set_old_value(txt, ref, value):
    pat = re.compile(r'(\(property "Reference" "%s"\s*\(at [^)]*\)(?:(?!\(symbol\n).)*?\(property "Value" ")([^"]*)(")' % re.escape(ref), re.S)
    new, n = pat.subn(lambda m: m.group(1) + value + m.group(3), txt, count=1)
    assert n == 1, "value of " + ref
    return new


for _r, (_v, _p) in OLD_LABELS.items():
    text = set_old_value(text, _r, _v)

ls_start = text.index("(lib_symbols")
ls_end = balanced_end(text, ls_start)
text = text[:ls_end - 1].rstrip("\n\t") + "\n" + lib_blocks.rstrip("\n") + "\n\t" + text[ls_end - 1:]
si = text.index("\t(sheet_instances")
text = text[:si] + new_items + text[si:]
text = text.replace('(paper "A4")', '(paper "A1")')
# original Boot / Reset buttons (SW1, SW2) keep their SMD B3U footprint: the user owns 2 of those
open(SCH, "w", encoding="utf8", newline="\n").write(text)

json.dump(groups, open(os.path.join(os.path.dirname(__file__), "parts_groups.json"), "w", encoding="utf8"), indent=1)
json.dump(LBL, open(os.path.join(os.path.dirname(__file__), "labels.json"), "w", encoding="utf8"), indent=1)
print("added", sum(len(v) for v in groups.values()), "parts in", len(groups), "groups; removed Brd1, U2 (AMS1117), D1")
for k, v in groups.items():
    print("  %-62s %s" % (k, " ".join(v)))
