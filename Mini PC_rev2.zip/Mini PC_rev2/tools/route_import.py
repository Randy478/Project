"""Import the Freerouting session back onto the board (KiCad CLOSED, KiCad's python):
    "%LOCALAPPDATA%\\Programs\\KiCad\\10.0\\bin\\python.exe" tools\\route_import.py MiniPC_v2.kicad_pcb routing\\minipc.ses [--write]
  * drops the wiring of the temporary Kelvin nets (/N_SENSEP, /N_SENSEM, see route_prep.py) from the session: KiCad refuses
    session nets it does not know
  * imports the session (KiCad replaces every track / via with the session's)
  * redraws the locked hand-drawn copper that is missing afterwards (manual.py), refills the zones, saves"""
import os
import sys

import pcbnew

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import manual  # noqa: E402

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PCB, SES = os.path.abspath(args[0]), os.path.abspath(args[1])
WRITE = "--write" in sys.argv
TEMP_NETS = ("/N_SENSEP", "/N_SENSEM")


def drop_net_blocks(text, names):
    """remove '(net NAME ...)' blocks (balanced parentheses) from a Specctra session"""
    out, i = [], 0
    while True:
        hits = [(text.find("(net %s" % n, i), n) for n in names]
        hits = [(h, n) for h, n in hits if h >= 0 and text[h + 5 + len(n)] in " \r\n\t)"]
        if not hits:
            out.append(text[i:])
            return "".join(out)
        h, _ = min(hits)
        out.append(text[i:h])
        depth, j = 0, h
        while True:
            c = text[j]
            depth += c == "("
            depth -= c == ")"
            j += 1
            if depth == 0:
                break
        i = j


ses_txt = open(SES, encoding="utf8").read()
clean = drop_net_blocks(ses_txt, TEMP_NETS)
CLEAN = SES.replace(".ses", ".clean.ses")
open(CLEAN, "w", encoding="utf8").write(clean)
print("session: %d -> %d bytes (temporary nets dropped)" % (len(ses_txt), len(clean)))

_keep = pcbnew.LoadBoard(PCB)
board = pcbnew.LoadBoard(PCB)
if not pcbnew.ImportSpecctraSES(board, CLEAN):
    sys.exit("ImportSpecctraSES failed -- board not touched")

# hand-drawn copper: the Kelvin traces never were in the session; the other locked bits came back as plain wires
# (manual.track / via reuse an identical existing item, so this only adds what is missing, and re-locks the rest)
manual.add_sense(board)
manual.add_others(board)
print("duplicate tracks / vias removed:", manual.dedupe(board))

pcbnew.ZONE_FILLER(board).Fill(board.Zones())
n_t = len([t for t in board.GetTracks() if t.GetClass() == "PCB_TRACK"])
n_v = len([t for t in board.GetTracks() if t.GetClass() == "PCB_VIA"])
print("board: %d tracks, %d vias" % (n_t, n_v))
if WRITE:
    pcbnew.SaveBoard(PCB, board, True)
    print("written", PCB)
