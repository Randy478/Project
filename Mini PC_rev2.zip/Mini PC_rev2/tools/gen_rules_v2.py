"""Write MiniPC_v2.kicad_pro: JLCPCB 4-layer friendly design rules, one Default net class (no net classes/patterns yet).
Run AFTER gen_pcb_v2.py (saving the board from pcbnew resets the project file)."""
import json
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
pro = {
    "meta": {"filename": "MiniPC_v2.kicad_pro", "version": 3},
    "board": {
        "design_settings": {
            "rules": {
                "min_clearance": 0.1, "min_connection": 0.0, "min_copper_edge_clearance": 0.2,
                "min_hole_clearance": 0.15, "min_hole_to_hole": 0.25, "min_microvia_diameter": 0.2,
                "min_microvia_drill": 0.1, "min_silk_clearance": 0.0, "min_text_height": 0.8,
                "min_text_thickness": 0.08, "min_through_hole_diameter": 0.2, "min_track_width": 0.1,
                "min_via_annular_width": 0.1, "min_via_diameter": 0.45, "solder_mask_to_copper_clearance": 0.0},
            "rule_severities": {"silk_over_copper": "ignore"},
            "track_widths": [0.0, 0.15, 0.2, 0.3, 0.5, 0.8],
            "via_dimensions": [{"diameter": 0.0, "drill": 0.0}, {"diameter": 0.6, "drill": 0.3}, {"diameter": 0.5, "drill": 0.3}],
        }
    },
    "net_settings": {
        "classes": [{
            "name": "Default", "clearance": 0.15, "track_width": 0.2, "via_diameter": 0.6, "via_drill": 0.3,
            "diff_pair_width": 0.2, "diff_pair_gap": 0.15, "diff_pair_via_gap": 0.25, "microvia_diameter": 0.3,
            "microvia_drill": 0.1, "bus_width": 12, "wire_width": 6, "line_style": 0,
            "pcb_color": "rgba(0, 0, 0, 0.000)", "schematic_color": "rgba(0, 0, 0, 0.000)",
            "priority": 2147483647, "tuning_profile": ""}],
        "meta": {"version": 5}, "net_colors": None, "netclass_assignments": None, "netclass_patterns": [],
    },
}
path = os.path.join(ROOT, "MiniPC_v2.kicad_pro")
json.dump(pro, open(path, "w", encoding="utf8"), indent=2)
print("wrote", path)
