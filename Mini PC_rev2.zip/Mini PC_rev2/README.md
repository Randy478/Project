# Mini PC rev 2 - placed and routed: 100 x 100 mm panel, handheld + left break-off flight node, DRC clean

Built from `D:\Projects\Mini PC\Mini PC.kicad_sch` (the original Mini PC, left untouched). Earlier experiments are archived in
`D:\Projects\_Mini PC old attempts\` and are unrelated to this project.

## State right now
- **Schematic** (`MiniPC_v2.kicad_sch`, A1): **137 parts, fully wired with net labels** (C35 added 4 Oct 2026: 1 uF EN-to-GND, `tools/add_en_cap.py`) (no drawn wires: every pin carries a net label or power symbol; unused pins carry no-connect flags; ERC is clean apart from 72 stock-library-version warnings). The 23 surviving original parts keep
  their old positions at the top-left; everything new sits in labelled groups below.
- **PCB** (`MiniPC_v2.kicad_pcb`): **placed (by hand, rev-1 look: through-hole passives, black mask) and fully routed (4 Oct 2026)**: DRC **0 errors, 0 unconnected, 0 schematic-parity issues**;
  29 warnings, all understood (see "Layout and routing" below).
  Renders: `routing/top.png`, `routing/bottom.png`. Rebuild everything with `tools/build_pcb.py --from-scratch` (KiCad closed).
- **Fab files** (`fab/MiniPC_v2_JLCPCB_gerbers.zip`, made from the board above): 4 copper layers, masks, paste, silkscreen, outline (Protel extensions), PTH + NPTH Excellon (mm) + drill maps.
  Order notes for JLCPCB: 4 layers, 1.6 mm, **stack-up JLC04161H-7628** (the 50 ohm RF / 90 ohm USB widths are computed for it - ask for impedance control only if you want it guaranteed);
  the panel holds **two different designs** (handheld + node joined by mouse-bite tabs) - JLC normally counts that as a multi-design panel and may charge for it, so pick the panel option that matches when quoting.
- **Rules** (`MiniPC_v2.kicad_pro` + `MiniPC_v2.kicad_dru`): JLCPCB 4-layer (0.2 mm tracks / 0.15 mm clearance, 0.6/0.3 mm vias); net classes changed for routing, see below.

## Layout and routing (4 Oct 2026) - supersedes the panel / break-off placement notes further down
**Panel 100 x 100 mm** (JLC's cheap 4-layer tier): **flight node strip x 0..20 on the LEFT** (20 mm is the floor: the RFM95W alone is 16 mm + pads), 2 mm routed slot,
**handheld x 22..100 (78 x 100)**. 3 tabs (5 mm, at y 15 / 50 / 85) with mouse bites MB1..MB3 0.5 mm off the handheld edge. Node parts are on both sides of the strip (passives + crystal on the back).
**Handheld, front (final placement: moved by hand in KiCad by the user, 4 Oct 2026):** J3 (EXP 2) top-left and J1 (EXP 1) top-right corner, screen J5 right below them, landscape,
**turned 180 deg: its 7-pin header is now along the TOP edge of the module (pin 1 on the right)** - check that this matches your module (the picture is flipped in software if needed);
the screen is soldered straight on (~2.5 mm), so only flat SMD parts are under it (J5's courtyard covers just its header); WS2812 row + LDR right under the screen;
**d-pad cross centred on the handheld** (SW3 up, SW4 down, SW5 left, SW6 right, SW7 middle, 10 mm pitch), **buzzer next to it** (upper left), encoder SW10 on the left, EXIT SW11 at the top right under the screen;
**rev-1 look:** black solder mask, the visible passives through-hole like the first Mini PC (`tools/tht_passives.py`): 14 resistors lying flat (axial, 10.16 mm), 100 nF ceramic discs (C2 C5 C14 C18 C19),
1-10 uF 5 mm radial electrolytics (C1 C4 C20 C35; polarised, + = pad 1 = the supply net, checked). The ones under the screen / on the back stay 1206 SMD (C3 C6-C13 C15-C17 R15 F1);
**ESP32 on the right edge, antenna hanging 6 mm over it** (U1's courtyard = on-board part only; the antenna keep-out wings trimmed to +-19 mm so the USB-C stays out);
**BOOT SW1 + RESET SW2 side by side right under the ESP32, PWR SW8 next to them**; USB-C J2 on the right edge below, **slide switch SW9 at the bottom of the right edge** (farthest from the antenna),
actuator sticking out over the edge (the body stays on the board: its mounting pads end 0.2 mm inside the edge).
**Handheld, back:** top row ports J14 GPS, J13 / J12 I2C, J4 RTC; module headers J11 HAPTIC, J9 GY-91 (row 1), CC1101 socket U5, J8 3V3 MOD, J7 CHARGER, LIPO J6 (row 2); RFM95W U7 + u.FL J10.
The plug-in modules lie over the back next to their headers - **check their real sizes** before ordering (charger, TPS63020, GY-91, DRV2605L, CC1101 bodies were not modelled; nothing taller than ~2 mm is next to the headers).
**Node:** RFM95W U9 + u.FL J17 at the top, AMS1117, ATmega32U4, USB-C J16 out of the left edge, ICSP, plug row J15 BEC + J19 GPS + J20 BARO + J21 AIRSPEED + J22 I2C, then the **power block**:
PACK+ J23 top-left, PACK- J25 top-right, 1 mohm shunt R17, ESC+ J24 bottom-right, INA180 U10 bottom-left.
**Pack current** runs in solid pours on F.Cu + In2.Cu (stitched), not in tracks. **Kelvin sense** traces are hand-drawn and locked: IN+ from shunt pad 2 straight to U10 pin 3, IN- from pad 3 via B.Cu under the pour to pin 4.
They never touch the pours; R17 carries `(jumper_pad_groups ("1" "2") ("3" "4"))` so KiCad knows each pad pair is one terminal (board-only edit: an "update footprint from library" removes it - re-run `tools/build_pcb.py` or `manual.add_jumper_groups`).
**Stack-up use:** In1 = solid ground planes (GND handheld, N_GND node), In2 = signals + ground pour, F / B = signals + ground pour, ~150 ground stitching vias.
**Net classes changed for routing:** Power 0.4 mm / 0.2 mm (0.5 mm did not fit the 0.5 mm pitch MAX17048 / SOT-23 pins), GND and N_GND moved to Default (they are planes, only via stubs),
HighCurrent 0.25 mm (only the sense / divider taps; the current is in the pours). RF 0.3244 mm (50 ohm): LORA_ANT is one straight 3 mm B.Cu trace, N_ANT 2.8 mm on F.Cu.
`MiniPC_v2.kicad_dru`: through-hole pins may have 1 thermal spoke per layer. **Starved thermal = warning** (`MiniPC_v2.kicad_pro`): 14 through-hole ground pins get no spoke on ONE crowded layer
(J16 shell, SW8, SW11, J19, J20, C1, C19, R1, J11, J9 x2, J4); they keep their spokes on the other layers and the In1 plane, so they are connected AND still easy to hand-solder (a solid connection
to all four layers would not take solder from a normal iron). Only 4 small SMD ground pads are solid (D4, D5 pad 2; J2 A1 / B12).
**Remaining DRC warnings (all intended):** silkscreen of the edge-mounted parts (U1 antenna, J2, J16, SW9) crosses the board edge (the fab clips it), the stock DO-41 footprints' "K" overlaps their own circle,
U1 / J5 differ from their library footprint (the courtyard edits above). 6 small node parts have their reference hidden on silkscreen (no free spot; still on the fab layer): C23 C26 C33 D10 R22 R29.
**Decoupling distances after the hand placement:** the ESP32's 3V3 is decoupled right at its pin by C3 (10 uF, back, 1.5 mm); C1 / C2 now sit ~40-60 mm away (rail bulk only). C35 (EN 1 uF) is ~37 mm
from the EN pin - the reset RC works at any distance, but it filters noise on EN best right at the pin; moving C35 next to U1's EN (top-left of the module) would be the one worthwhile tweak.
C4 / C5 (screen supply) are at the bottom while the screen header is now at the top (~86 mm): the OLED module has its own caps, so these are only rail bulk.
**Decoupling moved / added (4 Oct 2026):** C35 (1 uF, new) next to the ESP32's EN pin (EN = R4 10k + C35: Espressif's reset RC); C29 (100 nF) is now the INA180's supply bypass right at its VS pin
(the regulator already has its 10 uF C32); C28 (100 nF) sits at the node RFM95W's 3.3 V pin (C33 10 uF stays at the AMS1117).
**Footprint-vs-library warnings (U1, J5):** intended. KiCad's normal "Update PCB from Schematic" keeps these edits (it only swaps a footprint whose name changed); do NOT tick "update footprints from library" for U1 / J5 / R17,
or re-run `tools/build_pcb.py` afterwards (it re-applies the courtyards, the trimmed antenna keep-out and R17's pad groups).
**Rebuild chain** (`tools/build_pcb.py`, KiCad closed, ~10 min; `--keep-placement` routes the placement that is on the board instead of re-placing - use it after moving parts by hand;
it runs `strip_routing.py` first): `place_v2.py` -> `route_prep.py` (+ `manual.py`) -> Freerouting (`C:\Users\pc\Documents\usbc-dock\tools\freerouting\...`) -> `route_import.py`
-> `post_route.py` -> `fix_opens.py` (DRC-driven, up to 4 rounds: closes opens with straight links or the `maze.py` grid router, solid-connects starved pins, nudges or rips up and reroutes vias that are too
close to something, merges same-net vias drilled on top of each other, ties stranded ground islands to the plane, removes dead-end copper) -> `silk_fix.py` -> final DRC. Freerouting is not deterministic: a rebuild routes differently (always re-check DRC).
Backups of each stage are in `backup/` (`before_placement`, `placed`, `routed_v2` ...).

## Parts
**Original, kept (23):** ESP32-S3-WROOM-1 (reused), USB-C, d-pad (Up/Down/Left/Right/Middle), Boot, Reset, Power *button* (MCU deep sleep), buzzer,
RTC header (J4), expansion headers J1/J3, C1-C3, R1-R6.
*(Removed from the original: TP4056 charger, step-up module, old 4-pin I2C OLED header, **AMS1117 and D1**.)*

**New (104) - module design (4 Oct 2026): 3.3 V, motion/compass/pressure, haptics and GPS are ready-made boards on pin headers; the old chip version is kept in `tools/add_parts_chip_design.py.bak`:**
| Group | Parts |
|---|---|
| Display | **2.42" SSD1309 OLED, 128x64** (non-square, 2:1 landscape, >= 2") as a 7-pin SPI module symbol (VCC GND DIN CLK CS DC RES) + 2 caps |
| LiPo charger | **your 1S TP4056 board** (with cell protection) on a 1x6 header + JST-PH battery socket + 1 bulk cap; the BQ24074 is gone |
| 3.3 V | **TPS63020 buck-boost module** (set to 3.3 V, not 4.2 / 5 V!) on a 4-pin header + 2 bulk caps (about 90 % efficient; the user's own 3.7 V -> 5 V boost module + AMS1117 would be about 55 %, so it is not used) |
| Fuel gauge | MAX17048 (battery % shown on the display) |
| Power switch | slide switch = hard power cut (the SW_Power button stays as the MCU deep-sleep button) |
| USB protection | USBLC6-2SC6 ESD array, **1 A** PTC, 10 uF |
| Motion + compass + pressure | **GY-91 module** (MPU9250 IMU + AK8963 compass + BMP280 pressure; no humidity) on a 1x8 header + 2 x 4.7k I2C pull-ups. Replaces LSM6DS3 + LIS3MDL + BME280 |
| Ambient light | **LDR (GL5528) + 10k divider** on an ADC pin (auto display brightness). Replaces the TSL25911 |
| LoRa | RFM95W-868S2 (SX1276; -915S2 for US) + u.FL antenna connector |
| Sub-GHz transceiver | **CC1101 module, 433 MHz** (8-pin SPI: GND VCC GDO0 CSN SCK MOSI MISO GDO2) in a 1.27 mm pin socket + 2 caps; the module brings its own SMA/spring antenna. Reads/learns 433 MHz remotes and sensors (non-rolling-code); the RFM95W covers 868 |
| GPS | **ATGM336H GP-02 board** (ceramic antenna on the board) plugs into the **UART PORT**: no GPS chip / u.FL / bias parts on this PCB |
| Haptics | **DRV2605L module** on a 1x6 header + ERM coin motor (wires to the module's motor pads) |
| Lights | 4 x WS2812B-2020 RGB LEDs |
| Inputs | EC11 rotary encoder (placeholder footprint - low-profile one later) + exit button; the 5 d-pad buttons, exit and the encoder push go to the **PCF8574 expander** below |
| I2C expander | **PCF8574T** (7 buttons, interrupt pin wakes the ESP32 from deep sleep) + 0.1 uF + 10k INT pull-up |
| Power OR-ing | **2 x 1N5819 Schottky (D_BAT, D_USB)** between battery / USB and the TPS63020 input: the converter's output only ever feeds the 3V3 rail, USB never reaches the battery, nothing back-feeds (the rev-1 boost-module noise) |
| Add-on ports | 2 x I2C + 1 x UART 4-pin 2.54 mm plugs, **pin order of the first board's J1/J3 headers beside the display: 1 IO1, 2 IO2, 3 VCC, 4 GND** (I2C: SDA SCL 3V3 GND; UART: module-TX module-RX 3V3 GND). VCC is 3.3 V here |
| Switched rails | **2 x AO3401A P-MOSFET high-side gates** (100k gate pull-ups, GPIO low = on): LED3V3 for the 4 WS2812B, GPS3V3 for the GPS port, so deep sleep really sleeps |
| Buzzer driver | **S8050 / 2N3904 NPN + 1k base resistor + 1N5819 flyback diode** (a 16 ohm magnetic buzzer needs far more than a GPIO can give) |
| **Break-off board** | EasyGlider flight node built from the **burnt Pro Micro's own parts**: ATmega32U4-AU + 16 MHz crystal + USB-C port, LEDs, reset, ICSP; plus RFM95W + u.FL, INA180A2 + Kelvin shunt, AMS1117-3.3, 1k/2k level shifters, 4 plug ports for GPS / baro / airspeed / spare (about 49 parts, see below) |

## Power tree and GPIO pin plan (4 Oct 2026)
**Power tree (parts are placed, wiring is yours):** USB 5 V -> 1 A PTC -> (a) charger board IN+ and (b) D_USB -> VIN node. Battery (charger board OUT+/OUT-, protected) -> slide switch -> D_BAT -> VIN node.
VIN node -> TPS63020 module (set to **3.3 V**) -> 3V3 rail. MAX17048 CELL/VDD straight to the battery (OUT+, before the switch). With USB plugged in the load runs from USB (VBUS - 0.3 V beats battery - 0.3 V), so the TP4056 charges undisturbed.
The slide switch cuts the battery only: with USB plugged in the device still runs. The LEDs and the GPS port sit behind P-MOSFET gates (IO7 = LED_EN, IO40 = GPS_EN, active low), so deep sleep is only the converter, gauge, expander and sensors (a few hundred uA with the LDR divider). Set IO42 (LED data) low before switching the LED rail off.
**Proposed ESP32-S3-WROOM-1 pins** (avoids IO0 boot-only, IO3 / IO45 / IO46 strapping, IO19 / IO20 USB, IO35-37 octal PSRAM on N16R8 modules; the LDR is on an ADC1 pin because ADC2 does not work with Wi-Fi):
| Signal | Pin | Signal | Pin |
|---|---|---|---|
| I2C SDA / SCL (GY-91, MAX17048, DRV2605L, PCF8574, ports A/B) | IO8 / IO9 | SPI SCK / MOSI / MISO (OLED, LoRa, CC1101) | IO12 / IO11 / IO13 |
| OLED CS / DC / RES | IO10 / IO14 / IO15 | LoRa NSS / RST / DIO0 | IO16 / IO17 / IO18 |
| CC1101 CSN / GDO0 / GDO2 | IO21 / IO38 / IO39 | PCF8574 INT (wake) / Power button (wake) | IO4 / IO5 |
| LDR (ADC1) / LED rail gate (low = on) | IO6 / IO7 | Encoder A / B | IO47 / IO48 |
| WS2812 data / buzzer | IO42 / IO41 | UART port (GPS GP-02) TX / RX | IO43 / IO44 |
| Expansion headers J1 / J3 | IO1 / IO2 | Boot button / reset | IO0 / EN |
| GPS port rail gate (low = on) | IO40 | MAX17048 ALRT | not used |
PCF8574 pins: P0 Up, P1 Down, P2 Left, P3 Right, P4 Middle, P5 Exit, P6 encoder push, P7 spare. 25 GPIOs used, about 5 spare. The SPI lines are shared already (SCK / MOSI / MISO are the same three pins for all three devices; only the chip-selects, DC, RES, DIO0 and GDO pins are separate).
Check the OLED: most 7-pin SSD1309 boards ship set to I2C and need their mode resistors moved for SPI.

## Wiring (generated, 4 Oct 2026)
`tools/add_parts.py` wires everything with **net labels on the pin ends** (the pins themselves touch the label, so there are no wires to route or break). The handheld nets are `GND`, `+3V3`, `VBUS`, `VBUSF` (after the 1 A PTC), `VBAT`, `BATN`, `VBSW` (after the slide switch),
`VIN` (the OR-ing node), `LED3V3`, `GPS3V3`, `SDA` / `SCL`, `SCK` / `MOSI` / `MISO`, `OLED_*`, `LORA_*`, `CC_*`, `BTN_*`, `ENC_*`, `PCF_INT`, `PWR_BTN`, `LDR`, `WS_DATA`, `BUZ`, `UART_TX` / `UART_RX`, `IO0`, `IO1`, `IO2`, `EN`, `USB_DM` / `USB_DP` (ESP side) and `USB_DMC` / `USB_DPC` (connector side).
The flight node is a separate board, so **every node net is prefixed `N_`** (`N_GND`, `N_5V`, `N_3V3`, `N_USBV`, `N_BEC`, `N_PACKP`, `N_ESCP`, ...) and nothing is shared with the handheld (checked in the exported netlist).
Things to know before layout:
- The 1 mohm shunt has 4 pads: pads 1 + 2 are the pack side, 3 + 4 the ESC side; lay the INA180 sense traces from pads 2 and 3 only (Kelvin), the high current through pads 1 and 4. Three solder-wire pads (PACK+, ESC+, PACK-) take the 3S wiring.
- The two charger / boost / GY-91 / DRV2605L headers are typical pin orders - check them against the boards you have before routing.
- `PWR_FLAG` symbols (top middle of the sheet, right of the node) exist only so ERC knows the rails are driven.
- Rebuild: `prune_j56.py -> localize_libs.py -> strip_connections.py -> add_parts.py` (KiCad closed). It overwrites the schematic, so it must not be run once you edit the schematic by hand.

## Silkscreen labels (4 Oct 2026)
Every part's **Value is now a short silkscreen name** (the long description moved to a hidden `Note` field on the symbol) and the PCB prints **Reference above and Value below each part** (F.SilkS, 1.0 mm / 0.15 mm).
Buttons: SW3 UP, SW4 DOWN, SW5 LEFT, SW6 RIGHT, SW7 MIDDLE, SW8 PWR (deep-sleep button), SW11 EXIT, SW1 BOOT, SW2 RESET, SW10 ENCODER, SW9 BATT SW (slide switch). Modules and ports: OLED 2.42, CHARGER, 3V3 MOD, GY-91, HAPTIC, CC1101, LORA 868 / LORA ANT, GPS UART, I2C A, I2C B, EXP 1 / EXP 2, RTC, LIPO, USB-C, BUZZER;
flight node: BEC IN, ICSP, GPS, BARO, AIRSPEED, I2C SPARE, PACK+, ESC+, PACK-, SHUNT 1mR.
**Headers and sockets also print their pin names beside every pin** (for example the ports: SDA SCL 3V3 GND; CHARGER: IN+ IN- OUT+ OUT- B+ B-; GPS: M-TX M-RX 3V3 GND where M-TX / M-RX are the module's own TX / RX pins). These are texts that belong to the footprint, so they move and rotate with it and survive "Update PCB from Schematic".
If a footprint is ever replaced or updated from the library they disappear: close KiCad and run `tools/silkscreen.py` again (KiCad's python: `"%LOCALAPPDATA%\Programs\KiCad\10.0\bin\python.exe" tools\silkscreen.py MiniPC_v2.kicad_pcb --write`; add `--reset-text-positions` only for the very first run, it re-puts Reference / Value above / below every part).
The names live in `tools/add_parts.py` (`LABEL_MAP`, `OLD_LABELS`) and are exported to `tools/labels.json`, which `silkscreen.py` reads.

## PCB setup for JLCPCB 4-layer (4 Oct 2026)
- **Outline:** the 80.5 x 90.0 mm rectangle now has **2 mm rounded corners** (4 lines + 4 arcs on Edge.Cuts, 0.05 mm). 3 mm was tried first but it clips the ESP32's corner GND pad, which sits 0.23 mm from the right edge (rev-1 placement); `tools/round_corners.py <pcb> <radius> --write` re-does it with any radius.
- **Vias (pick while routing):** **0.6 / 0.3 mm** = JLC standard (default in every net class), **0.45 / 0.2 mm** = JLC minimum for 4 layers (dense areas under the TQFP / ESP32), **0.8 / 0.4 mm** = power and stitching.
- **Track widths:** 0.15, 0.2 (default), 0.2332, 0.3, 0.3244, 0.5, 0.8, 1.0, 2.0, 3.0 mm. **Net classes:** Default 0.2 mm track / 0.15 mm clearance; **Power** 0.5 mm / 0.2 mm (+3V3, GND, VBAT, VBUS, VBUSF, VBSW, VIN, BATN, LED3V3, GPS3V3, and the node's N_5V / N_3V3 / N_GND / N_USBV / N_BEC);
  **HighCurrent** 3 mm / 0.3 mm (N_PACKP, N_ESCP: the 3S pack -> shunt -> ESC path, up to 16-37 A, so use big copper pours on both outer layers with many 0.8 / 0.4 mm vias, not a track);
  **USB** 0.2332 mm, 0.15 mm gap, 90 ohm differential (USB_DM / USB_DP and the connector-side nets, both boards); **RF** 0.3244 mm = 50 ohm microstrip for LORA_ANT and N_ANT (needs an unbroken ground plane on layer 2).
- **Fab limits entered in the project:** min track 0.1, clearance 0.1, via 0.45 / 0.2 (annular ring 0.125), copper to board edge 0.2 mm (0.3 mm recommended; the ESP32 pads are at 0.23), silkscreen text 1.0 mm high / 0.15 mm stroke and 0.15 mm to pads. JLC's own minimum is 0.09 mm track / space.
- **Stackup:** JLC04161H-7628, 1.6 mm: 35 um copper / 0.2104 mm 7628 prepreg / 15.2 um inner copper / 1.065 mm core / 15.2 um / 0.2104 mm prepreg / 35 um (inner layers 0.5 oz). The 50 ohm and 90 ohm widths above are JLC's figures for exactly this stackup.
- `tools/set_jlc_rules.py <project>` writes the rules, classes and stackup (KiCad closed); re-run it if you add nets that belong in a class. DRC with these rules: 0 errors (386 unrouted connections, nothing is routed yet).
  (`gen_rules_v2.py` from the earlier PCB generator is superseded.)

## Break-off board: EasyGlider flight node (separate PCB region, snapped off later)
**Why LoRa and not Spektrum telemetry:** the AR620 has *no* telemetry / X-Bus port (Horizon lists telemetry ports as "NA"; TM1000/TM1100 are not compatible with it either).
Its built-in telemetry only reports the receiver's own supply voltage, not your 3S pack. So the node talks to the **Mini PC over LoRa** (868 MHz): the Mini PC already has the
RFM95W and the display. (A telemetry-capable "T" receiver would allow Spektrum X-Bus later: I2C 3.3 V open-drain, receiver = master, slave address 0x34 battery gauge.)
- **On the node (Pro Micro rebuild, 4 Oct 2026):** the user's burnt board is a **Pro Micro (ATmega32U4, native USB, USB-C 12P)**, not a Nano: the ATmega32U4-AU (TQFP-44), 16 MHz crystal, USB-C port, LEDs come off it (no reset button on the node, 4 Oct 2026: touch the ICSP header's RST pin to GND instead; the Arduino IDE resets the board over USB by itself);
  resistors / caps are through-hole. Native USB means **no CH340G, no 12 MHz crystal, no DTR cap**; it programs like a Pro Micro (Caterina bootloader, Arduino IDE "Arduino Leonardo / Pro Micro"), ICSP header for a reflash.
  USB-C: same HRO TYPE-C-31-M-12 footprint as J2 + 2 x 5.1k CC resistors, 2 x 22R on D+/D-, 1 uF on UCAP, 10k on HWB, 10k reset pull-up. 5 V logic straight from the receiver BEC (must be 5.0-5.5 V, **not** a 6 V BEC), Schottky from USB 5 V,
  AMS1117-3.3 only for the RFM95W + modules, 1k/2k through-hole dividers level-shift MOSI / SCK / NSS / RESET to the RFM95W (MISO / DIO0 read fine at 5 V; DIO0 on D7 = INT6). RFM95W-868S2 + u.FL,
  INA180A2 + **1 mohm 4-terminal Kelvin shunt** (high-side), 100k/22k divider (3S = 12.6 V -> 2.27 V). GPS on the hardware UART (Serial1, D0/D1), I2C on D2/D3, SPI on the ICSP pins.
  **Limits vs the ESP32-C3 plan:** 2.5 KB RAM, 28 KB flash and no flash for a flight log, so the node only streams over LoRa and the Mini PC records / replays the flight (gaps if the plane flies out of range).
  Confirmed by the user: the crystal is 16 MHz (= 5 V board, so the level-shift dividers stay) and the 3.3 V AMS1117 is the one desoldered from the old Mini PC. Still to check: the chip marking (ATmega32U4).
- **Plug-in sensors (4-pin plugs, no soldering):** GPS (UART: GND VCC TX RX; e.g. BN-220 / GY-GPS6MV2 with its patch antenna), BARO (I2C; e.g. MS5611 or BMP390 module),
  AIRSPEED (I2C; e.g. MS4525DO or SDP3x kit), plus one spare I2C port. I2C pull-ups (4.7k) are on the node.
- **Flight replay:** the node logs GPS track, altitude, airspeed, battery % / current / mAh to its flash and also streams them over LoRa; the Mini PC stores them (16 MB flash)
  and replays the flight (track plot, altitude and speed graphs). USB export (CSV / KML for Google Earth) is a firmware feature for later.
- **Reports live:** battery % (voltage + integrated mAh), current, position, altitude, airspeed; about one packet every few seconds (868 MHz EU duty cycle: stay under 1 %).
- **3S numbers:** stock EasyGlider about 16 A, up to 25-37 A with a larger ESC. 1 mohm shunt: 16 A -> 0.26 W, 37 A -> 1.4 W (fine for a WSK2512). Wire BATT+ -> shunt -> ESC+, GND wire to the node.
- **Break-off board on the PCB (4 Oct 2026, now on the RIGHT side):** the whole panel is **100 x 100 mm** (JLCPCB's cheap 4-layer tier ends there): handheld **65 x 100 mm** at the left, 2 mm routed slot,
  flight node **33 x 97 mm** on its right edge (`tools/make_breakoff.py`, 2 mm corners). 3 tabs (5 mm wide, at y = 14.6 / 48.5 / 82.5) with 5 mouse-bite holes each (0.5 mm NPTH, 0.8 mm pitch, footprints MB1..MB3
  in `MiniPC_v2.pretty`, 'not in schematic' so Update PCB leaves them), 0.5 mm off the handheld edge. The 55 node parts are on it in a **first-pass placement** (no overlaps, nothing routed): the 21 big parts on the front
  (USB-C faces out of the free right edge), the **34 SMD resistors / capacitors on the back** (flip the board to solder them; through-hole pins and the RF area are kept clear there).
  **Why 33 mm and not the 15 mm asked for:** the RFM95W alone is 16.6 mm wide and the ATmega32U4 13.4 mm, the front parts need about 1600 mm2 of courtyard and a 15 mm strip is only 1450 mm2 in total; the packer needs
  at least 30-33 mm whatever the spacing (3.2 / 2.6 / 1.9 mm gaps all tried). The only ways to a ~15-20 mm strip are fewer parts on it (e.g. no USB-C, no plug headers, a smaller radio) or a bigger panel.
  Consequence: a 65 mm wide handheld cannot hold the 72.5 mm screen lying down, so **J5 is turned to portrait** (header down the left edge, pin 1 at the top, module 44 x 72.5 mm at x 1.5, y 1.5).
  The ESP32 (U1) antenna must not point at the node, so **U1 is turned to the bottom edge** (antenna off the board, pos 12.5 mm from the right edge); SW8 keeps its 6.35 mm from the right edge and 37.25 mm above the bottom.
  **Area check:** handheld part courtyards add up to about 6400 mm2 (screen 3200, 1206 passives 380) on 6500 mm2 of board, so it only works with parts on BOTH sides: SMD ICs / passives, the radios, the JST socket and the plug-in
  modules on the back, screen + 6 mm buttons + encoder + ESP32 on the front (the buttons and both optional modules, CC1101 and DRV2605L, stay).
  `make_breakoff.py --side=top --redo` puts the node back on top (handheld 100 x 66, landscape screen); `--node-width=N` forces a strip width; `--front-only` keeps the node's passives on the front.
  Do not run `round_corners.py` any more (it refuses: it would rebuild one rectangle). Keep the LoRa antenna side free of metal.
- **1206 SMD resistors / capacitors (4 Oct 2026):** all 69 R / C are `R_1206_3216Metric` / `C_1206_3216Metric` (3.2 x 1.6 mm: big enough to hand-solder; were THT axial / disc / radial, then 0805 for a few minutes).
  `tools/swap_passives_smd.py` swapped them on the PCB. Only the reference is printed on the silkscreen for them (the value is on the fab layer). The LDR stays through-hole. 1206 also makes 10 uF easy in 16-25 V ceramics.
  New parts to buy: 1206 resistor kit 6.89 + 1206 capacitor kit (1 nF - 22 uF) 2.29 + 1206 capacitor kit (1 pF - 820 pF, for the 2 x 22 pF) 2.29 = about 11.5 EUR (see `parts_checklist.html`);
  the through-hole resistors / capacitors you own are no longer used.
- **Estimated cost:** node about 13 EUR (ESP32-C3 ~2.5, RFM95W ~5, antenna ~2, shunt+INA ~1.6, misc ~2) + GPS module ~6-8 + baro module ~3-6;
  **airspeed is the expensive one:** ready-made MS4525DO / SDP3x kits are about 45-60 EUR (ports are ready; buy later). Total without airspeed about 25-30 EUR.
- **Plug pin order** (all 4 ports): 1 IO1, 2 IO2, 3 VCC, 4 GND, i.e. the first board's J1/J3 headers (read from the rev-1 PCB nets). I2C ports: pin 1 SDA, pin 2 SCL.
  GPS plug: pin 1 = module TX, pin 2 = module RX. VCC on the node plugs is the AMS1117's 3.3 V.

## Display notes
- Colour OLED at >= 2" and ~1:2 **does not exist as a standard part.** Closest colour options: 1.91" AMOLED 240x536 (RM67162, QSPI, ~2.2:1, just under 2"),
  2.16" AMOLED 480x480 (square), 2.41" AMOLED 600x450 (4:3). The SSD1309 2.42" (white / yellow / blue / green, one colour per module) is the only one
  meeting size + shape. SSD1309 modules differ in header pin order between vendors (Waveshare: VCC GND DIN CLK CS DC RES; common generic: GND VCC D0 D1 RES DC CS) -
  pick the module before wiring.

**Screen footprint (4 Oct 2026):** J5 uses the project footprint `MiniPC_v2:OLED_2.42_SSD1309_Module` (library `MiniPC_v2.pretty`, registered in `fp-lib-table`),
drawn at the real module size so the layout keeps the whole screen clear: courtyard + silkscreen outline **72.0 x 43.5 mm**, active area 55.01 x 27.49 mm and the 4 mounting-hole
positions (2.8 mm, 68 x 39 mm) on F.Fab (not drilled), 7 header pads (2.54 mm) along the long bottom edge, pin names under the pads (staggered so 'VCC' etc. fit).
The module sits on its header **on top of the board**, so nothing on the front side may be under it (back side is free). J5 is placed on the board as a size reference
(pad 1 at 32.5 / 44.0, module 4.1 .. 76.1 x 3.0 .. 46.5 mm). **Assumed, not verified (no vendor drawing found):** header centred on the bottom edge, pad centres 2.5 mm from the edge,
active area centred, board 72.0 x 43.5 (vendors list 72.0 x 43.0 .. 43.5). Check against the module you receive; change the constants in `tools/make_oled_footprint.py`,
re-run it, then `tools/swap_oled_footprint.py <pcb> --write` and `tools/silkscreen.py <pcb> --write` (KiCad closed).

## GPS notes
- ATGM336H-5N31 pin map (from GitHub, u-blox MAX-M8 pin-compatible): pins 1-6, 8-12, 14-17 match KiCad's official `RF_GPS:MAX-8C`; pins 7/13/18 (VCC_IO / LNA_EN /
  SAFEBOOT on the u-blox) are NC/Reserved on the ATGM. Footprint: KiCad stock `RF_GPS:ublox_MAX` (identical 18-pad pattern). **Verify against the Zhongkewei
  datasheet before ordering a PCB** (I could not download it).
- Needs an antenna: an active GPS antenna with a u.FL cable (~2-3), powered through VCC_RF (pin 14) via the bias inductor.

## AliExpress-only pricing (3 Oct 2026, EU storefront, EUR, before shipping) - current plan
Everything on the sheet from AliExpress = **about EUR 104** (handheld about 90 + flight node about 13), because most parts only come in lots (5-20 pcs), so ~25 of it is spare chips / kits.
**Stage 1 for about EUR 50** (populate only this at first; every footprint stays on the PCB so the rest can be hot-air soldered later):
OLED 9.79, BQ24074 (5 pcs) 2.69, TPS63001 (10 pcs) 5.29 + 2.2 uH inductors 2.69, MAX17048 2.35, USB-C x10 1.25, USBLC6 x10 1.55, PTC x10 1.05, JST-PH 2.05, slide switch 1.79, LiPo 1000 mAh 4.29,
6 mm tactile x20 1.25, SMD tactile x50 1.69, EC11 1.15, buzzer x10 2.35, WS2812B-2020 x20 2.39, LSM6DS3TR-C 2.15, resistor kit 2.25, capacitor kit 3.19, headers 1.15 = ~52 (50 without USBLC6 + PTC).
Later stages: radios (RFM95W 3.49, 2 antennas 1.69, u.FL x20 1.29, CC1101 2.75) ~9; sensors+haptics (BME280 3.49, LIS3MDL 3.49, TSL25911 3.05, DRV2605L x5 5.89, motor 0.5, TPS22919 x5 2.45) ~19;
GPS (ATGM336H 4.19, active antenna 2.69, 10 nH kit 2.99) ~10; flight node (ESP32-C3 2.49, RFM95W 3.49, INA180 x10 1.79, AMS1117 x10 1.59, 1 mohm shunt x10 3.99) ~13.
Caveats: shipping not included (free over EUR 10 per seller, so expect +10-25 from ~25 sellers); AliExpress ICs can be relabelled (BME280 'chip' listing is rated 3 stars - modules are often BMP280);
substitutes needing a footprint/value check: 2.2 uH 0420 inductor vs SRN4018, 3x4x2 SMD button vs B3U-1000P, 2-terminal 1 mohm shunt vs 4-terminal WSK2512, E24 resistors instead of the E96 values around the BQ24074 (1.78k, 3.09k, 2.94k, 37.4k).

## FINAL sourcing: module design (4 Oct 2026) - what to buy, AliExpress, EUR
**Owned (not bought):** the **1S TP4056 charger board** (used as a module on a header: no charger chip on the PCB; its DW01A + FS8205A cell protection comes with it, its JST-PH socket if it is the SMD right-angle type), pin headers (the GTIWUNG 3.7 V -> 5/8/9/12 V boost module is not used), USB-C port (J2 keeps the rev-1 HRO TYPE-C-31-M-12 footprint), all resistors / caps (through-hole), all buttons (9 x 6 mm, 2 x SMD B3U for Boot / Reset). ESP32-S3 reused.
**3.3 V on the handheld = a new TPS63020 module (1.79), bought instead of using the owned 3.7 V -> 5 V boost module + AMS1117 (rev-1 style, about 55 % efficient = roughly 35 % less battery life).**
Power-path: the two Schottky diodes (D_BAT, D_USB) make the TPS63020 run from USB when it is plugged in, so the TP4056 charges undisturbed and nothing back-feeds the battery or the converter output; set the charger's Rprog to ~3k (400 mA) so charge + load stay under USB's 500 mA.
**Handheld, about 50 incl. LiPo (45 with your own cell):** OLED 7.49, TPS63020 3.3 V module 1.79, PCF8574 1.35, 1N5819 x100 1.65 (4 needed), MAX17048 2.35, USBLC6 x10 1.35, PTC 1 A x10 1.05, PCM12 x2 1.79, LiPo 4.29, GY-91 4.89, LDR x20 1.29, RFM95W 3.29, CC1101 + antenna 2.75,
868 antennas x2 1.69, u.FL x20 1.29, GP-02 GPS 2.79, DRV2605L module 3.09 + motor 0.5, EC11 1.15, passive buzzer x5 1.35, WS2812B-2020 x20 2.39 (+2.05 if the TP4056 JST socket does not fit).
**Flight node, about 8 (Pro Micro parts reused, AMS1117 desoldered from the old Mini PC):** RFM95W 3.29, INA180 x10 1.79, 1 mohm 2512 x20 2.69. **Total about 59 (+ AO3401A x20 0.62 and S8050 x100 0.99 for the new gates / buzzer driver).** (A fresh Pro Micro clone is about 3 if rebuilding turns out to be a hassle.)
The old board's KiCad symbol was the *adjustable* AMS1117, but it had no divider resistors, so the part should be the fixed 3.3 V one: check that the marking reads 1117-3.3.
Caveats: shipping not included (about +10-25 over many sellers); module pin orders (charger board, TPS63020, GY-91, DRV2605L) are typical - check the boards you have / receive; no power gates any more.

## OLD chip-design sourcing (4 Oct 2026) - superseded by the module design above
Decision: the schematic stays chips; the user buys cheap modules where that beats the bare-chip lot and moves the chip onto our footprint (hot air).
**Owned (not bought):** USB-C port (J2 keeps the rev-1 HRO TYPE-C-31-M-12 footprint), TP4056 board parts (JST-PH socket if it is the SMD right-angle type, LEDs, DW01A + FS8205A cell protection if the LiPo has none),
all resistors / caps (through-hole), all buttons (9 x 6 mm, 2 x SMD B3U for Boot / Reset). The BQ24074 stays (power-path, 1.69 for 5): a TP4056 cannot run the device while charging.
**Harvest from modules:** DRV2605L from a 3.09 module (chip lot 5.89), ATGM336H-5N31 from the 2.79 GP-02 GPS board (bare module 4.19). Not worth it: MAX17048 / LSM6DS3 boards save ~0.4, LIS3MDL board costs 11.69, no BQ24074 / TPS63001 boards exist.
**Buy (AliExpress, EUR):** OLED 7.49, BQ24074 x5 1.69, TPS63001 x10 5.29, 2.2 uH x10 2.69, MAX17048 2.35, USBLC6 x10 1.35, PTC x10 1.05, PCM12 x2 1.79, LiPo 4.29, EC11 1.15, passive buzzer x5 1.35, WS2812B-2020 x20 2.39, LSM6DS3TR-C 2.15, headers 1.15,
RFM95W 3.29, CC1101 + antenna 2.75, 868 antennas x2 1.69, u.FL x20 1.29, BME280 3.49, LIS3MDL 3.49, TSL25911 3.05, DRV2605L module 3.09 + motor 0.5, GP-02 2.79 + active GPS antenna 2.69 + 10 nH kit 2.99, TPS22919 x5 2.45;
flight node: ESP32-C3-WROOM-02 2.49, RFM95W 3.29, INA180 x10 1.79, AMS1117 x10 1.59, 1 mohm 2512 x20 2.69.
**Total about EUR 82 = handheld 70 (incl. LiPo; +2.05 if the TP4056 JST socket does not fit) + flight node 12.** Stage 1 (about 49: everything except GPS, compass, light sensor, haptics, power gates, node) then GPS+sensors+haptics+gates ~21 and the node ~12 later.

## Cheaper AliExpress swaps (4 Oct 2026) - NOT adopted (module swaps; the user keeps chips)
Replacing discrete chips with ready modules takes the handheld to **about EUR 58 incl. LiPo (54 without)** and the flight node to **about EUR 10.5** (total about 68; the 104 above was chip lots).
- TPS63001 + inductor (8.0) -> TPS63020 3.3 V buck-boost module 1.79 (BQ24074 stays: 5 pcs 1.69)
- LSM6DS3 + LIS3MDL + BME280 (9.1) -> GY-91 (MPU9250 + AK8963 compass + BMP280, no humidity) 4.89
- TSL25911 (3.05) -> LDR on an ADC pin 1.29 (20 pcs); GPS chip + antenna + u.FL + inductor (9.9) -> ATGM336H GP-02 board with ceramic antenna 2.79 on the UART port
- DRV2605L chip lot (5.89) -> DRV2605L module 3.09; OLED cheapest decent 7.49; slide switch MSK-12C02 1.49; **buzzer must be passive** (5 pcs 1.35; the earlier 2.35 listing was an active, single-tone buzzer)
- Node: ESP32-C3 SuperMini 2.69 (replaces WROOM-02 + AMS1117 + PROG header + EN/BOOT buttons), RFM95W 3.29, INA180 1.79, 2512 shunt 2.69
- Dropping the TPS22919 gates (2.45) and SMD buttons (1.69: all buttons become 6 mm). For about 50 on the handheld: own LiPo, no USBLC6/PTC/JST connector.
- **Through-hole passives and buttons (applied in the schematic, 4 Oct 2026):** all resistors use the **rev-1 footprint** (1/4 W axial lying flat, P10.16 mm horizontal - the same as R1-R6), 100 nF / 100 pF are ceramic discs, 1-22 uF are 5 mm radial electrolytics, 9 buttons are 6 mm tactile (d-pad, power, exit, node EN/BOOT) and the handheld Boot / Reset keep the original SMD B3U footprint (the user owns 2 of those) - the user already owns all of these, so the resistor kit (2.25), capacitor kit (3.19) and buttons (1.25) leave the shopping list (-6.69).
  Resistors are E24 only now: the BQ24074 values became 3k / 1.8k / 3k / 36k (were 3.09k / 1.78k / 2.94k / 37.4k) - recheck against the datasheet. **New totals with the module swaps: handheld about 51 incl. LiPo (47 with own LiPo), flight node about 10.5, together about 62.**

## European shops + AliExpress pricing (3 Oct 2026, 1 USD = 0.8875 EUR) - earlier, superseded by the AliExpress-only plan above
**No LCSC (not possible for this build): European shops + AliExpress only.** **About EUR 108 for everything on the sheet** (handheld about 86, flight node about 22),
plus about 9 for a LiPo cell; realistically 140-150 landed after shipping from 5-6 shops and VAT. ESP32-S3 reused (0). Quantity-1 prices, net of VAT unless noted.
- TME: BQ24074 2.12, TPS63001 2.09, USBLC6 x10 2.17, TPS22919 x4 0.82, WS2812B-2020 x10 1.84, PCM12 1.00, B3U-1000P x4 2.03, EC11E15244G1 2.33, ESP32-C3-WROOM-02-N4 3.29, RFM95W-868S2R x2 13.47
- DigiKey / Mouser (US companies with EU delivery - swap to Farnell/AliExpress if not allowed): MAX17048 2.96, LSM6DS3TR-C **5.82** (Mouser; DigiKey out of stock), BME280 3.58, LIS3MDL 2.75,
  TSL25911 1.54, DRV2605L 2.02, INA180A2 0.41, JST-PH 0.43, SRN4018 0.32, 1 mohm shunt **WSK25121L000FEA** 1.70 (DigiKey out of stock until Mar 2027)
- Tinytronics: CC1101 module 5.00 (gross). BerryBase: coin motor 3.20. electronicaembajadores: active GPS antenna u.FL 3.52.
- AliExpress (search-result prices, listings did not load: +-30%): ATGM336H-5N31 ~5.7, 2.42" OLED SPI/I2C module ~10, 868 MHz u.FL antenna x2 ~4, USB-C TYPE-C-31-M-12 x10 ~2, u.FL connectors ~1, passive kits (0603 R + C, 10/22 uF 0805, rare E96 values) ~14.
- Estimates: through-hole bits (7 tactile, buzzer, axial R, radial/disc C, headers, 1.27 mm socket) ~6.5, PTC 0.3, AMS1117 0.3.
- Display note: Tinytronics' 2.42" OLED (14.00) is I2C only; the schematic's SPI module matches the AliExpress 7-pin SPI/I2C boards (2.54 mm pins) and Waveshare (MX1.25 connector).
The table below is the **older** estimate and is superseded.

## Budget estimate - OLD (EUR, single pieces, no shipping/tax/PCB; ESP32 reused)
Ballpark only: module prices from a quick web check, chip prices LCSC-class. Verify before ordering.

| Block | ~EUR |
|---|---|
| 2.42" SSD1309 mono OLED module | 10 (7-12) |
| LoRa RFM95W + u.FL | 5.2 |
| GPS: ATGM336H ~3 + active antenna ~2 | 5 |
| BQ24074 + JST + parts | 1.85 |
| TPS63001 + inductor | 2.3 |
| CC1101 433 MHz module + socket | 3.5 (2.5-5) |
| MAX17048 | 2.0 |
| slide switch | 0.3 |
| USB-C, ESD, PTC | 0.7 |
| DRV2605L + motor | 2.2 |
| 4 x WS2812B-2020 | 1.0 |
| encoder + 10 buttons + buzzer | 2.0 |
| LSM6DS3 + BME280 | 4.5 |
| RTC module (J4) + headers | 1.9 |
| 4 x TPS22919 power gates + ~55 passives | 3.8 |
| LIS3MDL + TSL25911 + 2 caps | 3.5 (estimate) |
| **core total** | **~50** |
| not included: LiPo cell ~5-6, 868 MHz antenna ~2, PCB, shipping | |

## Antennas
- **Sub-GHz (LoRa 868/915 MHz):** u.FL port on the board -> FPC or rubber-duck antenna with a u.FL pigtail (~2).
- **Sub-GHz (CC1101, 433 MHz):** the module carries its own antenna connector (SMA / spring); no u.FL on the board. The common green module covers 387-464 MHz only.
  **Verify the pin pitch of the module you buy** (Waveshare / Ebyte boards are 1.27 mm; the footprint is `PinSocket_1x08_P1.27mm`) and its pin order (GND VCC GDO0 CSN SCK MOSI MISO GDO2 per the Ebyte manual).
- **GPS (1575 MHz):** the GP-02 board brings its own ceramic patch antenna (plugs into the UART port); no u.FL or antenna parts on the PCB.
- **2.4 GHz:** the ESP32-S3 PCB antenna as-is; for range swap to the ESP32-S3-WROOM-1**U** (u.FL, identical pads) + a dual-band flex antenna.
- **5 GHz:** the ESP32-S3 has no 5 GHz radio. Plan: a separate dual-band module (ESP32-C5 / BW16, ~5) on the add-on port you will build later.

## How it was built (tools/)
`prune_j56.py` -> `localize_libs.py` -> `strip_connections.py` -> `add_parts.py` (+ `parts_groups.json`, `third_party/`). Run in that order to rebuild the schematic
from the original; it overwrites `MiniPC_v2.kicad_sch`, so do not run it after you start wiring.
`make_oled_footprint.py` writes the full-size screen footprint, `swap_oled_footprint.py` swaps J5 on the PCB to it (keeps nets / schematic link), `silkscreen.py` redoes the labels.
`gen_pcb_v2.py` + `gen_rules_v2.py` rebuild the PCB from the current schematic (only while the board is unplaced).
